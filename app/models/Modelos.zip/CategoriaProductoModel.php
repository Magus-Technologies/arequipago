<?php

class CategoriaProductoModel {
    private $conectar;

    public function __construct() {
        $this->conectar = (new Conexion())->getConexion(); // Conexión a la base de datos
    }

    public function guardarCategoriaProducto($categoriaProducto) {
        $sql = "INSERT INTO categoria_producto (nombre) VALUES (?)"; // Consulta SQL
        $stmt = $this->conectar->prepare($sql);
        $stmt->bind_param("s", $categoriaProducto); // Vincular parámetro
        return $stmt->execute(); // Ejecutar la consulta
    }

    public function getUltimoIdInsertado() {
        return $this->conectar->insert_id; // Obtener el último ID insertado
    }

       
    public function obtenerCategoriasProducto() {
        $sql = "SELECT idcategoria_producto, nombre FROM categoria_producto";
        $stmt = $this->conectar->prepare($sql);
            
        if ($stmt->execute()) {
            $result = $stmt->get_result();
            $categorias = $result->fetch_all(MYSQLI_ASSOC);
            return $categorias;
        } else {
            return [];
        }
    }
    
    
}
