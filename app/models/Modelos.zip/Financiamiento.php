<?php

    class Financiamiento
    {
        private $id_cliente;
        private $codigo_asociado;
        private $grupo_financiamiento;
        private $estado;
        private $monto_total;
        private $cuotas;
        private $fecha_inicio;
        private $fecha_fin;
        private $conectar;

        public function __construct()
        {
            $this->conectar = (new Conexion())->getConexion();
        }

        public function guardarFinanciamiento($datos)
        {
        try {
            // Preparar la consulta SQL
            $sql = "INSERT INTO financiamiento (
                id_conductor, idproductosv2, id_coti, codigo_asociado, 
                grupo_financiamiento, cantidad_producto, monto_total, cuota_inicial, 
                cuotas, estado, fecha_inicio, fecha_fin, fecha_creacion, frecuencia, 
                second_product, monto_inscrip, moneda  -- Agregamos el campo 'moneda'
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"; 

            $stmt = $this->conectar->prepare($sql);

            if (!$stmt) {
                error_log("Error preparando la consulta: " . $this->conectar->error);
                throw new Exception('Error al preparar la consulta SQL');
            }

            // Vincular parámetros
            $stmt->bind_param(
                "iiisssddissssssds",
                $datos['id_conductor'],
                $datos['id_producto'],
                $datos['id_coti'],
                $datos['codigo_asociado'],
                $datos['grupo_financiamiento'],
                $datos['cantidad_producto'],
                $datos['monto_total'],
                $datos['cuota_inicial'],
                $datos['cuotas'],
                $datos['estado'],
                $datos['fecha_inicio'],
                $datos['fecha_fin'],
                $datos['fecha_creacion'],
                $datos['frecuencia'],
                $datos['planT'],
                $datos['monto_inscrip'],
                $datos['tipo_moneda']
            );

            // Ejecutar la consulta
            if (!$stmt->execute()) {
                error_log("Error ejecutando la consulta: " . $stmt->error);
                throw new Exception('Error al ejecutar la consulta');
            }

            // Obtener el ID insertado
            $idFinanciamiento = $stmt->insert_id;
            $stmt->close();

            return $idFinanciamiento;
        } catch (Exception $e) {
            error_log("Excepción capturada: " . $e->getMessage());
            throw $e;
        }
    }

    private function crearCuotas($id_financiamiento, $cantidad_cuotas, $valor_cuota, $fecha_inicio)
    {
        $fecha_vencimiento = $this->calcularFechaVencimiento($fecha_inicio);
        $estado = "Pendiente";  // Estado por defecto

        for ($i = 1; $i <= $cantidad_cuotas; $i++) {
            // Insertar cada cuota
            $sql = "INSERT INTO cuotas_financiamiento (id_financiamiento, numero_cuota, monto, fecha_vencimiento, estado) 
                    VALUES (?, ?, ?, ?, ?)";
            $stmt = $this->conectar->prepare($sql);
            $stmt->bind_param("iiiss", $id_financiamiento, $i, $valor_cuota, $fecha_vencimiento, $estado);
            $stmt->execute();
            
            // Incrementar fecha de vencimiento para la siguiente cuota
            $fecha_vencimiento = $this->calcularFechaVencimiento($fecha_vencimiento);
        }
    }

    private function calcularFechaVencimiento($fecha_inicio)
    {
        $fecha = new DateTime($fecha_inicio);
        $fecha->modify('+1 month');  // Añadir un mes a la fecha de inicio para la fecha de vencimiento
        return $fecha->format('Y-m-d');
    }

    

public function obtenerTotalClientes($searchTerm = '')
{
    try {
        // Consulta para obtener el total de clientes filtrados
        $sql = "SELECT COUNT(*) as total
                FROM clientes c
                LEFT JOIN financiamiento f ON c.id_cliente = f.id_cliente
                WHERE c.datos LIKE ? OR f.codigo_asociado LIKE ?";

        $stmt = $this->conectar->prepare($sql);
        $searchTermLike = "%$searchTerm%";
        $stmt->bind_param("ss", $searchTermLike, $searchTermLike);
        $stmt->execute();
        $result = $stmt->get_result();
        $row = $result->fetch_assoc();

        return $row['total'];
    } catch (Exception $e) {
        error_log("Error en Cliente::obtenerTotalClientes(): " . $e->getMessage());
        throw $e;
    }
}

public function obtenerPorConductor($id_conductor)
{
    try {
        $sql = "SELECT tipo_doc, nro_documento, 
                       CONCAT(nombres, ' ', apellido_paterno, ' ', apellido_materno) AS nombre_completo 
                FROM conductores 
                WHERE id_conductor = ?";
        
        $stmt = $this->conectar->prepare($sql); // Preparar la consulta
        $stmt->bind_param("i", $id_conductor); // Enlazar el parámetro
        $stmt->execute();
        $result = $stmt->get_result();
        
        $conductor = $result->fetch_assoc(); // Obtener el resultado como un array asociativo
        
        return $conductor ? $conductor : []; // Devolver el resultado o un array vacío si no hay datos
    } catch (Exception $e) {
        error_log("Error en Financiamiento::obtenerPorConductor(): " . $e->getMessage()); // Registrar el error
        throw $e;
    }
}

public function obtenerFinanciamientoPorCliente($id_cliente)
    {
        try {
            $sql = "SELECT * FROM financiamiento WHERE id_cliente = ?";
            $stmt = $this->conectar->prepare($sql);
            $stmt->bind_param("i", $id_cliente);
            $stmt->execute();
            $result = $stmt->get_result();
            return $result->fetch_assoc();
        } catch (Exception $e) {
            return ['error' => 'Error al obtener financiamiento: ' . $e->getMessage()];
        }
    }

        
    public function ObtenerFinanciamientoPorConductor ($id_conductor){
        try {
            $sql = "SELECT * FROM financiamiento WHERE id_conductor = ?";
            $stmt = $this->conectar->prepare($sql);
            $stmt->bind_param("i", $id_conductor);
            $stmt->execute();
            $result = $stmt->get_result();
    
            return $result->fetch_assoc();
        } catch (Exception $e) {
            return ['error' => 'Error al obtener el financiamiento: ' . $e->getMessage()];
        }     
    }

    public function buscarFinanciamientos($query)
    {
        $query = strtolower($query);
        $query = "%$query%";

        $sql = "
            SELECT 
                f.idfinanciamiento AS id,
                CONCAT(c.nombres, ' ', c.apellido_paterno, ' ', c.apellido_materno) AS cliente,
                f.fecha_creacion AS fecha,
                f.monto_total AS monto,
                f.estado AS estado
            FROM financiamiento f
            INNER JOIN conductores c ON f.id_conductor = c.id_conductor
            WHERE 
                LOWER(f.idfinanciamiento) LIKE ? OR
                LOWER(CONCAT(c.nombres, ' ', c.apellido_paterno, ' ', c.apellido_materno)) LIKE ? OR
                LOWER(f.fecha_creacion) LIKE ? OR
                LOWER(f.monto_total) LIKE ? OR
                LOWER(f.estado) LIKE ?
        ";

        $stmt = $this->conectar->prepare($sql);
        $stmt->bind_param('sssss', $query, $query, $query, $query, $query);
        $stmt->execute();

        $result = $stmt->get_result();
        $resultados = [];

        while ($row = $result->fetch_assoc()) {
            $resultados[] = $row;
        }

        $stmt->close();
        return $resultados;
    }

    public function getFinanciamientoById($id) {
        $sql = "SELECT * FROM financiamiento WHERE idfinanciamiento = ?";
        $stmt = $this->conectar->prepare($sql);
        
        if (!$stmt) {
            die('Error al preparar la consulta financiamiento: ' . $this->conectar->error);
        }
        
        $stmt->bind_param('i', $id);
        $stmt->execute();
        $result = $stmt->get_result()->fetch_assoc();
        
        // Verificamos si el resultado es null
        if ($result === null) {
            return []; // Retornamos un array vacío si no se encuentra el financiamiento
        }
        
        return $result;
    }
    
    public function getConductorById($id) {
        $sql = "SELECT * FROM conductores WHERE id_conductor = ?";
        $stmt = $this->conectar->prepare($sql);
        
        if (!$stmt) {
            die('Error al preparar la consulta conductor: ' . $this->conectar->error);
        }
        
        $stmt->bind_param('i', $id);
        $stmt->execute();
        $result = $stmt->get_result()->fetch_assoc();
        
        // Verificamos si el resultado es null
        if ($result === null) {
            return []; // Retornamos un array vacío si no se encuentra el conductor
        }
        
        return $result;
    }
    
    public function getDireccionCompleta($idConductor) {
        $sql = "
            SELECT 
                dc.direccion_detalle,
                dep.nombre AS departamento,
                prov.nombre AS provincia,
                dist.nombre AS distrito
            FROM direccion_conductor dc
            LEFT JOIN depast dep ON dc.departamento = dep.iddepast
            LEFT JOIN provincet prov ON dc.provincia = prov.idprovincet
            LEFT JOIN distritot dist ON dc.distrito = dist.iddistritot
            WHERE dc.id_conductor = ?
        ";
        $stmt = $this->conectar->prepare($sql);
        
        if (!$stmt) {
            die('Error al preparar la consulta direccion conductor: ' . $this->conectar->error);
        }
        
        $stmt->bind_param('i', $idConductor);
        $stmt->execute();
        $direccion = $stmt->get_result()->fetch_assoc();
        
        // Verificamos si la dirección es null
        if ($direccion === null) {
            return ''; // Retornamos una cadena vacía si no se encuentra la dirección
        }
        
        // Verificamos si los valores son null antes de devolverlos
        $direccionDetalle = isset($direccion['direccion_detalle']) ? $direccion['direccion_detalle'] : '';
        $departamento = isset($direccion['departamento']) ? $direccion['departamento'] : '';
        $provincia = isset($direccion['provincia']) ? $direccion['provincia'] : '';
        $distrito = isset($direccion['distrito']) ? $direccion['distrito'] : '';
        
        return "{$direccionDetalle}, {$departamento}, {$provincia}, {$distrito}";
    }
    
    public function getProductoById($id) {
        $sql = "SELECT codigo, nombre FROM productosv2 WHERE idproductosv2 = ?";
        $stmt = $this->conectar->prepare($sql);
        
        if (!$stmt) {
            die('Error al preparar la consulta producto: ' . $this->conectar->error);
        }
        
        $stmt->bind_param('i', $id);
        $stmt->execute();
        $producto = $stmt->get_result()->fetch_assoc();
        
        // Verificamos si el producto es null
        if ($producto === null) {
            return ['codigo' => 'N/A', 'nombre' => 'Producto no disponible']; // Retornamos valores por defecto
        }
        
        // Verificamos si los valores son null antes de devolverlos
        $codigo = isset($producto['codigo']) ? $producto['codigo'] : 'N/A';
        $nombre = isset($producto['nombre']) ? $producto['nombre'] : 'Producto no disponible';
        
        return ['codigo' => $codigo, 'nombre' => $nombre];
    }

    public function buscarFinanciamientosPorFecha($fechaInicio, $fechaFin)
    {
        // Consulta SQL para obtener los financiamientos dentro del rango de fechas
        $sql = "
            SELECT 
                f.idfinanciamiento AS id,
                CONCAT(c.nombres, ' ', c.apellido_paterno, ' ', c.apellido_materno) AS cliente,
                f.fecha_creacion AS fecha,
                f.monto_total AS monto,
                f.estado AS estado
            FROM financiamiento f
            INNER JOIN conductores c ON f.id_conductor = c.id_conductor
            WHERE f.fecha_creacion BETWEEN ? AND ?
        ";

        // Preparar y ejecutar la consulta
        $stmt = $this->conectar->prepare($sql);
        $stmt->bind_param('ss', $fechaInicio, $fechaFin);
        $stmt->execute();

        $result = $stmt->get_result();
        $resultados = [];

        // Obtener los resultados
        while ($row = $result->fetch_assoc()) {
            $resultados[] = $row;
        }

        $stmt->close();
        return $resultados;
    }
    
    public function obtenerTipoProducto($idFinanciamiento)
    {
        $query = "SELECT p.tipo_producto 
                  FROM financiamiento f
                  INNER JOIN productosv2 p ON f.idproductosv2 = p.idproductosv2
                  WHERE f.idfinanciamiento = ?";
        $stmt = $this->conectar->prepare($query);
        $stmt->bind_param('i', $idFinanciamiento);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($row = $result->fetch_assoc()) {
            return $row['tipo_producto'];
        }

        return null; // Si no se encuentra el producto
    }

    public function obtenerProductoConCategoria($idProducto)
    {
        $sql = "SELECT codigo, nombre, categoria, cantidad, cantidad_unidad, unidad_medida, tipo_producto, fecha_vencimiento, ruc, razon_social, precio, fecha_registro, guia_remision 
            FROM productosv2 
            WHERE idproductosv2 = ?";
        $stmt = $this->conectar->prepare($sql);

        if (!$stmt) {
            die('Error al preparar la consulta producto: ' . $this->conectar->error);
        }

        $stmt->bind_param('i', $idProducto);
        $stmt->execute();
        $producto = $stmt->get_result()->fetch_assoc();

        if ($producto === null) {
            return [
                'codigo' => 'N/A',
                'nombre' => 'Producto no disponible',
                'categoria' => 'N/A',
                'cantidad' => 0,
                'cantidad_unidad' => 0,
                'unidad_medida' => '',
                'tipo_producto' => 'N/A', // Modificado: Nueva clave añadida
                'fecha_vencimiento' => null, // Modificado: Nueva clave añadida
                'ruc' => 'N/A', // Modificado: Nueva clave añadida
                'razon_social' => 'N/A', // Modificado: Nueva clave añadida
                'precio' => 0.00, // Modificado: Nueva clave añadida
                'fecha_registro' => null, // Modificado: Nueva clave añadida
                'guia_remision' => 'N/A',
            ]; 
        }

        return $producto;
    }

    public function getFinanciamientoList($id_conductor) { // Modificado
        $sql = "SELECT * FROM financiamiento WHERE id_conductor = ?"; // Modificado
        $stmt = $this->conectar->prepare($sql); // Modificado
        $stmt->bind_param('i', $id_conductor); // Modificado
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->fetch_all(MYSQLI_ASSOC);
    }


    public function getPlanChecker($idProducto) {
        // Consulta para obtener el id_plan del producto seleccionado
        $sql = "SELECT id_plan FROM productosv2 WHERE idproductosv2 = ?";
        $stmt = $this->conectar->prepare($sql);
        $stmt->bind_param("i", $idProducto);
        $stmt->execute();
        $resultado = $stmt->get_result();
        $producto = $resultado->fetch_assoc();

        // Si no hay producto o no tiene un plan asociado, retornamos null
        if (!$producto || empty($producto['id_plan'])) {
            return null;
        }

        $idPlan = $producto['id_plan'];

        // Consulta para obtener los detalles del plan de financiamiento
        $sqlPlan = "SELECT * FROM planes_financiamiento WHERE idplan_financiamiento = ?";
        $stmtPlan = $this->conectar->prepare($sqlPlan);
        $stmtPlan->bind_param("i", $idPlan);
        $stmtPlan->execute();
        $resultadoPlan = $stmtPlan->get_result();

        return $resultadoPlan->fetch_assoc() ?: null; // Retorna el plan o null si no se encuentra
    }

    public function eliminarFinanciamiento($id_financiamiento) {
        try {
            $this->conectar->begin_transaction(); // Iniciar transacción

            // 1. Eliminar las cuotas asociadas
            $sqlCuotas = "DELETE FROM cuotas_financiamiento WHERE id_financiamiento = ?";
            $stmtCuotas = $this->conectar->prepare($sqlCuotas);
            $stmtCuotas->bind_param("i", $id_financiamiento);
            $stmtCuotas->execute();

            if ($stmtCuotas->affected_rows === -1) {
                throw new Exception("Error al eliminar cuotas.");
            }
            $stmtCuotas->close();

            // 2. Eliminar el financiamiento
            $sqlFinanciamiento = "DELETE FROM financiamiento WHERE idfinanciamiento = ?";
            $stmtFinanciamiento = $this->conectar->prepare($sqlFinanciamiento);
            $stmtFinanciamiento->bind_param("i", $id_financiamiento);
            $stmtFinanciamiento->execute();

            if ($stmtFinanciamiento->affected_rows === -1) {
                throw new Exception("Error al eliminar financiamiento.");
            }
            $stmtFinanciamiento->close();

            $this->conectar->commit(); // Confirmar transacción
            return true;
        } catch (Exception $e) {
            $this->conectar->rollback(); // Revertir cambios si hay error
            return false;
        }
    }
    
}
