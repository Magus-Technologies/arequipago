<?php

class GrupoFinanciamientoModel {
    private $conectar;

    public function __construct() {
        $this->conectar = (new Conexion())->getConexion();
    }

    public function guardarGrupoFinanciamiento($nombre) {
        $sql = "INSERT INTO grupovehicular_financiamiento (nombre) VALUES (?)";
        $stmt = $this->conectar->prepare($sql);

        if ($stmt) {
            $stmt->bind_param("s", $nombre); // "s" para tipo string
            return $stmt->execute(); // Ejecutar la consulta
        }
        return false;
    }

    public function getUltimoIdInsertado() {
        return $this->conectar->insert_id; // Obtener el último ID insertado
    }

    public function obtenerGruposFinanciamiento() {
        $sql = "SELECT idgrupoVehicular_financiamiento, nombre FROM grupovehicular_financiamiento";
        $stmt = $this->conectar->prepare($sql);

        if ($stmt->execute()) {
            $result = $stmt->get_result();
            $grupos = $result->fetch_all(MYSQLI_ASSOC);
            return $grupos;
        } else {
            return [];
        }
    }

    
    public function insertarPlan($nombrePlan, $cuotaInicial, $montoCuota, $cantidadCuotas, $frecuenciaPago, $moneda, $tasaInteres)
    {
        $sql = "INSERT INTO planes_financiamiento (nombre_plan, cuota_inicial, monto_cuota, cantidad_cuotas, frecuencia_pago, moneda, tasa_interes, penalizacion_mora) 
                VALUES (?, ?, ?, ?, ?, ?, ?, NULL)";

        $stmt = $this->conectar->prepare($sql);
        
        if (!$stmt) { // 🔹 Verifico si la preparación falló
            die("Error en la preparación de la consulta: " . $this->conectar->error);
        }

        $stmt->bind_param("sddissd", $nombrePlan, $cuotaInicial, $montoCuota, $cantidadCuotas, $frecuenciaPago, $moneda, $tasaInteres);
        // 🔹 Cambié el tipo de 'cantidadCuotas' de 'd' a 'i' porque es un entero

        return $stmt->execute();
    }

    public function getAllPlanes() {
        $sql = "SELECT * FROM planes_financiamiento";
        $result = $this->conectar->query($sql); // Modificado: Ahora usamos query() en MySQLi en lugar de prepare/execute de PDO

        $planes = [];
        while ($row = $result->fetch_assoc()) { // Modificado: Usamos fetch_assoc() en lugar de fetchAll(PDO::FETCH_ASSOC)
            $planes[] = $row;
        }

        return $planes;
    }

    public function saveAsociation($codigo, $idPlan) {
        // Buscar el producto por código o código de barra
        $sql = "SELECT idproductosv2 FROM productosv2 WHERE codigo = ? OR codigo_barra = ? LIMIT 1"; // Modificado: Se usa ? para prevenir SQL Injection
        $stmt = $this->conectar->prepare($sql);
        $stmt->bind_param("ss", $codigo, $codigo); // Modificado: Usamos bind_param() para vincular valores
        $stmt->execute();
        $result = $stmt->get_result();

        if ($row = $result->fetch_assoc()) {
            $idProducto = $row["idproductosv2"];

            // Actualizar el id_plan en el producto encontrado
            $updateSql = "UPDATE productosv2 SET id_plan = ? WHERE idproductosv2 = ?"; // Modificado: Se usa ? para seguridad
            $stmt = $this->conectar->prepare($updateSql);
            $stmt->bind_param("ii", $idPlan, $idProducto); // Modificado: Se pasan los valores con bind_param()
            return $stmt->execute(); // Ejecutar la actualización
        }
        return false;
    }

}
