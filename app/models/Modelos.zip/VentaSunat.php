<?php
class VentaSunat
{
    private $id_venta;
    private $hash;
    private $nombre_xml;
    private $conectar;
    private $qr_data;
    private $sql;
private $sql_error;

    /**
     * VentaSunat constructor.
     */
    public function __construct()
    {
        $this->conectar = (new Conexion())->getConexion();
    }

    /**
     * @return mixed
     */
    public function getIdVenta()
    {
        return $this->id_venta;
    }

    /**
     * @return mixed
     */
    public function getQrData()
    {
        return $this->qr_data;
    }

    /**
     * @param mixed $qr_data
     */
    public function setQrData($qr_data): void
    {
        $this->qr_data = $qr_data;
    }

    /**
     * @param mixed $id_venta
     */
    public function setIdVenta($id_venta)
    {
        $this->id_venta = $id_venta;
    }

    /**
     * @return mixed
     */
    public function getHash()
    {
        return $this->hash;
    }

    /**
     * @param mixed $hash
     */
    public function setHash($hash)
    {
        $this->hash = $hash;
    }

    /**
     * @return mixed
     */
    public function getNombreXml()
    {
        return $this->nombre_xml;
    }

    /**
     * @param mixed $nombre_xml
     */
    public function setNombreXml($nombre_xml)
    {
        $this->nombre_xml = $nombre_xml;
    }
    public function getSql()
    {
        return $this->sql;
    }
    
    public function setSql($sql)
    {
        $this->sql = $sql;
    }
    
    public function getSqlError()
    {
        return $this->sql_error;
    }
    
    public function setSqlError($sql_error)
    {
        $this->sql_error = $sql_error;
    }
    public function insertar()
{
    $this->sql = "insert into ventas_sunat 
    values ('$this->id_venta', '$this->hash', '$this->nombre_xml', '$this->qr_data')";
    
    $result = $this->conectar->query($this->sql);
    
    if (!$result) {
        $this->sql_error = $this->conectar->error;
        error_log("Error al insertar venta_sunat: " . $this->sql_error . "\nConsulta: " . $this->sql);
    }
    
    return $result;
}

public function obtenerDatos()
{
    $this->sql = "select * 
    from ventas_sunat 
    where id_venta = '$this->id_venta'";
    
    $fila = $this->conectar->get_Row($this->sql);
    
    if (!$fila) {
        $this->sql_error = $this->conectar->error;
        error_log("Error al obtener datos de venta_sunat: " . $this->sql_error . "\nConsulta: " . $this->sql);
        return false;
    }
    
    $this->hash = $fila['hash'];
    $this->nombre_xml = $fila['nombre_xml'];
    return true;
}
}