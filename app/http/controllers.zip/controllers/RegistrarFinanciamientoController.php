<?php

require_once "app/models/Financiamiento.php";
require_once "app/models/CuotaFinanciamiento.php";
require_once "app/models/Conductor.php";

class RegistrarFinanciamientoController extends Controller
{
    public function __construct()
    {
        $this->conexion = (new Conexion())->getConexion();

    }

    public function guardarFinanciamiento()
    {
        try {
            // Obtener los datos recibidos por POST
            $datos = $_POST;

            $fechasVencimiento = $datos['fechas_vencimiento'];
            
            

            // Validar que todos los campos requeridos estén presentes
            $camposRequeridos = ['id_conductor','id_producto', 'codigo_asociado', 'monto_total', 'grupo_financiamiento', 'cuotas', 'estado', 'fecha_inicio', 'fecha_fin', 'fecha_creacion'];
            foreach ($camposRequeridos as $campo) {
                if (empty($datos[$campo])) {
                    throw new Exception("Falta el campo obligatorio: $campo");
                }
            }
            $montoTotal = floatval(str_replace('S/. ', '', $datos['monto_total']));
            // Guardar el financiamiento
            $financiamientoModel = new Financiamiento();
            $idFinanciamiento = $financiamientoModel->guardarFinanciamiento($datos);

            $cuotas = $datos['cuotas'];
            $valorCuota = $datos['valorCuota'];

            // Iterar sobre las fechas de vencimiento y guardar cada cuota
            for ($i = 0; $i < count($fechasVencimiento); $i++) {
                $cuotaModel = new CuotaFinanciamiento();
                // Convertir la fecha de vencimiento a formato 'Y-m-d'
                $fechaVencimiento = date('Y-m-d', strtotime($fechasVencimiento[$i]));
                $cuotaModel->guardarCuota($idFinanciamiento, $i + 1, $valorCuota, $fechaVencimiento);
            }

            $this->enviarRespuesta(true, 'Registro completado con éxito.', $idFinanciamiento);
        } catch (Exception $e) {
            $this->enviarRespuesta(false, 'Error: ' . $e->getMessage());
        }
    }

    // Método para buscar conductor
    public function buscarConductor() {
        header('Content-Type: application/json');
        // Recibimos el número de documento del front-end
        $nroDocumento = $_GET['nro_documento'];

        // Llamamos al modelo para buscar el conductor
        $conductorModel = new Conductor();
        $idConductor = $conductorModel->buscarPorDocumento($nroDocumento);

        // Verificamos si encontramos al conductor
        if ($idConductor) {
            echo json_encode(['success' => true, 'id_conductor' => $idConductor]);
        } else {
            echo json_encode(['success' => false, 'message' => 'Conductor no encontrado']);
        }
    }

    private function enviarRespuesta($success, $message, $idFinanciamiento = null)
    {
        $response = [
            'success' => $success,
            'message' => $message
        ];

        if ($idFinanciamiento !== null) { // 🔹 Si hay un ID, lo agregamos a la respuesta
            $response['id_financiamiento'] = $idFinanciamiento;
        }

        
        header('Content-Type: application/json');
        echo json_encode($response);
        exit;
    }
}