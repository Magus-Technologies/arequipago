<?php
require_once "app/models/Conductor.php";
require_once "app/models/DireccionConductor.php";
require_once "app/models/ContactoEmergencia.php";
require_once "app/models/Inscripcion.php";
require_once "app/models/Vehiculo.php";
require_once "app/models/Requisito.php";
require_once "app/models/Kit.php";
require_once "app/models/Observacion.php";
require_once 'utils/lib/vendor/autoload.php'; // Importar PhpSpreadsheet
require_once 'utils/lib/exel/vendor/autoload.php'; // Importar PhpSpreadsheet

use PhpOffice\PhpSpreadsheet\Spreadsheet; // Importar la clase Spreadsheet
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

class ConductorController extends Controller
{

    private $conexion;
    //private $conductor;


    

    public function __construct()
    {
        $this->conexion = (new Conexion())->getConexion();
       // $this->conductor = new Conductor();
    }

    
    // Método para mostrar la lista de conductores
   /* public function index()
    {
        $conductores = $this->conductor->verFilas();
        // Aquí deberías incluir la vista donde se mostrará la lista de conductores
        include_once 'app/views/conductor/index.php';
    }

    // Método para mostrar el formulario de creación de un nuevo conductor
    public function create()
    {
        // Mostrar formulario para agregar conductor
        include_once 'app/views/conductor/create.php';
    }

    // Método para almacenar un nuevo conductor
    public function store()
    {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            // Recibimos los datos del formulario
            $this->conductor->setTipoDoc($_POST['tipo_doc']);
            $this->conductor->setNroDocumento($_POST['nro_documento']);
            $this->conductor->setNombres($_POST['nombres']);
            $this->conductor->setApellidoPaterno($_POST['apellido_paterno']);
            $this->conductor->setApellidoMaterno($_POST['apellido_materno']);
            $this->conductor->setNacionalidad($_POST['nacionalidad']);
            $this->conductor->setNroLicencia($_POST['nro_licencia']);
            $this->conductor->setTelefono($_POST['telefono']);
            $this->conductor->setCorreo($_POST['correo']);

            // Insertar conductor en la base de datos
            $resultado = $this->conductor->insertar();

            // Redirigir a la lista de conductores o mostrar un mensaje de éxito
            if ($resultado) {
                header("Location: /conductores"); // Redirigir a la lista
            } else {
                // Aquí podrías mostrar un mensaje de error
                echo "Error al insertar conductor";
            }
        }
    }

    // Método para mostrar el formulario de edición de un conductor
    public function edit($id)
    {
        $this->conductor->setIdConductor($id);
        $this->conductor->obtenerDatos();
        
        // Mostrar formulario de edición con los datos del conductor
        include_once 'app/views/conductor/edit.php';
    }

    // Método para actualizar los datos de un conductor
    public function update($id)
    {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            // Recibimos los datos del formulario
            $this->conductor->setIdConductor($id);
            $this->conductor->setTipoDoc($_POST['tipo_doc']);
            $this->conductor->setNroDocumento($_POST['nro_documento']);
            $this->conductor->setNombres($_POST['nombres']);
            $this->conductor->setApellidoPaterno($_POST['apellido_paterno']);
            $this->conductor->setApellidoMaterno($_POST['apellido_materno']);
            $this->conductor->setNacionalidad($_POST['nacionalidad']);
            $this->conductor->setNroLicencia($_POST['nro_licencia']);
            $this->conductor->setTelefono($_POST['telefono']);
            $this->conductor->setCorreo($_POST['correo']);

            // Actualizar los datos del conductor en la base de datos
            $resultado = $this->conductor->modificar();

            // Redirigir a la lista de conductores o mostrar un mensaje de éxito
            if ($resultado) {
                header("Location: /conductores"); // Redirigir a la lista
            } else {
                // Aquí podrías mostrar un mensaje de error
                echo "Error al actualizar conductor";
            }
        }
    }

    // Método para buscar conductores por nombre o apellido
    public function buscar()
    {
        if (isset($_GET['term'])) {
            $term = $_GET['term'];
            $resultados = $this->conductor->buscarConductores($term);
            echo json_encode($resultados); // Retornar los resultados en formato JSON
        }
    }*/
    public function buscarDocInfo()
    {
        $token = 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJlbWFpbCI6InN5c3RlbWNyYWZ0LnBlQGdtYWlsLmNvbSJ9.yuNS5hRaC0hCwymX_PjXRoSZJWLNNBeOdlLRSUGlHGA';
        
        // Validar y sanitizar el documento
        $doc = filter_var($_POST['doc'], FILTER_SANITIZE_STRING);
        
        if (strlen($doc) == 8) {
            $url = 'https://dniruc.apisperu.com/api/v1/dni/' . $doc . '?token=' . $token;
        } else {
            $url = 'https://dniruc.apisperu.com/api/v1/ruc/' . $doc . '?token=' . $token;
        }
    
        $data = $this->apiRequest($url);
        
        if (isset($data['data'])) {
            if (strlen($doc) == 8) {
                $data["data"]["nombre"] = $data["data"]["nombres"] . " " . $data["data"]["apellidoPaterno"] . " " . $data["data"]["apellidoMaterno"];
            } else {
                $data["data"]["nombre"] = $data["data"]["razonSocial"];
            }
        }
    
        echo json_encode($data);
    }
    
    public function apiRequest($url)
    {
        $curl = curl_init();
        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
        $result = curl_exec($curl);
        curl_close($curl);
        return json_decode($result, true);
    }

   
    public function verDetalleConductor()
    {
        header('Content-Type: application/json');
        try {
            $id = isset($_GET['id']) ? (int)$_GET['id'] : 0; // Cambié 'id_conductor' para que coincida con la variable de la URL (comentado para claridad)

            // Verificar si el ID del conductor es válido
            if ($id <= 0) {  // Verificar si el ID es inválido
                throw new Exception("ID del conductor no válido");
            }


            // Instanciar modelos
            $conductor = new Conductor();
            $direccionConductor = new DireccionConductor();
            $vehiculo = new Vehiculo();
            $requisito = new Requisito();
            $observacion = new Observacion();
            $inscripcion = new Inscripcion(); 

            // Obtener datos del conductor
            $conductor->setIdConductor($id);
            if (!$conductor->obtenerDatos()) {
                throw new Exception("No se encontraron datos para el conductor con ID $id");
            }
            $conductorArray = []; // Definir un array vacío para almacenar los datos
            foreach ((array) $conductor as $key => $value) { // Recorrer las propiedades del objeto
                $key = preg_replace('/^\x00.+\x00/', '', $key); // Eliminar prefijos de propiedades privadas
                $conductorArray[$key] = $value; // Asignar al array con las claves limpias
            }

            // Obtener dirección del conductor
            $direccion = $direccionConductor->obtenerDatosDireccion($id);
            

            // Obtener datos del vehículo
            $datosVehiculo = $vehiculo->obtenerDatosVehiculo($id);

            // Obtener requisitos
            $datosRequisitos = $requisito->obtenerDatosRequisitos($id);

            $datoobservacion = $observacion->obtenerObservacion($id);
            

            // Obtener el valor de 'setare' desde el modelo Inscripcion
            $inscripcion = $inscripcion->obtenerInscripcionPorConductor($id);
           

            $response = [
                'success' => true,
                'data' => [
                    'conductor' => $conductorArray, // Asegurarse de que el array tenga los datos correctos
                    'direccion' => $direccion ?: [], // Asegurar que no sea null
                    'vehiculo' => $datosVehiculo ?: [], // Asegurar que no sea null
                    'requisitos' => $datosRequisitos ?: [], // Asegurar que no sea null
                    'observacion' => $datoobservacion,
                    'inscripcion' => $inscripcion
                ]
            ];
        } catch (Exception $e) {
            // Manejar errores
            $response = [
                'success' => false,
                'message' => $e->getMessage()
            ];
        }

        echo json_encode($response, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
        exit;
    }

    
    public function descargarDocumento()
    {
        // Validate and sanitize the input
        $filePath = filter_input(INPUT_POST, 'url', FILTER_SANITIZE_STRING);
    
        if (!$filePath) {
            http_response_code(400);
            echo json_encode(['error' => 'Invalid file path']);
            exit;
        }

        // Asegurar que la ruta no incluya "public/uploadFiles/"
        $filePath = str_replace(['/', '\\'], DIRECTORY_SEPARATOR, $filePath);
            
        // Obtener la ruta absoluta
        $fullPath = realpath($filePath);

            // DEPURACIÓN: Ver valores de las rutas
            

            if ($fullPath === false || !file_exists($fullPath)) { // <-- Verificación corregida
                http_response_code(404);
                echo json_encode(['error' => 'File not found']);
                exit;
            }

        // Obtener el tipo MIME del archivo
        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        $mimeType = finfo_file($finfo, $fullPath);
        finfo_close($finfo);
    
        // Configurar las cabeceras para la descarga
        header('Content-Type: ' . $mimeType);
        header('Content-Disposition: attachment; filename="' . basename($fullPath) . '"');
        header('Content-Length: ' . filesize($fullPath));

    
        // Output file contents
        readfile($fullPath);
        exit;
    } 

    public function allConductors() {
        if (!isset($_GET['id']) || empty($_GET['id'])) {
            echo json_encode(['success' => false, 'message' => 'ID de conductor no proporcionado']);
            return;
        }

        $id_conductor = $_GET['id'];

        // Obtener datos del conductor
        $conductor = new Conductor();
        $conductor->setIdConductor($id_conductor);
        $datosConductor = $conductor->obtenerDatosEdit(); 

        if ($datosConductor === false) { // Changed condition to check for false explicitly
            echo json_encode(['success' => false, 'message' => 'Error al obtener datos del conductor']);
            return;
        }      

        // Obtener dirección del conductor
        $direccion = new DireccionConductor();
        $datosDireccion = $direccion->getEditdirection($id_conductor);

        // Obtener contacto de emergencia
        $contactoEmergencia = new ContactoEmergencia();
        $contactoEmergencia->setIdConductor($id_conductor);
        $contactoEmergencia->obtenerDatosporConductor();

        //var_dump($contactoEmergencia->toArray());

        // Obtener datos del vehículo
        $vehiculo = new Vehiculo();
        $datosVehiculo = $vehiculo->obtenerDatosVehiculo($id_conductor);

        //var_dump($datosVehiculo);

        // Obtener datos de inscripción
        $inscripcion = new Inscripcion();
        $datosInscripcion = $inscripcion->obtenerInscripcionPorConductor($id_conductor);

        //var_dump($datosInscripcion);

        // Obtener estado de requisitos
        $requisito = new Requisito();
        $estadoRequisitos = $requisito->obtenerEstadoRequisitos($id_conductor);

        //var_dump($estadoRequisitos);

        // Obtener datos del kit
        $kit = new Kit();
        $datosKit = $kit->obtenerKitPorConductor($id_conductor);

        //var_dump($datosKit);

        // Obtener observaciones
        $observacion = new Observacion();
        $datosObservacion = $observacion->obtenerObservacionPorConductor($id_conductor);

        //var_dump($datosObservacion);

        // Combinar todos los datos
        $datosCombinados = array_merge(
            ['conductor' => $datosConductor],
            ['direccion' => $datosDireccion],
            ['contacto_emergencia' => $contactoEmergencia->toArray()],
            ['vehiculo' => $datosVehiculo],
            ['inscripcion' => $datosInscripcion],
            ['requisitos' => $estadoRequisitos],
            ['kit' => $datosKit],
            ['observacion' => $datosObservacion]
        );

        echo json_encode(['success' => true, 'data' => $datosCombinados]);
    }

    public function allConductorsva(){

        if (!isset($_GET['id']) || empty($_GET['id'])) {
            echo json_encode(['success' => false, 'message' => 'ID de conductor no proporcionado']);
            return;
        }
    
        $id_conductor = $_GET['id'];
    
        // Obtener datos del conductor
        $conductor = new Conductor();
        $conductor->setIdConductor($id_conductor);
        $datosConductor = $conductor->obtenerDatosEdit();
    
        if ($datosConductor === false) {
            echo json_encode(['success' => false, 'message' => 'Error al obtener datos del conductor']);
            return;
        }
    
        // Obtener observaciones
        $observacion = new Observacion();
        $datosObservacion = $observacion->obtenerObservacionPorConductor($id_conductor);
    
        // Filtrar solo los datos requeridos del conductor
        $datosFiltrados = [
            'nombres'          => $datosConductor['nombres'] ?? null,
            'apellido_paterno' => $datosConductor['apellido_paterno'] ?? null,
            'apellido_materno' => $datosConductor['apellido_materno'] ?? null,
            'correo'           => $datosConductor['correo'] ?? null,
            'observacion'      => $datosObservacion ?? null,
        ];
    
        echo json_encode(['success' => true, 'data' => $datosFiltrados]);

    }

    public function datoPagoConductor()
    {
        if (!isset($_GET['id']) || empty($_GET['id'])) {
            echo json_encode([]);
            return;
        }

        $id_conductor = intval($_GET['id']);

        
        $conductor = new Conductor();
        $datosPago = $conductor->obtenerDatosPago($id_conductor);

        if ($datosPago) {
            echo json_encode($datosPago);
        } else {
            echo json_encode([]);
        }
    }

    public function deleteInfoPagoConductor() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['id_conductor'])) {
            $id_conductor = intval($_POST['id_conductor']); // Sanitiza el ID
            $conductor = new Conductor();
            
            $resultado = $conductor->eliminarPago($id_conductor);

            echo json_encode([
                'success' => $resultado,
                'message' => $resultado ? 'Información eliminada correctamente' : 'Error al eliminar la información'
            ]);
        } else {
            echo json_encode([
                'success' => false,
                'message' => 'Solicitud no válida'
            ]);
        }
    }

    public function deleteConductor() {
        if ($_SERVER["REQUEST_METHOD"] === "POST") { // Verifica que la solicitud sea POST
            $id_conductor = $_POST["id_conductor"] ?? null; // Obtiene el ID del conductor

            if ($id_conductor) {
                $conductor = new Conductor(); // Instancia el modelo
                $resultado = $conductor->eliminarConductor($id_conductor); // Llama al método en el modelo y pasa el ID
    
                echo json_encode($resultado); 
                
            } else {
                echo json_encode(["success" => false, "message" => "No se recibió un ID válido"]);
            }
        } else {
            echo json_encode(["success" => false, "message" => "Método no permitido"]);
        }
    }
    
    public function generarDataBaseConductors() {
        $conductorModel = new Conductor();
        $conductores = $conductorModel->obtenerConductoresDataBase();

        $spreadsheet = new Spreadsheet();
        $sheet = $spreadsheet->getActiveSheet();

        // Encabezados
        $headers = ['ID', 'Tipo Doc', 'Nro Documento', 'Nombre Completo', 'Fecha Nacimiento', 'Categoría Licencia', 'Nro Licencia', 'Teléfono', 'Correo', 'Unidad', 'Condición', 'Vehículo Flota', 'Fecha SOAT', 'Fecha Seguro', 'Dirección', 'Placa', 'Marca', 'Modelo', 'Año', 'Color', 'Tipo Servicio', 'Tipo Pago', 'Monto', 'Cronograma de Pagos', 'Observaciones'];
        $sheet->fromArray([$headers], null, 'A1');

        // Aplicar estilo de centrado a los encabezados
         $sheet->getStyle('A1:Y1')->getAlignment()->setHorizontal(\PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_CENTER); // Centra los encabezados

        $rowIndex = 2;
        foreach ($conductores as $conductor) {
            $id = $conductor['id_conductor'];
            $nombreCompleto = $conductor['nombre_completo'];
            $datosPago = $conductorModel->obtenerDatosPago($id);

            $tipoPago = $datosPago['tipo_pago'] ?? '';
            $monto = isset($datosPago['monto_pago']) ? "S/" . number_format($datosPago['monto_pago'], 2) : '';
            $cronogramaPagos = '';

            if ($tipoPago === 'Financiamiento' && !empty($datosPago['cuotas'])) {
                $cronogramaPagos = "📌 Fecha V. - Monto\n";
                foreach ($datosPago['cuotas'] as $cuota) {
                    $cronogramaPagos .= $cuota['fecha_vencimiento'] . ' - S/' . number_format($cuota['monto_cuota'], 2) . "\n"; // Cambio 'monto' a 'monto_cuota'
                }
            } elseif ($tipoPago === 'Contado') {
                $cronogramaPagos = 'No aplica';
            }

            $sheet->setCellValue("A$rowIndex", $id);
            $sheet->setCellValue("B$rowIndex", $conductor['tipo_doc']);
            $sheet->setCellValue("C$rowIndex", $conductor['nro_documento']);
            $sheet->setCellValue("D$rowIndex", $nombreCompleto);
            $sheet->setCellValue("E$rowIndex", $conductor['fech_nac']);
            $sheet->setCellValue("F$rowIndex", $conductor['categoria_licencia']);
            $sheet->setCellValue("G$rowIndex", $conductor['nro_licencia']);
            $sheet->setCellValue("H$rowIndex", $conductor['telefono']);
            $sheet->setCellValue("I$rowIndex", $conductor['correo']);
            $sheet->setCellValue("J$rowIndex", $conductor['numUnidad']);
            $sheet->setCellValue("K$rowIndex", $conductor['condicion']);
            $sheet->setCellValue("L$rowIndex", $conductor['vehiculo_flota']);
            $sheet->setCellValue("M$rowIndex", $conductor['fech_soat']);
            $sheet->setCellValue("N$rowIndex", $conductor['fech_seguro']);
            $sheet->setCellValue("O$rowIndex", $conductor['direccion']);
            $sheet->setCellValue("P$rowIndex", $conductor['placa']);
            $sheet->setCellValue("Q$rowIndex", $conductor['marca']);
            $sheet->setCellValue("R$rowIndex", $conductor['modelo']);
            $sheet->setCellValue("S$rowIndex", $conductor['anio']);
            $sheet->setCellValue("T$rowIndex", $conductor['color']);
            $sheet->setCellValue("U$rowIndex", $conductor['tipo_servicio']);
            $sheet->setCellValue("V$rowIndex", $tipoPago);
            $sheet->setCellValue("W$rowIndex", $monto);
            $sheet->setCellValue("X$rowIndex", $cronogramaPagos);
            $sheet->setCellValue("Y$rowIndex", $conductor['observaciones']);
            
            $rowIndex++;
        }

        // Autoajustar el tamaño de las columnas
        foreach (range('A', 'Y') as $col) {
            $sheet->getColumnDimension($col)->setAutoSize(true);
        }

        // Aplicar alineación centrada a todas las celdas de datos
        $sheet->getStyle("A2:Y$rowIndex")->getAlignment()->setHorizontal(\PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_CENTER); // Centra todas las columnas

        // Generar contenido del archivo Excel en memoria
        ob_start(); // Captura el contenido en el buffer
        $writer = new Xlsx($spreadsheet);
        $writer->save('php://output');
        $excelContent = ob_get_clean(); // Obtiene el contenido generado

        // Convertir el archivo a base64
        $base64Excel = base64_encode($excelContent);

        // Retornar los datos como JSON
        echo json_encode([
            'excel' => $base64Excel,
            'nombre_excel' => 'Reporte_Conductores.xlsx'
        ]);
        exit();
    }
    
}
