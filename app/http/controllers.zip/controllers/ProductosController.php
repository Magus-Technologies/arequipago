<?php

require_once 'utils/lib/vendor/autoload.php';
require_once 'utils/lib/exel/vendor/autoload.php';
require_once 'utils/lib/code/vendor/autoload.php'; // 🔄 Ajustado para la ubicación correcta de Picqer


require_once 'app/models/TipoProductoModel.php';

require_once "app/models/Producto.php";

require_once "app/models/Productov2.php";

require_once "app/models/CategoriaProductoModel.php";

require_once "app/models/CaracteristicaProducto.php";

use Picqer\Barcode\BarcodeGeneratorPNG;

class ProductosController extends Controller
{
    private $conexion;
    private $c_producto;
    private $tipoProductoModel;

    public function __construct()
    {
        $this->conexion = (new Conexion())->getConexion();

    }

    public function getTiposProducto() {
        $tipos = new TipoProductoModel();
        $tipos = $tipos->obtenerTiposProducto();
        return json_encode($tipos);
    }

    public function guardarTipoProducto() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $tipoProducto = isset($_POST['tipo_producto']) ? trim($_POST['tipo_producto']) : '';
            $tipoVenta = isset($_POST['tipo_venta']) ? trim($_POST['tipo_venta']) : '';
    
            if (empty($tipoProducto)) {
                echo json_encode(['success' => false, 'message' => 'El campo tipo de producto está vacío.']);
                return;
            }

            if (empty($tipoVenta) || !in_array($tipoVenta, ['volumen', 'unidad'])) {
                echo json_encode(['success' => false, 'message' => 'El tipo de venta es inválido.']);
                return;
            }
    
            $model = new TipoProductoModel();

            $model->setTipoVenta($tipoVenta);

            $resultado = $model->guardarTipoProducto($tipoProducto);
    
            if ($resultado) {
                // Obtener el ID del nuevo tipo de producto
                $nuevoId = $model->getUltimoIdInsertado();
                echo json_encode([
                    'success' => true, 
                    'nuevoTipoProducto' => [
                        'idtipo_producto' => $nuevoId,
                        'tipo_productocol' => $tipoProducto,
                        'tipo_venta' => $tipoVenta
                    ]
                ]);
            } else {
                echo json_encode(['success' => false, 'message' => 'No se pudo guardar el tipo de producto.']);
            }
        }
    }

    public function guardarCategoriaProducto() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $categoriaProducto = isset($_POST['categoria_producto']) ? trim($_POST['categoria_producto']) : '';
    
            if (empty($categoriaProducto)) {
                echo json_encode(['success' => false, 'message' => 'El campo categoría de producto está vacío.']);
                return;
            }
    
            $model = new CategoriaProductoModel(); // Instanciar el modelo
    
            $resultado = $model->guardarCategoriaProducto($categoriaProducto); // Guardar la categoría
    
            if ($resultado) {
                // Obtener el ID de la nueva categoría
                $nuevoId = $model->getUltimoIdInsertado();
                echo json_encode([
                    'success' => true,
                    'nuevaCategoriaProducto' => [
                        'idcategoria_producto' => $nuevoId,
                        'nombre' => $categoriaProducto
                    ]
                ]);
            } else {
                echo json_encode(['success' => false, 'message' => 'No se pudo guardar la categoría de producto.']);
            }
        }
    }

    public function getCategoriasProducto() {
        $categoriaProducto = new CategoriaProductoModel();
        $categorias = $categoriaProducto->obtenerCategoriasProducto();
        echo json_encode($categorias);
    }
    
    

    public function obtenerTipoProducto() {
        // Recibir el tipo de producto desde la solicitud GET
        $tipoProducto = $_GET['tipoProducto'] ?? '';
    
        // Si el tipo de producto está vacío, devolver un error
        if (empty($tipoProducto)) {
            echo json_encode(['error' => 'Tipo de producto no especificado']);
            return;
        }
    
        // Crear una instancia del modelo TipoProductoModel
        $tipoProductoModel = new TipoProductoModel();
    
        // Obtener el tipo de venta basado en el tipo_productocol
        $tipoVenta = $tipoProductoModel->obtenerTipoVentaPorTipoProducto($tipoProducto);
    
        // Devolver la respuesta en formato JSON
        if ($tipoVenta) {
            echo json_encode(['tipo_venta' => $tipoVenta]);
        } else {
            echo json_encode(['error' => 'Tipo de producto no encontrado']);
        }
    }
    


    public function obtenerTodosProductos()
    {
        try {
            $productov2 = new Productov2();
            $productos = $productov2->obtenerTodos();

            // Filtrar productos para excluir aquellos con estado 0  
            $productos = array_filter($productos, function ($producto) {
                return $producto['estado'] != '0'; // Si el estado es 0, no se incluirá en la respuesta  
            });

            echo json_encode(array_values($productos)); 
        } catch (Exception $e) {
            http_response_code(500);
            echo json_encode(["error" => $e->getMessage()]);
        }
    }

    public function guardarProducto()
    {
        // Obtener los datos del POST
        $nombre = $_POST['nombre_producto'] ?? '';
        $tipo_producto = $_POST['tipo_producto'] ?? ''; // Obtener tipo_producto
        $codigo = $_POST['codigo_producto'] ?? null;
        $cantidad = $_POST['cantidad_producto'] ?? 0;
        $categoria = $_POST['categoria_producto'] ?? '';
        $ruc = $_POST['ruc'] ?? '';
        $razon_social = $_POST['razonsocial'] ?? '';
        $fecha_vencimiento = $_POST['fecha_vencimiento'] ?? null; // Obtener fecha_vencimiento
        // Nuevos campos
        $cantidad_unidad = $_POST['cantidad_unidad'] ?? null;
        $unidad_medida = $_POST['unidad_medida'] ?? null;
        $precio = $_POST['precio'] ?? null; // Nuevo campo: precio
        $fecha_registro = $_POST['fecha_registro'] ?? null; // Obtener fecha_registro desde el formulario
        $guia_remision = $_POST['guia_remision']?? null;
        $precio_venta = $_POST['precio_venta']?? null;
        
        $aro = $_POST['aro'] ?? null; // Nuevo campo: aro
        $perfil = $_POST['perfil'] ?? null; // Nuevo campo: perfil

        // Generar código de barras automáticamente si no se proporciona uno (Nuevo cambio)
        $codigo_barra = null;
        if (empty($codigo)) { 
            $codigo_barra = $this->generarCodigoBarrasUnico();
        }

        // Validar que no esté vacío
        if (empty($nombre) || empty($cantidad) || empty($categoria) || empty($ruc) || empty($razon_social) || empty($tipo_producto)) {
            echo json_encode(['status' => 'error', 'message' => 'Todos los campos obligatorios deben estar completos.']);
            return;
        }

        // Crear instancia del modelo
        $productoModel = new Productov2();

        // Insertar datos en la base de datos
    
        $productoData = [
            'nombre' => $nombre,
            'tipo_producto' => $tipo_producto,
            'codigo' => $codigo,
            'cantidad_unidad' => $cantidad_unidad,
            'unidad_medida' => $unidad_medida,
            'cantidad' => $cantidad,
            'categoria' => $categoria,
            'ruc' => $ruc,
            'razon_social' => $razon_social,
            'precio' => $precio,
            'fecha_vencimiento' => $fecha_vencimiento,
            'fecha_registro' => $fecha_registro,
            'guia_remision' => $guia_remision,
            'codigo_barra' => $codigo_barra, // Código de barras generado si no se proporcionó uno
            'precio_venta' => $precio_venta,
        ];

        // Ajustar para pasar datos en el orden correcto
        $idProducto = $productoModel->insertar( // Cambiado para capturar el ID del producto insertado
            $productoData['nombre'], 
            $productoData['codigo'], 
            $productoData['cantidad'], 
            $productoData['categoria'], 
            $productoData['ruc'], 
            $productoData['razon_social'], 
            $productoData['fecha_vencimiento'], 
            $productoData['fecha_registro'],
            $productoData['tipo_producto'], 
            $productoData['cantidad_unidad'], 
            $productoData['unidad_medida'], 
            $productoData['precio'],
            $productoData['guia_remision'],
            $productoData['codigo_barra'], 
            $productoData['precio_venta'],
        );

        

        // Procesar características adicionales según la categoría
        $caracteristicas = [];

        if ($categoria === 'Llantas') {
            $aro = $_POST['aro'] ?? null;
            $perfil = $_POST['perfil'] ?? null;
            if ($aro) {
                $caracteristicas[] = ['nombre_caracteristica' => 'aro', 'valor_caracteristica' => $aro];
            }
            if ($perfil) {
                $caracteristicas[] = ['nombre_caracteristica' => 'perfil', 'valor_caracteristica' => $perfil];
            }
        } elseif ($categoria === 'Chip (Linea corporativa)') {
            $plan_mensual = $_POST['plan_mensual'] ?? null;
            $operator = $_POST['operator']?? null;
            if ($plan_mensual) {
                $caracteristicas[] = ['nombre_caracteristica' => 'plan_mensual', 'valor_caracteristica' => $plan_mensual];
            }
            if ($operator){
                $caracteristicas[] = ['nombre_caracteristica' => 'operadora', 'valor_caracteristica' => $operator];
            }
        } elseif ($categoria === 'Celular') {
            $chip_linea = $_POST['chip_linea'] ?? null;
            $marca_equipo = $_POST['marca_equipo'] ?? null;
            $modelo = $_POST['modelo'] ?? null;
            $nro_imei = $_POST['nro_imei'] ?? null;
            $nro_serie = $_POST['nro_serie'] ?? null;
            $colorc = $_POST['colorc'] ?? null;
            $cargador = $_POST['cargador'] ?? null;
            $cable_usb = $_POST['cable_usb'] ?? null;
            $manual_usuario = $_POST['manual_usuario'] ?? null;
            $estuche = $_POST['estuche'] ?? null;
    
            if ($chip_linea) {
                $caracteristicas[] = ['nombre_caracteristica' => 'chip_linea', 'valor_caracteristica' => $chip_linea];
            }
            if ($marca_equipo) {
                $caracteristicas[] = ['nombre_caracteristica' => 'marca_equipo', 'valor_caracteristica' => $marca_equipo];
            }
            if ($modelo) {
                $caracteristicas[] = ['nombre_caracteristica' => 'modelo', 'valor_caracteristica' => $modelo];
            }
            if ($nro_imei) {
                $caracteristicas[] = ['nombre_caracteristica' => 'nro_imei', 'valor_caracteristica' => $nro_imei];
            }
            if ($nro_serie) {
                $caracteristicas[] = ['nombre_caracteristica' => 'nro_serie', 'valor_caracteristica' => $nro_serie];
            }
            if ($colorc) {
                $caracteristicas[] = ['nombre_caracteristica' => 'colorc', 'valor_caracteristica' => $colorc];
            }
            if ($cargador) {
                $caracteristicas[] = ['nombre_caracteristica' => 'cargador', 'valor_caracteristica' => $cargador];
            }
            if ($cable_usb) {
                $caracteristicas[] = ['nombre_caracteristica' => 'cable_usb', 'valor_caracteristica' => $cable_usb];
            }
            if ($manual_usuario) {
                $caracteristicas[] = ['nombre_caracteristica' => 'manual_usuario', 'valor_caracteristica' => $manual_usuario];
            }
            if ($estuche) {
                $caracteristicas[] = ['nombre_caracteristica' => 'estuche', 'valor_caracteristica' => $estuche];
            }
        }

        if (!empty($caracteristicas)) { // Cambiado: Validar si hay características para insertar
            $caracteristicaModel = new CaracteristicaProducto();
            foreach ($caracteristicas as $caracteristica) {
                $caracteristica['idproductosv2'] = $idProducto; 
                $caracteristicaModel->insertarCaracteristica($caracteristica);
            }
        }

        if ($idProducto) { 
            // Enviar respuesta exitosa con tipo de contenido json
            header('Content-Type: application/json'); // Asegurarse de que el tipo de contenido es JSON
            echo json_encode(['status' => 'success', 'message' => 'Producto guardado exitosamente.']); 
            exit;// Enviar respuesta de éxito
        } else {
            header('Content-Type: application/json'); // Asegurarse de que el tipo de contenido es JSON
            echo json_encode(['status' => 'error', 'message' => 'Error al guardar el producto.']); // Enviar respuesta de error
            exit;
        }
    }

    // Nueva función para generar un código de barras único sin generar imagen
    private function generarCodigoBarrasUnico()
    {
        do {
            $codigo = rand(100000000000, 999999999999); // Generar un número aleatorio de 12 dígitos
            $productoModel = new Productov2();
        } while ($productoModel->existeCodigoBarras($codigo)); // Verificar si el código ya existe en la BD
        
        return $codigo;
    }

    public function listaProducto()
    {
        $a_productos = $this->c_producto->obtenerProductos();

        // Se prepara un array con los datos de los productos
        $productos = [];
        while ($producto = $a_productos->fetch_assoc()) {
            $productos[] = [
                'id_producto'   => $producto['id_producto'],
                'nombre'        => $producto['nombre'],
                'cantidad'      => $producto['cantidad'],
                'razon_social'  => $producto['razon_social'],
                'ruc'           => $producto['ruc'],
                'codigo'        => $producto['codigo'],
                'tipo_producto' => $producto['tipo_producto'],
                'categoria'     => $producto['categoria'],
            ];
        }

        // Devolver los productos como un JSON
        echo json_encode($productos);
    }

    public function buscarProductos()
    {
        try {
            if (!isset($_GET['search']) || empty($_GET['search'])) {
                echo json_encode([]); // Si no hay término de búsqueda, devuelve un array vacío
                return;
            }

            $search = trim($_GET['search']);
            $productov2 = new Productov2();
            $productos = $productov2->buscarPorTermino($search); // Llamar al método del modelo
            
            // Filtrar productos para excluir aquellos con estado 0  
            $productos = array_filter($productos, function ($producto) {
                return $producto['estado'] == '1'; // Solo incluir productos con estado 1  
            });

            echo json_encode(array_values($productos)); // Devolver los productos encontrados
        } catch (Exception $e) {
            http_response_code(500);
            echo json_encode(["error" => $e->getMessage()]);
        }
    }

    public function agregarPorLista()
    {
        $lista = json_decode($_POST['lista'], true);
        $respuesta = ["res" => false];
        foreach ($lista as $item) {
            $afect = $item['afecto'] ? '1' : '0';

            $descripcion = $item['descripcicon'];
            $codigoProd = $item['codigoProd'];

            $sqlProducto = "SELECT * FROM productos where codigo = '$codigoProd' ";
            $producto =  $this->conexion->query($sqlProducto)->fetch_assoc();
            if ($producto) {
                $updateProducto = "UPDATE productos set descripcion= '$descripcion',
                                            precio='{$item['precio']}',
                                            precio2='{$item['precio2']}',
                                            precio3='{$item['precio3']}',
                                            precio4='{$item['precio4']}',
                                            almacen='{$item['almacen']}',
                                            precio_unidad='{$item['precio_unidad']}',
                                            costo='{$item['costo']}',
                                            cantidad='{$item['cantidad']}',
                                            codsunat='{$item['codSunat']}'
                                    where 
                                    codigo='$codigoProd' ";
                $this->conexion->query($updateProducto);
                $respuesta["res"] = true;
            } else {
                $sql = "insert into productos set descripcion=?,
                precio='{$item['precio']}',
                precio2='{$item['precio2']}',
                precio3='{$item['precio3']}',
                precio4='{$item['precio4']}',
                almacen='{$item['almacen']}',
                precio_unidad='{$item['precio_unidad']}',
                costo='{$item['costo']}',
                cantidad='{$item['cantidad']}',
                iscbp='$afect',
                id_empresa='{$_SESSION['id_empresa']}',
                ultima_salida='1000-01-01',
                sucursal='{$_SESSION['sucursal']}',
                codsunat='{$item['codSunat']}',
                codigo=?";

                $stmt = $this->conexion->prepare($sql);
                $stmt->bind_param('ss', $descripcion, $codigoProd);
                /*   $stmt->bind_param('s', $codigoProd); */

                if ($stmt->execute()) {
                    $respuesta["res"] = true;
                }
            }
        }
        return json_encode($respuesta);
    }

    public function importarExel()
    {
        $respuesta = ["res" => false];
        $filename = $_FILES['file']['name'];

        $path_parts = pathinfo($filename, PATHINFO_EXTENSION);
        $newName = Tools::getToken(80);
        /* Location */
        $loc_ruta = "files/temp";
        if (!file_exists($loc_ruta)) {
            mkdir($loc_ruta, 0777, true);
        }
        $location = $loc_ruta . "/" . $newName . '.' . $path_parts;
        if (move_uploaded_file($_FILES['file']['tmp_name'], $location)) {
            $nombre_logo = $newName . "." . $path_parts;

            $respuesta["res"] = true;
            $type = $path_parts;

            // Selección del lector según el tipo de archivo
            if ($type == "xlsx") {
                $reader = new \PhpOffice\PhpSpreadsheet\Reader\Xlsx();
            } elseif ($type == "xls") {
                $reader = new \PhpOffice\PhpSpreadsheet\Reader\Xls();
            } elseif ($type == "csv") {
                $reader = new \PhpOffice\PhpSpreadsheet\Reader\Csv();
            }

            // Lectura de datos del archivo
            $reader->setReadDataOnly(true);
            $spreadsheet = $reader->load("files/temp/" . $nombre_logo);
            $data = $spreadsheet->getActiveSheet()->toArray();

            array_shift($data); // Esta línea elimina la primera fila (cabecera) del archivo Excel

            // Procesamiento de los datos
            $productos = [];
            foreach ($data as $row) {

                $fecha_vencimiento = $row[9];
                if ($fecha_vencimiento) {
                    // Convertir la fecha a formato YYYY-MM-DD si es necesario
                    // Excel almacena las fechas como números (ej. 41609), así que convertimos a una fecha válida
                    if (is_numeric($fecha_vencimiento)) {
                        // Convertir el número de Excel a una fecha en formato 'Y-m-d'
                        $fecha_vencimiento = date('Y-m-d', ($fecha_vencimiento - 25569) * 86400); // Excel fecha base: 1900-01-01
                    }
                }

                error_log("Fecha de vencimiento convertida: " . $fecha_vencimiento); // Esto 
                
                $productos[] = [
                    'nombre' => $row[0],           // Nombre del producto
                    'codigo' => $row[1],           // Código del producto
                    'cantidad' => $row[2],         // Cantidad
                    'cantidad_unidad' => $row[3],  // Cantidad por unidad
                    'unidad_medida' => $row[4],    // Unidad de medida
                    'tipo_producto' => $row[5],    // Tipo de producto
                    'perfil' => $row[6],        // Categoría
                    'aro' => $row[7], // Fecha de vencimiento
                    'categoria' => $row[8],              // RUC
                    'fecha_vencimiento' => $fecha_vencimiento,      // Razón social
                    'ruc' => $row[10] ?? null,  // Perfil (nuevo campo, puede ser null)
                    'razon_social' => $row[11] ?? null,
                    'precio' => $row[12] ?? null
                ];
            }

            // Llamar a la función para insertar los productos en la base de datos
            $this->insertarProductos($productos);

            // Eliminar archivo temporal
            unlink($location);

            $respuesta["data"] = $productos; // Respuesta con los productos procesados
        }

        return json_encode($respuesta);
    }

    // Función para insertar productos en la base de datos
    private function insertarProductos($productos)
    {
        // Crear una instancia del modelo Productov2
        $productoModel = new Productov2();

        // Insertar cada producto en la base de datos
        foreach ($productos as $producto) {
            // Aquí pasamos los datos a la función insertar del modelo
            $productoModel->insertar(
                $producto['nombre'],
                $producto['codigo'],
                $producto['cantidad'],
                $producto['categoria'],
                $producto['ruc'],
                $producto['razon_social'],
                $producto['fecha_vencimiento'],
                $producto['tipo_producto'],
                $producto['cantidad_unidad'],
                $producto['unidad_medida'],
                $producto['perfil'],  // Nuevo campo
                $producto['aro'],      // Nuevo campo
                $producto['precio']
            );
        }
    }



    public function restock()
    {
        $respuesta = ["res" => false];
        $sql = "update productos set cantidad=cantidad+{$_POST['cantidad']} where id_producto='{$_POST['cod']}'";
        //echo $sql;
        if ($this->conexion->query($sql)) {
            $respuesta["res"] = true;
        }
        return json_encode($respuesta);
    }
    public function informacionPorCodigo()
    {
        $respuesta = ["res" => false];
        $sql = "SELECT * FROM productos where trim(codigo)='{$_POST['code']}' AND almacen = '{$_POST['almacen']}' and sucursal='{$_SESSION['sucursal']}'";

        if ($row = $this->conexion->query($sql)->fetch_assoc()) {
            $respuesta["res"] = true;
            $respuesta["data"] = $row;
        }
        return json_encode($respuesta);
    }
    public function informacion()
    {
        $respuesta = ["res" => false];
        $sql = "SELECT * FROM productos where id_producto='{$_POST['cod']}'";
        if ($row = $this->conexion->query($sql)->fetch_assoc()) {
            $respuesta["res"] = true;
            $respuesta["data"] = $row;
        }
        return json_encode($respuesta);
    }
    public function agregar()
    {
        $respuesta = ["res" => false];
        $descripcion = $_POST['descripcicon'];
        $codigoProd = $_POST['codigo'];
        for ($i=1; $i < 3; $i++) { 
            $sql = "insert into productos set descripcion=?,
            precio='{$_POST['precio']}',
            costo='{$_POST['costo']}',
            almacen='{$i}',
            cantidad='{$_POST['cantidad']}',
            iscbp='{$_POST['afecto']}',
              sucursal='{$_SESSION['sucursal']}',
            id_empresa='{$_SESSION['id_empresa']}',
            ultima_salida='1000-01-01',
            codsunat='{$_POST['codSunat']}',
            precio_mayor={$_POST['precioMayor']},precio_menor={$_POST['precioMenor']},razon_social='{$_POST['razon']}',ruc='{$_POST['ruc']}',codigo=?
            ";
          
                  $stmt = $this->conexion->prepare($sql);
                  $stmt->bind_param('ss', $descripcion, $codigoProd);
                  /*   $stmt->bind_param('s', $codigoProd); */
          
                  if ($stmt->execute()) {
                      $respuesta["res"] = true;
                  }
        }
      
        return json_encode($respuesta);
    }
    public function actualizar()
    {
        $respuesta = ["res" => false];
        $descripcion = $_POST['descripcicon'];
        $codigoProd = $_POST['codigo'];

        $sql="select * from productos where id_producto='{$_POST['cod']}'";
        $result = $this->conexion->query($sql);
        if ($row= $result->fetch_assoc()){
            $almacenTemp = $row["almacen"]=="1"?2:1;
            $sql = "update productos set descripcion=?,
                     cod_barra='',
                     usar_barra='{$_POST['usar_barra']}',
                  precio='{$_POST['precio']}',
                  costo='{$_POST['costo']}',
                  iscbp='{$_POST['afecto']}',
                  codsunat='{$_POST['codSunat']}',precio_mayor={$_POST['precioMayor']},precio_menor={$_POST['precioMenor']},razon_social='{$_POST['razon']}',ruc='{$_POST['ruc']}',
                  codigo=?
                  where descripcion=? and almacen='$almacenTemp'";
            $stmt = $this->conexion->prepare($sql);
            $stmt->bind_param('sss', $descripcion, $codigoProd,$row['descripcion']);
            /*   $stmt->bind_param('s', $codigoProd); */

            if(!$stmt->execute()){
                var_dump($stmt->error);
            }

        }

        /*   $sql = "insert into productos set descripcion=?, */
        $sql = "update productos set descripcion=?,
                     cod_barra='',
                     usar_barra='{$_POST['usar_barra']}',
  precio='{$_POST['precio']}',
  costo='{$_POST['costo']}',
  iscbp='{$_POST['afecto']}',
  cantidad='{$_POST['cantidad']}',
  codsunat='{$_POST['codSunat']}',precio_mayor={$_POST['precioMayor']},precio_menor={$_POST['precioMenor']},razon_social='{$_POST['razon']}',ruc='{$_POST['ruc']}',
  codigo=?
  where id_producto='{$_POST['cod']}'";

        $stmt = $this->conexion->prepare($sql);
        $stmt->bind_param('ss', $descripcion, $codigoProd);
        /*   $stmt->bind_param('s', $codigoProd); */

        if ($stmt->execute()) {
            $respuesta["res"] = true;


        }
        return json_encode($respuesta);
    }

    public function actualizarPrecios()
    {
        $respuesta = ["res" => false];
        $sql = "update productos set precio='{$_POST['precio']}',precio_unidad='{$_POST['precio_unidad']}', precio2='{$_POST['precio2']}', precio3='{$_POST['precio3']}', precio4='{$_POST['precio4']}' where id_producto='{$_POST['cod_prod']}'";
        if ($this->conexion->query($sql)) {
            $respuesta["res"] = true;
            $sql="select * from productos where id_producto='{$_POST['cod_prod']}'";
            $result = $this->conexion->query($sql);
            if ($row= $result->fetch_assoc()){
                $almacenTemp = $row["almacen"]=="1"?2:1;
                $sql = "update productos set 
                     precio='{$_POST['precio']}',precio_unidad='{$_POST['precio_unidad']}', 
                     precio2='{$_POST['precio2']}', precio3='{$_POST['precio3']}', 
                     precio4='{$_POST['precio4']}'
                  where descripcion=? and almacen='$almacenTemp'";
                $stmt = $this->conexion->prepare($sql);
                $stmt->bind_param('s', $row['descripcion']);
                /*   $stmt->bind_param('s', $codigoProd); */

                if(!$stmt->execute()){
                }


            }
        }
        return json_encode($respuesta);
    }
    public function confirmarTraslado()
    {
        $respuesta['res'] = false;
        $sql = "SELECT id_producto,almacen_ingreso,almacen_egreso,cantidad FROM ingreso_egreso WHERE intercambio_id ='{$_POST['cod']}'";
        $result = $this->conexion->query($sql)->fetch_assoc();

        $almacen = $result['almacen_ingreso'];
        $id_producto = $result['id_producto'];
        $cantidad = $result['cantidad'];

        $sql = "SELECT * FROM productos WHERE id_producto = '{$result['id_producto']}'";
        $result = $this->conexion->query($sql)->fetch_assoc();


        $sql = "SELECT * FROM productos WHERE descripcion = '{$result['descripcion']}' AND almacen = '$almacen'";
        $result2 = $this->conexion->query($sql)->fetch_assoc();


        if (is_null($result2)) {
            $sql = "INSERT INTO productos 
            (cod_barra, descripcion, precio, costo,cantidad,iscbp,id_empresa,sucursal,ultima_salida,codsunat,usar_barra,precio_mayor,precio_menor,razon_social,ruc,estado,almacen,precio2,precio3)
            SELECT cod_barra, descripcion, precio, costo,$cantidad,iscbp,id_empresa,sucursal,ultima_salida,codsunat,usar_barra,precio_mayor,precio_menor,razon_social,ruc,estado, $almacen,precio2,precio3
            FROM productos
            WHERE id_producto = $id_producto";
            if ($this->conexion->query($sql)) {
                $sql = "UPDATE productos set cantidad = cantidad - $cantidad   WHERE id_producto = $id_producto";
                if ($this->conexion->query($sql)) {
                    $respuesta['res'] = true;
                }
            }
        } else {
            $idExistente = $result2['id_producto'];
            $sql2 = "UPDATE  productos set cantidad =  cantidad - $cantidad  WHERE id_producto = $id_producto";
            if ($this->conexion->query($sql2)) {
                $sql = "UPDATE  productos set cantidad = cantidad + $cantidad   WHERE id_producto = $idExistente";
                if ($this->conexion->query($sql)) {
                    $respuesta['res'] = true;
                }
            }
        }
        if ($respuesta['res']) {
            $sql = "UPDATE  ingreso_egreso set estado = 1   WHERE intercambio_id = '{$_POST['cod']}'";
            if ($this->conexion->query($sql)) {
                $respuesta['res'] = true;
            }
        }
        echo json_encode($respuesta);
    }

    public function delete()
    {
        $respuesta["res"] = true;
        $respuesta["data"] = $_POST;
        $sql = '';
        foreach ($respuesta["data"]['arrayId'] as $ids) {
            /*   $sql .= $ids; */

            $sql = "UPDATE   productos set estado=0 where id_producto = '{$ids['id']}'";
            if ($this->conexion->query($sql)) {
                $respuesta["res"] = true;
            }
        }
        return json_encode($respuesta);
    }

    private function enviarRespuesta($success, $message, $data = []) // Función reutilizable para enviar respuestas JSON
    {
        $response = [
            'success' => $success, // Indicar si la operación fue exitosa
            'message' => $message, // Mensaje de la operación
            'data' => $data // Datos adicionales (opcional)
        ];

        if (!$success) {
            error_log("Error en la respuesta: " . $message); // Registrar errores en el log
        }

        header('Content-Type: application/json'); // Establecer el encabezado como JSON
        echo json_encode($response); // Codificar la respuesta como JSON
        exit; // Terminar la ejecución
    }

    public function saveProductsMassive()
    {
        try {
            $this->validateInputs();
            $spreadsheet = $this->loadSpreadsheet();
            $sheetProductos = $this->getProductSheet($spreadsheet);
            
            $deletedProducts = json_decode($_POST['deletedProducts'], true);
            $this->removeDeletedProducts($sheetProductos, $deletedProducts);

            $this->validateProductData($sheetProductos);


            $productosRestantes = $this->processRemainingProducts($sheetProductos);
            $idsProductos = $this->saveProducts($productosRestantes);
            
            
            $sheetCaracteristicas = $spreadsheet->getSheetByName('Características');
            //var_dump('Hoja Características:', $sheetCaracteristicas);
            if ($sheetCaracteristicas) {
                $this->removeDeletedCharacteristics($sheetCaracteristicas, $deletedProducts);
             
                $this->validateCharacteristicsData($sheetCaracteristicas);
                $this->saveCharacteristics($sheetCaracteristicas, $idsProductos);
            } else {
                throw new \Exception('La hoja "Características" no existe en el archivo Excel.');
            }
            
            $this->enviarRespuesta(true, 'Productos y características importados exitosamente.'); // Modificación: Usar enviarRespuesta para éxito
        } catch (\Exception $e) {
            echo json_encode(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    private function validateInputs()
    {
        if (!isset($_FILES['file']) || $_FILES['file']['error'] !== UPLOAD_ERR_OK) {
            throw new \Exception('Archivo inválido o no recibido.');
        }
        if (!isset($_POST['deletedProducts']) || empty($_POST['deletedProducts'])) {
            throw new \Exception('No se recibieron códigos de productos para eliminar.');
        }
    }

    private function loadSpreadsheet()
    {
        $file = $_FILES['file']['tmp_name'];
        return \PhpOffice\PhpSpreadsheet\IOFactory::load($file);
    }

    private function getProductSheet($spreadsheet)
    {
        $sheetProductos = $spreadsheet->getSheetByName('Productos');
        if (!$sheetProductos) {
            throw new \Exception('La hoja "Productos" no existe en el archivo Excel.');
        }
        return $sheetProductos;
    }

    private function removeDeletedProducts($sheet, $deletedProducts)
    {
        $highestRow = $sheet->getHighestRow();
        for ($row = $highestRow; $row >= 2; $row--) {
            $codigo = $sheet->getCellByColumnAndRow(2, $row)->getValue();
            if (in_array($codigo, $deletedProducts)) {
                $sheet->removeRow($row);
            }
        }
    }

    private function processRemainingProducts($sheet)
    {
        $productosRestantes = [];
        $highestRow = $sheet->getHighestRow();
        for ($row = 2; $row <= $highestRow; $row++) {
            $producto = [
                'nombre' => $sheet->getCellByColumnAndRow(1, $row)->getValue(),
                'codigo' => $sheet->getCellByColumnAndRow(2, $row)->getValue(),
                'cantidad' => $sheet->getCellByColumnAndRow(3, $row)->getValue(),
                'cantidad_unidad' => $sheet->getCellByColumnAndRow(4, $row)->getValue(),
                'unidad_medida' => $sheet->getCellByColumnAndRow(5, $row)->getValue(), // Cambiado de 'unidadMedida' a 'unidad_medida'
                'tipo_producto' => $sheet->getCellByColumnAndRow(6, $row)->getValue(),
                'categoria' => $sheet->getCellByColumnAndRow(7, $row)->getValue(),
                'fecha_vencimiento' => $sheet->getCellByColumnAndRow(8, $row)->getValue(),
                'ruc' => $sheet->getCellByColumnAndRow(9, $row)->getValue(),
                'razon_social' => $sheet->getCellByColumnAndRow(10, $row)->getValue(),
                'precio' => $sheet->getCellByColumnAndRow(11, $row)->getValue(),
                'precio_venta' =>$sheet->getCellByColumnAndRow(12, $row)->getValue(),
                'fecha_registro' => $sheet->getCellByColumnAndRow(13, $row)->getValue(),
                'guia_remision' => $sheet->getCellByColumnAndRow(14, $row)->getValue()
            ];
            $productosRestantes[] = $producto; 
            
           // var_dump($productosRestantes);
            //var_dump($producto);
            
            // Eliminada la línea duplicada
        }
        return $productosRestantes;
    }
    
    private function saveProducts($productos)
    {
        $productoModel = new ProductoV2();
        $result = $productoModel->guardarProductosMasivos($productos);
        if ($result === false) {
            throw new \Exception('Error al guardar los productos en la base de datos.');
        }
       
        return $result;
    }

    private function removeDeletedCharacteristics($sheet, $deletedProducts)
    {
        $highestRow = $sheet->getHighestRow();
        for ($row = $highestRow; $row >= 2; $row--) {
            $codigoCaracteristica = $sheet->getCellByColumnAndRow(1, $row)->getValue();
            if (in_array($codigoCaracteristica, $deletedProducts)) {
                $sheet->removeRow($row);
            }
        }
    }

    private function validateProductData($sheet)
    {
        $highestRow = $sheet->getHighestRow();
        for ($row = 2; $row <= $highestRow; $row++) {
            $this->validateProductRow($sheet, $row);
        }
    }

    private function validateProductRow($sheet, $row)
    {
        $cantidad = $sheet->getCellByColumnAndRow(3, $row)->getValue();
        $cantidadUnidad = $sheet->getCellByColumnAndRow(4, $row)->getValue();
        $fechaVencimiento = $sheet->getCellByColumnAndRow(8, $row)->getValue();
        $ruc = $sheet->getCellByColumnAndRow(9, $row)->getValue();
        $precioVenta = $sheet->getCellByColumnAndRow(11, $row)->getValue();
        $fechaRegistro = $sheet->getCellByColumnAndRow(12, $row)->getValue();

        if (!is_numeric($cantidad)) {
            throw new \Exception("Cantidad inválida en la fila $row.");
        }
        if (!is_numeric($cantidadUnidad) && !empty($cantidadUnidad)) {
            throw new \Exception("Cantidad por unidad inválida en la fila $row.");
        }
        $this->validateDate($fechaVencimiento, "Fecha de vencimiento", $row);
        
        if (!empty($ruc) && (!is_numeric($ruc) || strlen($ruc) !== 11)) { // Modificado: Permitir RUC vacío y validar solo si tiene valor
            throw new \Exception("RUC inválido en la fila $row.");
        }
        
        if (empty($ruc)) { // Modificado: Si el RUC está vacío, guardarlo como null
            $ruc = null;
        }

        if (!empty($precioVenta) && !is_numeric($precioVenta)) { // Modificado: Validar precio solo si tiene valor
            throw new \Exception("Precio de venta inválido en la fila $row.");
        }
        
        if (empty($precioVenta)) { // Modificado: Si el precio está vacío, guardarlo como null
            $precioVenta = null;
        }
    
        $this->validateRegistrationDate($fechaRegistro, $row);
    }

    private function validateDate($date, $fieldName, $row)
    {
        if (!empty($date)) {
            if (is_numeric($date)) {
                $date = \DateTime::createFromFormat('!d-m-Y', gmdate('d-m-Y', ($date - 25569) * 86400));
            } else {
                $date = \DateTime::createFromFormat('Y-m-d', $date);
            }
            if (!$date) {
                throw new \Exception("$fieldName inválida en la fila $row.");
            }
        }
    }

    private function validateRegistrationDate($date, $row)
    {
        if (empty($date)) {
            throw new \Exception("La fecha de registro es obligatoria en la fila $row.");
        }
        $this->validateDate($date, "Fecha de registro", $row);
        $fechaRegistro = is_numeric($date) 
            ? \DateTime::createFromFormat('!d-m-Y', gmdate('d-m-Y', ($date - 25569) * 86400))
            : \DateTime::createFromFormat('Y-m-d', $date);
        
        $fechaActual = new \DateTime();
        $fechaDosDiasFuturo = (clone $fechaActual)->modify('+2 days');
        
        if ($fechaRegistro > $fechaDosDiasFuturo) {
            throw new \Exception("Fecha de registro no puede ser mayor a dos días en el futuro en la fila $row.");
        }
    }

    private function validateCharacteristicsData($sheet)
    {
        $highestRow = $sheet->getHighestRow();
        for ($row = 2; $row <= $highestRow; $row++) {
            $caracteristica = $sheet->getCellByColumnAndRow(3, $row)->getValue();
            if (empty($caracteristica)) {
                throw new \Exception("Característica vacía en la fila $row de la hoja 'Características'.");
            }
        }
    }

    private function saveCharacteristics($sheet, $idsProductos)
    {
      
        $caracteristicas = [];
        $highestRow = $sheet->getHighestRow();
        for ($row = 2; $row <= $highestRow; $row++) {
            $codigoProducto = $sheet->getCellByColumnAndRow(1, $row)->getValue();
            $nombreCaracteristica = $sheet->getCellByColumnAndRow(3, $row)->getValue();
            $valorCaracteristica = $sheet->getCellByColumnAndRow(4, $row)->getValue();
    
           
    
            if (isset($idsProductos[$codigoProducto])) {
                $idProducto = $idsProductos[$codigoProducto];
                $caracteristicas[] = [
                    'idproductosv2' => $idProducto,
                    'nombre_caracteristicas' => $nombreCaracteristica,
                    'valor_caracteristica' => $valorCaracteristica,
                ];
            } else {
                var_dump("No se encontró ID para el producto con código: $codigoProducto");
            }
        }
    
        //var_dump('Características a guardar: ', $caracteristicas);
    
        if (!empty($caracteristicas)) {
            $caracteristicaModel = new CaracteristicaProducto();
            $result = $caracteristicaModel->guardarCaracteristicasMasivas($caracteristicas);
            if ($result === false) {
                throw new \Exception('Error al guardar las características en la base de datos.');
            }
        } else {
           
        }
    }

    public function downloadReport()
    {

        $spreadsheet = new \PhpOffice\PhpSpreadsheet\Spreadsheet();
     
        $sheet = $spreadsheet->getActiveSheet();

        // Definir las cabeceras del archivo Excel
        $headers = [
            'ID Producto', 'Nombre', 'Código', 'Cantidad', 'Cantidad Unidad', 
            'Unidad de Medida', 'Tipo de Producto', 'Categoría', 'Fecha de Vencimiento',
            'RUC', 'Razón Social', 'Precio', 'Precio Total', 'Fecha de Registro', 
            'Guía de Remisión', 'Texto de Cabecera'
        ];

        // Escribir las cabeceras en la primera fila
        $columnIndex = 1;
        foreach ($headers as $header) {
            $sheet->setCellValueByColumnAndRow($columnIndex, 1, $header);
            $columnIndex++;
        }

        $sheet->getColumnDimension('A')->setWidth(15); // ID Producto
        $sheet->getColumnDimension('B')->setWidth(30); // Nombre
        $sheet->getColumnDimension('C')->setWidth(20); // Código
        $sheet->getColumnDimension('D')->setWidth(15); // Cantidad
        $sheet->getColumnDimension('E')->setWidth(20); // Cantidad Unidad
        $sheet->getColumnDimension('F')->setWidth(20); // Unidad de Medida
        $sheet->getColumnDimension('G')->setWidth(20); // Tipo de Producto
        $sheet->getColumnDimension('H')->setWidth(20); // Categoría
        $sheet->getColumnDimension('I')->setWidth(20); // Fecha de Vencimiento
        $sheet->getColumnDimension('J')->setWidth(20); // RUC
        $sheet->getColumnDimension('K')->setWidth(30); // Razón Social
        $sheet->getColumnDimension('L')->setWidth(15); // Precio
        $sheet->getColumnDimension('M')->setWidth(20); // Precio Total
        $sheet->getColumnDimension('N')->setWidth(20); // Fecha de Registro
        $sheet->getColumnDimension('O')->setWidth(20); // Guía de Remisión
        $sheet->getColumnDimension('P')->setWidth(30); // Texto de Cabecera

       

        // Llamar al modelo para obtener los datos
        $productoModel = new Productov2();
        $productos = $productoModel->reporteProducts();
        
        // Escribir los datos en el archivo Excel
        $rowIndex = 2; // Comenzar desde la segunda fila
        foreach ($productos as $producto) {
            $sheet->setCellValue('A' . $rowIndex, $producto['idproductosv2']);
            $sheet->setCellValue('B' . $rowIndex, $producto['nombre']);
            $sheet->setCellValue('C' . $rowIndex, $producto['codigo']);
            $sheet->setCellValue('D' . $rowIndex, $producto['cantidad']);
            $sheet->setCellValue('E' . $rowIndex, $producto['cantidad_unidad']);
            $sheet->setCellValue('F' . $rowIndex, $producto['unidad_medida']);
            $sheet->setCellValue('G' . $rowIndex, $producto['tipo_producto']);
            $sheet->setCellValue('H' . $rowIndex, $producto['categoria']);
            $sheet->setCellValue('I' . $rowIndex, $producto['fecha_vencimiento']);
            $sheet->setCellValue('J' . $rowIndex, $producto['ruc']);
            $sheet->setCellValue('K' . $rowIndex, $producto['razon_social']);
            $sheet->setCellValue('L' . $rowIndex, $producto['precio']);
            $sheet->setCellValue('M' . $rowIndex, $producto['cantidad'] * $producto['precio']); // Precio Total
            $sheet->setCellValue('N' . $rowIndex, $producto['fecha_registro']);
            $sheet->setCellValue('O' . $rowIndex, $producto['guia_remision']);
            $sheet->setCellValue('P' . $rowIndex, $producto['texto_cabecera']); // Texto de Cabecera
            $rowIndex++;
        }

        // Alinear la columna "ID Producto" (columna A) a la izquierda
        $sheet->getStyle('A2:A' . ($rowIndex - 1)) // Solo la columna "ID Producto" desde la fila 2 hasta la última
        ->getAlignment()
        ->setHorizontal(\PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_LEFT); // Alinear a la izquierda

        // Alinear todo el contenido a partir de la fila 2 a centrado
        for ($row = 2; $row <= $rowIndex - 1; $row++) {
            $sheet->getStyle('A' . $row . ':P' . $row) // Desde la columna A hasta la P
                ->getAlignment()
                ->setHorizontal(\PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_CENTER); // Alinear a la centrado
        }

        // Preparar el archivo para la descarga
        $writer = \PhpOffice\PhpSpreadsheet\IOFactory::createWriter($spreadsheet, "Xlsx");
        $fileName = 'reporte_inventario.xlsx';

        // Limpiar cualquier salida previa
        ob_end_clean(); // Añadido: Limpiar el buffer de salida
    
        // Configurar las cabeceras de la respuesta
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment; filename="' . $fileName . '"'); // Modificado: Añadido espacio después de 'attachment;'
        header('Cache-Control: max-age=0');

        // Enviar el archivo Excel al navegador
        $writer->save('php://output'); // Guardar el archivo en el buffer de salida

        exit; // Se asegura de que no haya más salida posterior

    }

    public function generateBarCode($codigo)
    {
        // ✅ Verificar si se recibió el código por GET
        if (!isset($_GET['codigo']) || empty($_GET['codigo'])) { 
            echo json_encode(["error" => "Código no proporcionado"]); // ✅ Reemplaza response()->json() por json_encode()
            return;
        }

        $codigo = $_GET['codigo']; // ✅ Obtiene el código desde la petición GET

        $generator = new BarcodeGeneratorPNG(); // Inicializa el generador de códigos de barras
        $barcode = $generator->getBarcode($codigo, $generator::TYPE_CODE_128); // Genera el código de barras tipo 128
        
        $barcodeBase64 = base64_encode($barcode); // ✅ Convierte la imagen en base64
        $imageUrl = 'data:image/png;base64,' . $barcodeBase64;
    
        echo json_encode(['image' => $imageUrl]); // ✅ Reemplaza response()->json() por json_encode()

    }

    public function getBarCode()
    {
        // Verificar si se recibió el ID del producto
        if (!isset($_GET['id_producto']) || empty($_GET['id_producto'])) {
            echo json_encode(["error" => "ID de producto no proporcionado"]);
            return;
        }

        $id_producto = $_GET['id_producto'];

        $productoModel = new Productov2();

        // Obtener el código de barras del producto
        $codigo = $productoModel->getCodeBar($id_producto);

        // Devolver la respuesta en formato JSON
        echo json_encode(["codigo" => $codigo]);
    }

    public function getdataForBarcode()
    {
        if (!isset($_GET["codigo"])) {
            echo json_encode(["success" => false, "message" => "Código no recibido"]);
            return;
        }

        $codigo = trim($_GET["codigo"]); 
        //var_dump($codigo);
        $productoModel = new Productov2();
        $producto = $productoModel->getdataForBarcode($codigo);

        if ($producto) {
            // Solo enviar los datos necesarios al frontend
            echo json_encode([
                "success" => true,
                "nombre" => $producto["nombre"],
                "precio" => $producto["precio"]
            ]);
        } else {
            echo json_encode(["success" => false, "message" => "Producto no encontrado"]);
        }
    }
    
    public function deleteProducts() {
        // Verificar si se recibieron datos mediante POST
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            // Obtener el JSON enviado desde la petición AJAX
            $data = json_decode(file_get_contents("php://input"), true);
            
            // Verificar si el array 'ids' está presente y no está vacío
            if (!isset($data['ids']) || empty($data['ids'])) {
                echo json_encode(["status" => "error", "message" => "No se recibieron productos para eliminar."]);
                return;
            }

            $productoModel = new Productov2();

            // Llamar al método eliminarProducts() y pasarle los IDs
            $resultado = $productoModel->eliminarProducts($data['ids']);

            // Verificar si la eliminación fue exitosa
            if ($resultado) {
                echo json_encode(["status" => "success", "message" => "Productos eliminados correctamente."]);
            } else {
                echo json_encode(["status" => "error", "message" => "Hubo un problema al eliminar los productos."]);
            }
        } else {
            // Respuesta en caso de que no sea una petición POST válida
            echo json_encode(["status" => "error", "message" => "Método no permitido."]);
        }
    }

    public function obtenerDatosProducto() {
        // Verificar si se recibió el ID por POST
        if (!isset($_POST['id']) || empty($_POST['id'])) {
            echo json_encode(["error" => "ID de producto no proporcionado"]);
            return;
        }

        $id_producto = intval($_POST['id']); // Sanitizar el ID

        // Instanciar el modelo
        $productoModel = new Productov2();

        // Obtener los datos del producto
        $producto = $productoModel->obtenerProductoPorId($id_producto);

        // Instanciar el modelo de características del producto // NUEVO CAMBIO
        $caracteristicasModel = new CaracteristicaProducto(); 

        // Obtener las características del producto usando el ID // NUEVO CAMBIO
        $caracteristicas = $caracteristicasModel->obtenerCaracteristicas($id_producto);

        if ($producto) {
            // Retornar los datos del producto junto con sus características // NUEVO CAMBIO
            echo json_encode([
                "producto" => $producto,
                "caracteristicas" => $caracteristicas 
            ]);
        } else {
            echo json_encode(["error" => "Producto no encontrado"]);
        }
    }

    public function getEditsSeletProducto()
    {
        // Instanciar los modelos
        $tipoProductoModel = new TipoProductoModel();
        $categoriaProductoModel = new CategoriaProductoModel();

        // Obtener datos desde los modelos
        $tiposProducto = $tipoProductoModel->obtenerTiposProducto();
        $categoriasProducto = $categoriaProductoModel->obtenerCategoriasProducto();

        // Estructurar la respuesta como JSON
        $response = [
            'tiposProducto' => $tiposProducto,
            'categorias' => $categoriasProducto
        ];

        // Devolver respuesta JSON
        echo json_encode($response);
    }


}
