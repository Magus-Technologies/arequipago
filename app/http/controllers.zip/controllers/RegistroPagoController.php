<?php

require_once "app/models/ConductorPagoModel.php";
require_once "app/models/ConductorRegFinanciamientoModel.php";
require_once "app/models/ConductorCuotaModel.php";

class RegistroPagoController extends Controller
{
    private $conexion;

    public function __construct()
    {
        $this->conexion = (new Conexion())->getConexion();
    }

    public function guardarRegistroPago()
    {
        $data = json_decode(file_get_contents('php://input'), true);

        if (!isset($data['id_conductor']) || !isset($data['tipo_pago'])) {
            echo json_encode(['success' => false, 'message' => 'Datos incompletos']);
            return;
        }

        $id_conductor = $data['id_conductor'];
        $tipo_pago = $data['tipo_pago'];
        $fecha_actual = date('Y-m-d');
        $monto_pago = $data['monto_pago'];

        $conductorPagoModel = new ConductorPagoModel();

        // Verificar si ya existe un registro para este conductor
        if ($conductorPagoModel->existeRegistro($id_conductor)) {
            echo json_encode(['success' => false, 'message' => 'Ya existe un registro de pago para este conductor']);
            return;
        }

        $id_pago = $conductorPagoModel->registrarPago($id_conductor, $tipo_pago, $fecha_actual, $monto_pago);

        if (!$id_pago) {
            echo json_encode(['success' => false, 'message' => 'Error al registrar el pago']);
            return;
        }

        if ($tipo_pago == 'financiado') {
            $conductorRegFinanciamientoModel = new ConductorRegFinanciamientoModel();
            $id_financiamiento = $conductorRegFinanciamientoModel->registrarFinanciamiento(
                $id_conductor,
                $data['numero_cuotas'],
                $data['frecuencia_pago'],
                $data['fechas_vencimiento'][0],
                end($data['fechas_vencimiento']),
                $data['monto_cuota'],
                $data['tasa_interes']
            );

            if (!$id_financiamiento) {
                echo json_encode(['success' => false, 'message' => 'Error al registrar el financiamiento']);
                return;
            }

            $conductorCuotaModel = new ConductorCuotaModel();
            foreach ($data['cuotas'] as $index => $monto_cuota) {
                $fecha_vencimiento = $data['fechas_vencimiento'][$index];
                // Validar y formatear la fecha
                if (!$this->validarFormatoFecha($fecha_vencimiento)) {
                    echo json_encode(['success' => false, 'message' => 'Formato de fecha inválido']);
                    return;
                }
                $result = $conductorCuotaModel->registrarCuota(
                    $id_financiamiento,
                    $index + 1,
                    $fecha_vencimiento,
                    $monto_cuota,
                    'pendiente'
                );
                if (!$result) {
                    echo json_encode(['success' => false, 'message' => 'Error al registrar las cuotas']);
                    return;
                }
            }
        }

        echo json_encode(['success' => true]);
    }

    private function validarFormatoFecha($fecha) {
        $formato = 'Y-m-d';
        $fecha_obj = DateTime::createFromFormat($formato, $fecha);
        return $fecha_obj && $fecha_obj->format($formato) === $fecha;
    }


}
