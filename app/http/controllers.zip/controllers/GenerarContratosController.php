<?php
require_once "utils/lib/mpdf/vendor/autoload.php";  // Incluir el autoload de MPDF

use Mpdf\Mpdf;

require_once "app/models/Financiamiento.php";
require_once "app/models/Conductor.php";
require_once "app/models/Productov2.php";
require_once "app/models/CaracteristicaProducto.php";
require_once "app/models/CuotaFinanciamiento.php";
require_once "app/models/Vehiculo.php";
require_once "app/models/ConductorPagoModel.php";
require_once "app/models/ConductorCuotaModel.php";
require_once "app/models/ConductorRegFinanciamientoModel.php";
require_once "app/models/DireccionConductor.php";
require_once "app/models/Inscripcion.php";
require_once "app/models/Requisito.php";
require_once "app/models/Observacion.php";
require_once "app/models/ContactoEmergencia.php";

require_once 'utils/lib/vendor/autoload.php'; // Importar PhpSpreadsheet
require_once 'utils/lib/exel/vendor/autoload.php'; // Importar PhpSpreadsheet

class GenerarContratosController extends controller
{
    private $conexion;

    public function __construct()
    {
        $this->conexion = (new Conexion())->getConexion();
        $this->mpdf = new Mpdf();  // Crear una instancia de Mpdf
    }

    public function searchFinanciamientos()
    {
        $input = json_decode(file_get_contents("php://input"), true);
        $query = $input['query'] ?? '';

        $financiamientoModel = new Financiamiento();
        $resultados = $financiamientoModel->buscarFinanciamientos($query);

        header('Content-Type: application/json');
        echo json_encode($resultados);
    }

    public function obtenerFinanciamientoDetalle() {
        $idFinanciamiento = $_GET['id_financiamiento'];
    
        // Consulta principal: Financiamiento
        $model = new Financiamiento();
        $financiamiento = $model->getFinanciamientoById($idFinanciamiento); // Se usa el modelo correctamente
    
        if (!$financiamiento) {
            echo json_encode(['error' => 'No se encontró el financiamiento.']);
            return;
        }
    
        // Información del conductor
        $conductor = $model->getConductorById($financiamiento['id_conductor']); // Se usa el modelo correctamente
        $direccion = $model->getDireccionCompleta($financiamiento['id_conductor']); 
    
        // Información del producto
        $producto = null;
        if ($financiamiento['idproductosv2'] !== null) {  // Verificamos si idproductosv2 no es null
            $producto = $model->getProductoById($financiamiento['idproductosv2']); // Solo buscamos el producto si existe
        }
        $producto = $model->getProductoById($financiamiento['idproductosv2']); // Se obtiene el producto
    
        // Si no se encuentra el producto, se maneja el caso y se devuelve un objeto vacío
        if (!$producto) {
            $producto = ['codigo' => 'N/A', 'nombre' => 'Producto no disponible']; // Se asigna un valor por defecto si no existe
        }
    
        // Respuesta
        $response = [
            'financiamiento' => $financiamiento,
            'conductor' => array_merge($conductor, ['direccion' => $direccion]),
            'producto' => $producto, // Se agrega el producto
        ];
    
        echo json_encode($response);
    }

    public function obtenerFinanciamientosPorFecha()
    {
        // Obtener el rango de fechas desde la solicitud AJAX
        $input = json_decode(file_get_contents("php://input"), true);
        $fechaInicio = $input['fecha_inicio'] ?? '';
        $fechaFin = $input['fecha_fin'] ?? '';

        // Validar que ambas fechas estén presentes
        if (empty($fechaInicio) || empty($fechaFin)) {
            echo json_encode([]);
            return;
        }

        // Llamar al modelo para obtener los financiamientos
        $financiamientoModel = new Financiamiento();
        $resultados = $financiamientoModel->buscarFinanciamientosPorFecha($fechaInicio, $fechaFin);

        // Devolver los resultados como respuesta JSON
        header('Content-Type: application/json');
        echo json_encode($resultados);
    }

    
    public function generar()
    {
        $input = json_decode(file_get_contents('php://input'), true);
        $ids = $input['ids'] ?? [];

        if (empty($ids)) {
            echo json_encode(['success' => false, 'errores' => ['No se enviaron IDs.']]);
            return;
        }

        $financiamientoModel = new Financiamiento();
        $conductorModel = new Conductor();
        $productoModel = new Productov2();
        $caracteristicasModel = new CaracteristicaProducto();
        $cuotaModel = new CuotaFinanciamiento();
        $errores = [];
        $pdfs = [];

        foreach ($ids as $idFinanciamiento) {
            try {
                $financiamiento = $financiamientoModel->getFinanciamientoById($idFinanciamiento);
                $conductor = $financiamientoModel->getConductorById($financiamiento['id_conductor']);
                $producto = $financiamientoModel->obtenerProductoConCategoria($financiamiento['idproductosv2']);
                $caracteristicas = $caracteristicasModel->obtenerCaracteristicas($financiamiento['idproductosv2']);
                $cuotas = $cuotaModel->obtenerCuotasPorFinanciamiento($idFinanciamiento);

               
                
                if (!in_array($producto['categoria'], ['Llantas', 'Aceites' , 'Celular', 'Chip (Linea corporativa)'])) {
                    throw new Exception("No hay un modelo de contrato para este producto.");
                }

                $plantillas = $this->generarPlantillaContrato(
                    $producto['categoria'],
                    $financiamiento,
                    $conductor,
                    $producto,
                    $caracteristicas,
                    $cuotas
                );

                foreach ($plantillas as $nombrePlantilla => $html) {
                    $mpdf = new \Mpdf\Mpdf([
                        'margin_left' => 30, // Margen izquierdo (en milímetros)
                        'margin_right' => 30,
                    ]);
                    $mpdf->WriteHTML($html);
    
                    // Crear un nombre único para cada archivo
                    $nombreArchivo = "contrato_{$idFinanciamiento}_{$conductor['nombres']}_{$conductor['apellido_paterno']}_{$nombrePlantilla}.pdf";
    
                    $pdfContent = $mpdf->Output('', 'S'); // Devuelve el contenido directamente
                    $pdfs[] = [
                        'content' => base64_encode($pdfContent), // Codificado en Base64
                        'nombre' => $nombreArchivo
                    ];
                }
            } catch (\Exception $e) {
                $errores[] = $idFinanciamiento;
                error_log("Error generando contrato ID $idFinanciamiento: " . $e->getMessage());
            }
        }

        echo json_encode([
            'success' => empty($errores),
            'errores' => $errores,
            'pdfs' => $pdfs,
            'mensaje' => !empty($errores) ? "Error" : null
        ]);
    }

    private function generarPlantillaContrato($categoria, $financiamiento, $conductor, $producto, $caracteristicas, $cuotas)
    {
        $rutaBase = "app" . DIRECTORY_SEPARATOR . "contratos";  // Usamos DIRECTORY_SEPARATOR

        // Formatear fecha y hora
        $fechaCreacion = strtotime($financiamiento['fecha_creacion']);
        $hora = date('h:i A', $fechaCreacion);
        $dia = date('d', $fechaCreacion);
        $mes = date('m', $fechaCreacion);
        $anio = date('Y', $fechaCreacion);

        // Concatenar nombre completo del conductor
        $nombreConductor = trim(
            $conductor['nombres'] . ' ' .
            $conductor['apellido_paterno'] . ' ' .
            $conductor['apellido_materno']
        );

        // Selección de la plantilla según la categoría
        if ($categoria === 'Llantas') {
            $rutaArchivo = $rutaBase . DIRECTORY_SEPARATOR . "contrato_llantas.html";
        } elseif ($categoria === 'Aceites') {
            $rutaArchivo = $rutaBase . DIRECTORY_SEPARATOR . "contrato_aceites.html";
        } elseif ($categoria === 'Celular') {
            $rutaArchivo = $rutaBase . DIRECTORY_SEPARATOR . "contrato_celular.html";
            if (isset($financiamiento['second_product']) && $financiamiento['second_product'] !== null) {
                $rutaArchivoChip = $rutaBase . DIRECTORY_SEPARATOR . "contrato_chipLinea.html";
                if (!file_exists($rutaArchivoChip)) {
                    throw new Exception("Archivo de contrato no encontrado: $rutaArchivoChip");
                }
                $plantillaChip = file_get_contents($rutaArchivoChip);

                $financiamientoModel = new Financiamiento();
                $caracteristicasModel = new CaracteristicaProducto();
                
                $producto2 = $financiamientoModel->obtenerProductoConCategoria($financiamiento['second_product']);
                $caracteristicas2 = $caracteristicasModel->obtenerCaracteristicas($financiamiento['second_product']);

                $planMensual = '';
                $operadora = '';
                $plan = ""; 
                foreach ($caracteristicas2 as $caracteristica2) { // ***Recorrer características***
                    if ($caracteristica2['nombre_caracteristicas'] === 'plan_mensual') {
                        $plan = $caracteristica2['valor_caracteristica']; 
                    } elseif ($caracteristica2['nombre_caracteristicas'] === 'operadora') {
                        $operadora = $caracteristica2['valor_caracteristica']; 
                    }
                }


                // Reemplazar los valores en la plantilla
                $plantillaChip = str_replace('<span id="hora">', $hora, $plantillaChip);
                $plantillaChip = str_replace('<span id="dia">', $dia, $plantillaChip);
                $plantillaChip = str_replace('<span id="mes">', $mes, $plantillaChip);
                $plantillaChip = str_replace('<span id="anio">', $anio, $plantillaChip);
                $plantillaChip = str_replace('<span id="conductor">', $nombreConductor, $plantillaChip);
                $plantillaChip = str_replace('<span id="dni">', $conductor['nro_documento'], $plantillaChip);
                $plantillaChip = str_replace('<span id="licencia">', $conductor['nro_licencia'], $plantillaChip);
                $plantillaChip = str_replace('<span id="cantidad">', $financiamiento['cantidad_producto'], $plantillaChip);

                // Reemplazos específicos para la plantilla de chip
                $plantillaChip = str_replace('<span id="empresa_chip">', $operadora, $plantillaChip);
                $plantillaChip = str_replace('<span id="precio">', $producto2['precio'], $plantillaChip);
                $plantillaChip = str_replace('<span id="precio2">', $producto2['precio'], $plantillaChip);
                $plantillaChip = str_replace('<span id="plan_mensual">', $plan, $plantillaChip);
                $plantillaChip = str_replace('<span id="plan_mensual2">', $plan, $plantillaChip);

                // Guardar la plantilla con los datos reemplazados en un archivo nuevo o devolverla
                $rutaArchivoSalida = "$rutaBase\contrato_chipLinea_relleno.html";
                file_put_contents($rutaArchivoSalida, $plantillaChip);

                
                $plantillas['plantillaChip'] = $plantillaChip;
            }
        } else {
            throw new Exception("Categoría desconocida: $categoria"); // Manejo de errores para categorías no soportadas
        }

        if (!file_exists($rutaArchivo)) {
            throw new Exception("Archivo de contrato no encontrado: $rutaArchivo");
        }
    
        $plantilla = file_get_contents($rutaArchivo);
    
    
        

        if ($categoria === 'Aceites') {
            $cantidadTotal = $financiamiento['cantidad_producto'] * $producto['cantidad_unidad']; // Multiplicación de cantidad por cantidad_unidad
        }

        
        $aro = ''; // Valor por defecto
        $perfil = ''; // Valor por defecto
        
        if ($categoria === 'Llantas') {
            foreach ($caracteristicas as $caracteristica) {
                if ($caracteristica['nombre_caracteristicas'] === 'aro') {
                    $aro = $caracteristica['valor_caracteristica']; // Asignar aro
                } elseif ($caracteristica['nombre_caracteristicas'] === 'perfil') {
                    $perfil = $caracteristica['valor_caracteristica']; // Asignar perfil
                }
            }
        }

        // Inicializar variables para celular
        $chipLinea = ''; // Valor por defecto
        $marcaEquipo = ''; // Valor por defecto
        $modelo = ''; // Valor por defecto
        $imei = ''; // Valor por defecto
        $serie = ''; // Valor por defecto
        $color = ''; // Valor por defecto
        $cargador = ''; // Valor por defecto
        $cableUsb = ''; // Valor por defecto
        $manualUsuario = ''; // Valor por defecto
        $cajaEstuche = ''; // Valor por defecto

        
        // Si la categoría es Celular, asignar las características correspondientes
        if ($categoria === 'Celular') { // ***Modificación para celular***
            foreach ($caracteristicas as $caracteristica) { // ***Recorrer características***
                if ($caracteristica['nombre_caracteristicas'] === 'chip_linea') {
                    $chipLinea = $caracteristica['valor_caracteristica']; // Asignar chip de línea
                } elseif ($caracteristica['nombre_caracteristicas'] === 'marca_equipo') {
                    $marcaEquipo = $caracteristica['valor_caracteristica']; // Asignar marca
                } elseif ($caracteristica['nombre_caracteristicas'] === 'modelo') {
                    $modelo = $caracteristica['valor_caracteristica']; // Asignar modelo
                } elseif ($caracteristica['nombre_caracteristicas'] === 'nro_imei') {
                    $imei = $caracteristica['valor_caracteristica']; // Asignar IMEI
                } elseif ($caracteristica['nombre_caracteristicas'] === 'nro_serie') {
                    $serie = $caracteristica['valor_caracteristica']; // Asignar serie
                } elseif ($caracteristica['nombre_caracteristicas'] === 'colorc') {
                    $color = $caracteristica['valor_caracteristica']; // Asignar color
                } elseif ($caracteristica['nombre_caracteristicas'] === 'cargador') {
                    $cargador = $caracteristica['valor_caracteristica']; // Asignar cargador
                } elseif ($caracteristica['nombre_caracteristicas'] === 'cable_usb') {
                    $cableUsb = $caracteristica['valor_caracteristica']; // Asignar cable USB
                } elseif ($caracteristica['nombre_caracteristicas'] === 'manual_usuario') {
                    $manualUsuario = $caracteristica['valor_caracteristica']; // Asignar manual del usuario
                } elseif ($caracteristica['nombre_caracteristicas'] === 'estuche') {
                    $cajaEstuche = $caracteristica['valor_caracteristica']; // Asignar caja/estuche
                }
            }
        }

             

        // Determinar el texto de frecuencia // ***Cambio añadido aquí***
        $frecuencyTexto='';
        $frecuenciaTexto = ''; // Valor por defecto
        if ($financiamiento['frecuencia'] === 'mensual') {
            $frecuenciaTexto = 'mensualmente';
            $frecuencyTexto = 'mensuales'; // Si frecuencia es mensual, se usa "mensualmente"
        } elseif ($financiamiento['frecuencia'] === 'semanal') {
            $frecuenciaTexto = 'semanalmente'; // Si frecuencia es semanal, se usa "semanalmente"
            $frecuencyTexto = 'semanales';
        }

       
    
        // Reemplazar etiquetas en la plantilla
        $reemplazos = [
            'hora' => $hora,
            'dia' => $dia,
            'mes' => $mes,
            'anio' => $anio,
            'nombre_conductor' => $nombreConductor,
            'dni' => $conductor['nro_documento'],
            'licencia' => $conductor['nro_licencia'],
            'cantidad' => $categoria === 'Aceites' ? $cantidadTotal : $financiamiento['cantidad_producto'], // Usar cantidad calculada para aceites
            'unidad_medida' => $producto['unidad_medida'], // Añadido para aceites
            'marca' => $producto['nombre'],
            'precio_total' => $financiamiento['monto_total'],
            'num_cuotas' => $financiamiento['cuotas'],
            'cuota_inicial' => $financiamiento['cuota_inicial'] ?? '0',
            'cuotas_semanales' => $financiamiento['cuotas'],
            'monto_cuota' => number_format($cuotas[0]['monto'], 2),
            'aro' => $aro,
            'perfil' => $perfil,
            'chip_linea' => $chipLinea, // ***Nuevo campo para chip de línea***
            'marca_equipo' => $marcaEquipo, // ***Nuevo campo para marca de equipo***
            'modelo' => $modelo, // ***Nuevo campo para modelo***
            'imei' => $imei, // ***Nuevo campo para IMEI***
            'serie' => $serie, // ***Nuevo campo para serie***
            'color' => $color, // ***Nuevo campo para color***
            'cargador' => $cargador, // ***Nuevo campo para cargador***
            'cable_usb' => $cableUsb, // ***Nuevo campo para cable USB***
            'manual_usuario' => $manualUsuario, // ***Nuevo campo para manual del usuario***
            'caja_estuche' => $cajaEstuche,
            'frecuency' => $frecuencyTexto,
            'frecuencia' => $frecuenciaTexto,
            'producto' => $producto['nombre'],
            'cuotas' => $financiamiento['cuotas'],
            'cuota_mensual' => number_format($cuotas[0]['monto'], 2), 
            'conductor' => $nombreConductor,
            
            'plan_mensual' => $chipLinea,
            'precio' => $producto['precio'],

        ];
    
        
    
        foreach ($reemplazos as $id => $valor) {
            $plantilla = str_replace("<span id=\"$id\"></span>", $valor, $plantilla);
        }
    
        // Generar lista de cuotas
        $listaCuotas = '';
        foreach ($cuotas as $index => $cuota) {
            $fechaCuota = date('d/m/Y', strtotime($cuota['fecha_vencimiento']));
            $listaCuotas .= "<li><strong>" . ($index + 1) . "a cuota:</strong> S/ {$cuota['monto']} - Fecha: $fechaCuota</li>";
        }
        $plantilla = str_replace("<ul id=\"lista_cuotas\"></ul>", "<ul>$listaCuotas</ul>", $plantilla);
    

        $plantillas['plantillaGeneral'] = $plantilla;

        return $plantillas;
    }

    public function generarContratosRegistro() {

        $input = file_get_contents('php://input'); // Leer el cuerpo de la solicitud
        $data = json_decode($input, true); // Decodificar el JSON recibido
    
        $financiamientoModel = new Financiamiento();
        $vehiculoModel = new Vehiculo();
        $pagoModel = new ConductorPagoModel();
        $cuotasModel = new ConductorCuotaModel();
        $conductorRegFinanciamientoModel = new ConductorRegFinanciamientoModel(); // Nuevo modelo para obtener financiamiento
        $conductorModel = new Conductor();
        $direccionConductorModel = new DireccionConductor();
        $inscripcionModel = new Inscripcion();
        $requisitosModel = new Requisito();
        $observacionModel = new Observacion();
        $contactoEmergenciaModel = new ContactoEmergencia();
        $conductorPago = new ConductorPagoModel();
        
        $resultados = []; // Inicializar el array de resultados
        $pdfs = []; 
        $errores = []; // Para registrar errores
    
        // Cargar la plantilla Excel
        $rutaBase = "app" . DIRECTORY_SEPARATOR . "contratos" . DIRECTORY_SEPARATOR . "exel";
        $rutaArchivo = $rutaBase . DIRECTORY_SEPARATOR . "DATOS GENERALES Lonely.xlsx";
        $spreadsheet = \PhpOffice\PhpSpreadsheet\IOFactory::load($rutaArchivo);
        $sheet = $spreadsheet->getActiveSheet();

        // Iterar sobre los conductores recibidos en el array
        foreach ($data['conductores'] as $conductor) {
            // Usar las claves correctas según el JSON
            $idConductor = $conductor['id_conductor']; // Cambiado de 'id' a 'id_conductor'
            $dni = $conductor['dni'];
            $nombresCompletos = $conductor['nombre_completo']; // Cambiado de 'nombres_completos' a 'nombre_completo'
    
            try {

                // Obtener los datos relacionados con el conductor
                $datosConductor = $conductorModel->getMissingData($idConductor);
                $datosDireccion = $direccionConductorModel->obtenerDatosDireccion($idConductor);
                $datosInscripcion = $inscripcionModel->obtenerInscripcionPorConductor($idConductor);
                $estadoRequisitos = $requisitosModel->obtenerEstadoRequisitos($idConductor);
                $observacion = $observacionModel->obtenerObservacion($idConductor);
                $direccion = $financiamientoModel->getDireccionCompleta($idConductor); // Obtener la dirección completa
                $vehiculo = $vehiculoModel->obtenerDatosVehiculo($idConductor); // Obtener los datos del vehículo
                $tipoPago = $pagoModel->obtenerTipoPago($idConductor); // Obtener el tipo de pago
                $datoPago = $conductorPago->obtenerPagosPorConductor($idConductor);
                // Obtener los datos del contacto de emergencia
                $contactoEmergenciaModel->setIdConductor($idConductor); // Establecer el id del conductor en el modelo de contacto de emergencia
                $contactoEmergenciaModel->obtenerDatosporConductor(); // Llamar al método para extraer los datos
                $contactoEmergencia = [
                    'nombres' => $contactoEmergenciaModel->getNombres(), // Obtener nombres
                    'telefono' => $contactoEmergenciaModel->getTelefono(), // Obtener teléfono
                    'parentesco' => $contactoEmergenciaModel->getParentesco(), // Obtener parentesco
                ];

                // Crear el array de datos para este conductor
                $datos = [
                    'id_conductor' => $idConductor, // Almacenar el id del conductor
                    'telefono' => $datosConductor['telefono'] ?? 'No registrado',
                    'apellido_paterno' => $datosConductor['apellido_paterno'] ?? 'No registrado',
                    'apellido_materno' => $datosConductor['apellido_materno'] ?? 'No registrado',
                    'nombres' => $datosConductor['nombres'] ?? 'No registrado',
                    'nombres_completos' => $conductor['nombre_completo'], // Cambiado de $data['nombres_completo']
                    'dni' => $conductor['dni'] ?? 'Sin DNI',
                    'direccion_completa' => $direccion, 
                    'placa' => $vehiculo['placa'] ?? 'Sin placa', // Placa, con valor por defecto
                    'marca' => $vehiculo['marca'] ?? 'Sin marca', // Marca, con valor por defecto
                    'modelo' => $vehiculo['modelo'] ?? 'Sin modelo', // Modelo, con valor por defecto
                    'color' => $vehiculo['color'] ?? 'Sin color', // Color, con valor por defecto
                    'anio' => $vehiculo['anio'] ?? 'Sin año', 
                    'condicion' => $vehiculo['condicion'] ?? 'Sin condición',
                    'monto_pago' => $datoPago[0]['monto_pago'],
                    'tipo_pago' => $tipoPago, // Tipo de pago
                    'nro_licencia' => $datosConductor['nro_licencia'] ?? 'No registrado',
                    'correo' => $datosConductor['correo'] ?? 'No registrado',
                    'numUnidad' => $datosConductor['numUnidad'] ?? 'No registrado',
                    'direccion_completa2' => [
                        'detalle' => $datosDireccion['direccion_detalle'] ?? 'No registrado',
                        'departamento' => $datosDireccion['departamento'] ?? 'No registrado',
                        'provincia' => $datosDireccion['provincia'] ?? 'No registrado',
                        'distrito' => $datosDireccion['distrito'] ?? 'No registrado',
                    ],
                    'setare' => $datosInscripcion['setare'] ?? 'No registrado',
                    'fecha_inscripcion' => $datosInscripcion['fecha_inscripcion'] ?? 'No registrado',
                    'estado_requisitos' => $estadoRequisitos,
                    'observacion' => $observacion ?? 'Sin observaciones',
                    'contacto_emergencia' => $contactoEmergencia, // Añadido: incluir datos del contacto de emergencia
                ];

                // Obtener la fecha actual en formato "d/m/Y"
                $fechaActual = date('d/m/Y'); // Nueva línea para obtener la fecha actual

                // Rellenar el archivo Excel con los datos
                $sheet->setCellValue('G5', $datos['telefono']);
                $sheet->setCellValue('A8', $datos['apellido_paterno']);
                $sheet->setCellValue('C8', $datos['apellido_materno']);
                $sheet->setCellValue('E8', $datos['nombres']);
                $sheet->setCellValue('G8', $datos['dni']);
                $sheet->setCellValue('A10', $datos['contacto_emergencia']['telefono']);
                $sheet->setCellValue('C10', $datos['contacto_emergencia']['parentesco']);
                $sheet->setCellValue('E10', $datos['contacto_emergencia']['nombres']);
                $sheet->setCellValue('A12', $datos['direccion_completa2']['detalle']);//Les cambie el nómbre a 2 para evitar que se confunda con el direccion_completa de arriba
                $sheet->setCellValue('G12', $datos['direccion_completa2']['distrito']);
                $sheet->setCellValue('A14', $datos['direccion_completa2']['provincia']);
                $sheet->setCellValue('D14', $datos['direccion_completa2']['departamento']);
                $sheet->setCellValue('G14', $datos['nro_licencia']);
                $sheet->setCellValue('A16', $datos['correo']);
                $sheet->setCellValue('A19', $datos['setare']);
                $sheet->setCellValue('E19', $datos['numUnidad']);
                $sheet->setCellValue('G19', $datos['monto_pago']);
                $sheet->setCellValue('D21', $datos['fecha_inscripcion']);
                $sheet->setCellValue('C26', $datos['observacion']);
                $sheet->setCellValue('B36', "$fechaActual"); // Mantiene la celda en B36
                $sheet->getStyle('B36')->getAlignment()->setHorizontal(\PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_LEFT);

                // Marcar los documentos presentados
                $documentos = $datos['estado_requisitos'];
                $sheet->setCellValue('H23', ($documentos['recibo_servicios'] ?? 0) == 1 ? '✔' : '');
                $sheet->setCellValue('D25', ($documentos['carta_desvinculacion'] ?? 0) == 1 ? '✔' : '');
                $sheet->setCellValue('G25', ($documentos['revision_tecnica'] ?? 0) == 1 ? '✔' : '');
                $sheet->setCellValue('D24', ($documentos['soat_doc'] ?? 0) == 1 ? '✔' : '');
                // $sheet->setCellValue('B25', ($documentos['seguro_doc'] ?? 0) == 1 ? '✔' : '');
                $sheet->setCellValue('B25', ($documentos['tarjeta_propiedad'] ?? 0) == 1 ? '✔' : '');
                $sheet->setCellValue('B24', ($documentos['licencia_doc'] ?? 0) == 1 ? '✔' : '');
                $sheet->setCellValue('B23', ($documentos['doc_identidad'] ?? 0) == 1 ? '✔' : '');

                //$sheet->setCellValue('B29', $documentos['doc_otro1'] == 1 ? '✔' : '');
                //$sheet->setCellValue('B30', $documentos['doc_otro2'] == 1 ? '✔' : '');
                //$sheet->setCellValue('B31', $documentos['doc_otro3'] == 1 ? '✔' : '');
        
                // Verificar si el tipo de pago es 2 (financiamiento)
                if ($tipoPago == 2) {
                    // Obtener el ID del financiamiento para este conductor
                    $idFinanciamiento = $conductorRegFinanciamientoModel->obtenerIdFinanciamiento($idConductor);
                    // Obtener las cuotas asociadas a este financiamiento
                    

                    $datos['cuotas'] = $cuotasModel->obtenerCronogramaPagos($idFinanciamiento);
                   
                }

          
                $html = $this->generarPlantillahtmltoPdf($datos);
              

                // Crear PDF
                $mpdf = new \Mpdf\Mpdf();
                
                
                // Definir la fecha actual en formato "día/mes/año"
                $fechaActual = date('d/m/Y'); 

                // Generar el contenido de la plantilla (obtenemos las dos secciones por separado)
                $htmlCompleto = $this->generarPlantillahtmltoPdf($datos);

                // Dividimos el contenido en secciones (suponiendo que el separador es "<div style='page-break-after: always;'></div>")
                $secciones = explode('<div style="page-break-after: always;"></div>', $htmlCompleto);

                // Validamos que haya al menos dos secciones
                $htmlSeccion1 = $secciones[0] ?? '';
                $htmlSeccion2 = $secciones[1] ?? '';

                // 1️⃣ Agregar la primera sección al PDF
                $mpdf->WriteHTML($htmlSeccion1);

                // Configurar el pie de página para la primera sección
                $mpdf->SetHTMLFooter('<div style="text-align: left; font-weight: normal; border-top: none;">AREQUIPA, ' . $fechaActual . '</div>');

                // 2️⃣ Agregar un salto de página manual antes de la segunda sección
                $mpdf->AddPage();

                // 3️⃣ Configurar el pie de página para la segunda sección
                $mpdf->SetHTMLFooter('<div style="text-align: left; font-weight: normal; border-top: none;">AREQUIPA, ' . $fechaActual . '</div>');

                // 4️⃣ Agregar la segunda sección al PDF
                $mpdf->WriteHTML($htmlSeccion2);


                $nombreArchivo = "contrato_{$conductor['dni']}.pdf";
                $pdfContent = $mpdf->Output('', 'S'); // Generar el PDF en memoria

                // Almacenar PDF en base64
                $pdfs[] = [ // Changed from associative array to indexed array
                    'content' => base64_encode($pdfContent),
                    'nombre' => $nombreArchivo
                ];
                // Guardar los cambios en el archivo Excel
                $nombreArchivoExcel = "ANEXO 01 - DT FLOTA_{$conductor['dni']}.xlsx";
                $spreadsheet->getActiveSheet()->getProtection()->setSheet(true); // Activar protección de la hoja
                $spreadsheet->getActiveSheet()->getProtection()->setPassword('tu_contraseña'); // Establecer contraseña para la protección
                
                $spreadsheet->getActiveSheet()->getStyle('G5')->getProtection()->setLocked(\PhpOffice\PhpSpreadsheet\Style\Protection::PROTECTION_UNPROTECTED);
                $spreadsheet->getActiveSheet()->getStyle('H5')->getProtection()->setLocked(\PhpOffice\PhpSpreadsheet\Style\Protection::PROTECTION_UNPROTECTED);
                
                // Desbloquear las celdas A8, B8, C8, D8, E8, F8, G8, H8
                $spreadsheet->getActiveSheet()->getStyle('A8')->getProtection()->setLocked(\PhpOffice\PhpSpreadsheet\Style\Protection::PROTECTION_UNPROTECTED);
                $spreadsheet->getActiveSheet()->getStyle('B8')->getProtection()->setLocked(\PhpOffice\PhpSpreadsheet\Style\Protection::PROTECTION_UNPROTECTED);
                $spreadsheet->getActiveSheet()->getStyle('C8')->getProtection()->setLocked(\PhpOffice\PhpSpreadsheet\Style\Protection::PROTECTION_UNPROTECTED);
                $spreadsheet->getActiveSheet()->getStyle('D8')->getProtection()->setLocked(\PhpOffice\PhpSpreadsheet\Style\Protection::PROTECTION_UNPROTECTED);
                $spreadsheet->getActiveSheet()->getStyle('E8')->getProtection()->setLocked(\PhpOffice\PhpSpreadsheet\Style\Protection::PROTECTION_UNPROTECTED);
                $spreadsheet->getActiveSheet()->getStyle('F8')->getProtection()->setLocked(\PhpOffice\PhpSpreadsheet\Style\Protection::PROTECTION_UNPROTECTED);
                $spreadsheet->getActiveSheet()->getStyle('G8')->getProtection()->setLocked(\PhpOffice\PhpSpreadsheet\Style\Protection::PROTECTION_UNPROTECTED);
                $spreadsheet->getActiveSheet()->getStyle('H8')->getProtection()->setLocked(\PhpOffice\PhpSpreadsheet\Style\Protection::PROTECTION_UNPROTECTED);
                
                // Desbloquear las celdas A10, B10, C10, D10, E10, F10, G10, H10
                $spreadsheet->getActiveSheet()->getStyle('A10')->getProtection()->setLocked(\PhpOffice\PhpSpreadsheet\Style\Protection::PROTECTION_UNPROTECTED);
                $spreadsheet->getActiveSheet()->getStyle('B10')->getProtection()->setLocked(\PhpOffice\PhpSpreadsheet\Style\Protection::PROTECTION_UNPROTECTED);
                $spreadsheet->getActiveSheet()->getStyle('C10')->getProtection()->setLocked(\PhpOffice\PhpSpreadsheet\Style\Protection::PROTECTION_UNPROTECTED);
                $spreadsheet->getActiveSheet()->getStyle('D10')->getProtection()->setLocked(\PhpOffice\PhpSpreadsheet\Style\Protection::PROTECTION_UNPROTECTED);
                $spreadsheet->getActiveSheet()->getStyle('E10')->getProtection()->setLocked(\PhpOffice\PhpSpreadsheet\Style\Protection::PROTECTION_UNPROTECTED);
                $spreadsheet->getActiveSheet()->getStyle('F10')->getProtection()->setLocked(\PhpOffice\PhpSpreadsheet\Style\Protection::PROTECTION_UNPROTECTED);
                $spreadsheet->getActiveSheet()->getStyle('G10')->getProtection()->setLocked(\PhpOffice\PhpSpreadsheet\Style\Protection::PROTECTION_UNPROTECTED);
                $spreadsheet->getActiveSheet()->getStyle('H10')->getProtection()->setLocked(\PhpOffice\PhpSpreadsheet\Style\Protection::PROTECTION_UNPROTECTED);
                
                // Desbloquear las celdas A12, B12, C12, D12, E12, F12, G12, H12
                $spreadsheet->getActiveSheet()->getStyle('A12')->getProtection()->setLocked(\PhpOffice\PhpSpreadsheet\Style\Protection::PROTECTION_UNPROTECTED);
                $spreadsheet->getActiveSheet()->getStyle('B12')->getProtection()->setLocked(\PhpOffice\PhpSpreadsheet\Style\Protection::PROTECTION_UNPROTECTED);
                $spreadsheet->getActiveSheet()->getStyle('C12')->getProtection()->setLocked(\PhpOffice\PhpSpreadsheet\Style\Protection::PROTECTION_UNPROTECTED);
                $spreadsheet->getActiveSheet()->getStyle('D12')->getProtection()->setLocked(\PhpOffice\PhpSpreadsheet\Style\Protection::PROTECTION_UNPROTECTED);
                $spreadsheet->getActiveSheet()->getStyle('E12')->getProtection()->setLocked(\PhpOffice\PhpSpreadsheet\Style\Protection::PROTECTION_UNPROTECTED);
                $spreadsheet->getActiveSheet()->getStyle('F12')->getProtection()->setLocked(\PhpOffice\PhpSpreadsheet\Style\Protection::PROTECTION_UNPROTECTED);
                $spreadsheet->getActiveSheet()->getStyle('G12')->getProtection()->setLocked(\PhpOffice\PhpSpreadsheet\Style\Protection::PROTECTION_UNPROTECTED);
                $spreadsheet->getActiveSheet()->getStyle('H12')->getProtection()->setLocked(\PhpOffice\PhpSpreadsheet\Style\Protection::PROTECTION_UNPROTECTED);
                
                // Desbloquear las celdas A14, B14, C14, D14, E14, F14, G14, H14
                $spreadsheet->getActiveSheet()->getStyle('A14')->getProtection()->setLocked(\PhpOffice\PhpSpreadsheet\Style\Protection::PROTECTION_UNPROTECTED);
                $spreadsheet->getActiveSheet()->getStyle('B14')->getProtection()->setLocked(\PhpOffice\PhpSpreadsheet\Style\Protection::PROTECTION_UNPROTECTED);
                $spreadsheet->getActiveSheet()->getStyle('C14')->getProtection()->setLocked(\PhpOffice\PhpSpreadsheet\Style\Protection::PROTECTION_UNPROTECTED);
                $spreadsheet->getActiveSheet()->getStyle('D14')->getProtection()->setLocked(\PhpOffice\PhpSpreadsheet\Style\Protection::PROTECTION_UNPROTECTED);
                $spreadsheet->getActiveSheet()->getStyle('E14')->getProtection()->setLocked(\PhpOffice\PhpSpreadsheet\Style\Protection::PROTECTION_UNPROTECTED);
                $spreadsheet->getActiveSheet()->getStyle('F14')->getProtection()->setLocked(\PhpOffice\PhpSpreadsheet\Style\Protection::PROTECTION_UNPROTECTED);
                $spreadsheet->getActiveSheet()->getStyle('G14')->getProtection()->setLocked(\PhpOffice\PhpSpreadsheet\Style\Protection::PROTECTION_UNPROTECTED);
                $spreadsheet->getActiveSheet()->getStyle('H14')->getProtection()->setLocked(\PhpOffice\PhpSpreadsheet\Style\Protection::PROTECTION_UNPROTECTED);
                
                // Desbloquear las celdas A16, B16, C16, D16, E16, F16, G16, H16
                $spreadsheet->getActiveSheet()->getStyle('A16')->getProtection()->setLocked(\PhpOffice\PhpSpreadsheet\Style\Protection::PROTECTION_UNPROTECTED);
                $spreadsheet->getActiveSheet()->getStyle('B16')->getProtection()->setLocked(\PhpOffice\PhpSpreadsheet\Style\Protection::PROTECTION_UNPROTECTED);
                $spreadsheet->getActiveSheet()->getStyle('C16')->getProtection()->setLocked(\PhpOffice\PhpSpreadsheet\Style\Protection::PROTECTION_UNPROTECTED);
                $spreadsheet->getActiveSheet()->getStyle('D16')->getProtection()->setLocked(\PhpOffice\PhpSpreadsheet\Style\Protection::PROTECTION_UNPROTECTED);
                $spreadsheet->getActiveSheet()->getStyle('E16')->getProtection()->setLocked(\PhpOffice\PhpSpreadsheet\Style\Protection::PROTECTION_UNPROTECTED);
                $spreadsheet->getActiveSheet()->getStyle('F16')->getProtection()->setLocked(\PhpOffice\PhpSpreadsheet\Style\Protection::PROTECTION_UNPROTECTED);
                $spreadsheet->getActiveSheet()->getStyle('G16')->getProtection()->setLocked(\PhpOffice\PhpSpreadsheet\Style\Protection::PROTECTION_UNPROTECTED);
                $spreadsheet->getActiveSheet()->getStyle('H16')->getProtection()->setLocked(\PhpOffice\PhpSpreadsheet\Style\Protection::PROTECTION_UNPROTECTED);
                
                // Desbloquear las celdas A19, B19, C19, D19, E19, F19, G19, H19
                $spreadsheet->getActiveSheet()->getStyle('A19')->getProtection()->setLocked(\PhpOffice\PhpSpreadsheet\Style\Protection::PROTECTION_UNPROTECTED);
                $spreadsheet->getActiveSheet()->getStyle('B19')->getProtection()->setLocked(\PhpOffice\PhpSpreadsheet\Style\Protection::PROTECTION_UNPROTECTED);
                $spreadsheet->getActiveSheet()->getStyle('C19')->getProtection()->setLocked(\PhpOffice\PhpSpreadsheet\Style\Protection::PROTECTION_UNPROTECTED);
                $spreadsheet->getActiveSheet()->getStyle('D19')->getProtection()->setLocked(\PhpOffice\PhpSpreadsheet\Style\Protection::PROTECTION_UNPROTECTED);
                $spreadsheet->getActiveSheet()->getStyle('E19')->getProtection()->setLocked(\PhpOffice\PhpSpreadsheet\Style\Protection::PROTECTION_UNPROTECTED);
                $spreadsheet->getActiveSheet()->getStyle('F19')->getProtection()->setLocked(\PhpOffice\PhpSpreadsheet\Style\Protection::PROTECTION_UNPROTECTED);
                $spreadsheet->getActiveSheet()->getStyle('G19')->getProtection()->setLocked(\PhpOffice\PhpSpreadsheet\Style\Protection::PROTECTION_UNPROTECTED);
                $spreadsheet->getActiveSheet()->getStyle('H19')->getProtection()->setLocked(\PhpOffice\PhpSpreadsheet\Style\Protection::PROTECTION_UNPROTECTED);
                
                // Desbloquear las celdas A21, B21, C21, D21, E21, F21, G21, H21
                $spreadsheet->getActiveSheet()->getStyle('A21')->getProtection()->setLocked(\PhpOffice\PhpSpreadsheet\Style\Protection::PROTECTION_UNPROTECTED);
                $spreadsheet->getActiveSheet()->getStyle('B21')->getProtection()->setLocked(\PhpOffice\PhpSpreadsheet\Style\Protection::PROTECTION_UNPROTECTED);
                $spreadsheet->getActiveSheet()->getStyle('C21')->getProtection()->setLocked(\PhpOffice\PhpSpreadsheet\Style\Protection::PROTECTION_UNPROTECTED);
                $spreadsheet->getActiveSheet()->getStyle('D21')->getProtection()->setLocked(\PhpOffice\PhpSpreadsheet\Style\Protection::PROTECTION_UNPROTECTED);
                $spreadsheet->getActiveSheet()->getStyle('E21')->getProtection()->setLocked(\PhpOffice\PhpSpreadsheet\Style\Protection::PROTECTION_UNPROTECTED);
                $spreadsheet->getActiveSheet()->getStyle('F21')->getProtection()->setLocked(\PhpOffice\PhpSpreadsheet\Style\Protection::PROTECTION_UNPROTECTED);
                $spreadsheet->getActiveSheet()->getStyle('G21')->getProtection()->setLocked(\PhpOffice\PhpSpreadsheet\Style\Protection::PROTECTION_UNPROTECTED);
                $spreadsheet->getActiveSheet()->getStyle('H21')->getProtection()->setLocked(\PhpOffice\PhpSpreadsheet\Style\Protection::PROTECTION_UNPROTECTED);
                $spreadsheet->getActiveSheet()->getStyle('C26')->getProtection()->setLocked(\PhpOffice\PhpSpreadsheet\Style\Protection::PROTECTION_UNPROTECTED);
                $spreadsheet->getActiveSheet()->getStyle('D26')->getProtection()->setLocked(\PhpOffice\PhpSpreadsheet\Style\Protection::PROTECTION_UNPROTECTED);
                $spreadsheet->getActiveSheet()->getStyle('E26')->getProtection()->setLocked(\PhpOffice\PhpSpreadsheet\Style\Protection::PROTECTION_UNPROTECTED);
                $spreadsheet->getActiveSheet()->getStyle('F26')->getProtection()->setLocked(\PhpOffice\PhpSpreadsheet\Style\Protection::PROTECTION_UNPROTECTED);
                $spreadsheet->getActiveSheet()->getStyle('G26')->getProtection()->setLocked(\PhpOffice\PhpSpreadsheet\Style\Protection::PROTECTION_UNPROTECTED);
                $spreadsheet->getActiveSheet()->getStyle('H26')->getProtection()->setLocked(\PhpOffice\PhpSpreadsheet\Style\Protection::PROTECTION_UNPROTECTED);

                $writer = \PhpOffice\PhpSpreadsheet\IOFactory::createWriter($spreadsheet, 'Xlsx');
                ob_start();
                $writer->save('php://output');
                $excelContent = ob_get_clean();
                $base64Excel = base64_encode($excelContent);
                $resultados[] = $nombreArchivoExcel;

                $exels[] = [
                    'excel' => $base64Excel,
                    'nombre_excel' => $nombreArchivoExcel
                ];

                

            } catch (\Exception $e) {
                $errores[] = [
                    'id_conductor' => $idConductor,
                    'error' => $e->getMessage()
                ];
            }
            

            
        }
        // Retornar respuesta JSON
        echo json_encode([
            'success' => empty($errores),
            'resultados' => $resultados,
            'pdfs' => $pdfs, // Changed from associative array to indexed array
            'exels' => $exels,
            'errores' => $errores
        ]);
        
    }

    public function generarPlantillahtmltoPdf($datos) {
        $rutaBase = "app" . DIRECTORY_SEPARATOR . "contratos";  // Usamos DIRECTORY_SEPARATOR
        $rutaArchivo =  $rutaBase . DIRECTORY_SEPARATOR . "contratoSyA.html";

        
        $html = file_get_contents($rutaArchivo);

        // Reemplazar los valores de los spans con los datos del conductor
        $html = str_replace('<span id="nombre_afiliado">', $datos['nombres_completos'], $html);
        $html = str_replace('<span id="dni_afiliado">', $datos['dni'], $html);
        $html = str_replace('<span id="domicilio_afiliado">', $datos['direccion_completa'], $html);
        $html = str_replace('<span id="placa_vehiculo">', $datos['placa'], $html);
        $html = str_replace('<span id="marca_vehiculo">', $datos['marca'], $html);
        $html = str_replace('<span id="modelo_vehiculo">', $datos['modelo'], $html);
        $html = str_replace('<span id="color_vehiculo">', $datos['color'], $html);
        $html = str_replace('<span id="anio_fabricacion">', $datos['anio'], $html);
        $html = str_replace('<span id="placa_vehiculo2">', $datos['placa'], $html);
        $html = str_replace('<span id="nombre_conductor">', $datos['nombres_completos'], $html);
        $html = str_replace('<span id="dni_conductor">', $datos['dni'], $html);
        
        $html = str_replace('<span id="monto_pago"></span>', '.' . number_format($datos['monto_pago'], 2), $html);
        $html = str_replace('<span id="nombre_conductor2">', $datos['nombres_completos'], $html);
        $html = str_replace('<span id="dni_conductor2">', $datos['dni'], $html);
        
        $condicionMin = strtolower(trim($datos['condicion'])); // Convertir toda la cadena a minúsculas y eliminar espacios
       
        $html = str_replace('<span id="condicion_vehiculo">', $condicionMin, $html); // Usar la condición modificada

        // Marcar el tipo de pago
        if ($datos['tipo_pago'] == 1) {
            // Marcar "Pago al contado"
            $html = str_replace('<span class="checkbox"></span> PAGO AL CONTADO', '<span class="checkbox">X</span> PAGO AL CONTADO', $html);
            // Eliminar "Pago financiado"
            $html = str_replace('<span class="checkbox"></span> PAGO FINANCIADO', '', $html);
        } elseif ($datos['tipo_pago'] == 2) {
            // Marcar "Pago financiado"
            $html = str_replace('<span class="checkbox"></span> PAGO FINANCIADO', '<span class="checkbox">X</span> PAGO FINANCIADO', $html);
            // Eliminar "Pago al contado"
            $html = str_replace('<span class="checkbox"></span> PAGO AL CONTADO', '', $html);

            $cuotasHtml = '<ul>';
            foreach ($datos['cuotas'] as $index => $cuota) {
                $cuotasHtml .= "<li>Cuota " . ($index + 1) . ": Monto: <span id='cuota" . ($index + 1) . "_monto'>" . $cuota['monto_cuota'] . "</span> Fecha: <span id='cuota" . ($index + 1) . "_fecha'>" . $cuota['fecha_vencimiento'] . "</span></li>";
            }
            $cuotasHtml .= '</ul>';
        
            // Reemplazar el marcador de cuotas en el HTML
            $html = str_replace('<div id="cronograma-cuotas"></div>', $cuotasHtml, $html);
        }

        //var_dump($html); // Esto mostrará el HTML ya con los datos reemplazados
        ///exit(); // Detener la ejecución para inspeccionar el resultado
        return $html; // Retornar el HTML generado
    }
    
    
    
}
