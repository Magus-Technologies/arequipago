<?php

require_once "utils/lib/mpdf/vendor/autoload.php";  // Incluir el autoload de MPDF

use Mpdf\Mpdf;


require_once "app/models/Cliente.php";
require_once "app/models/Conductor.php";
require_once "app/models/Financiamiento.php";
require_once "app/models/CuotaFinanciamiento.php";
require_once "app/models/DireccionConductor.php";
require_once "app/models/Departamento.php";
require_once "app/models/Provincia.php";
require_once "app/models/Distrito.php";
require_once "app/models/Productov2.php";
require_once "app/models/GrupoFinanciamientoModel.php";
class FinanciamientoController extends Controller
{
    private $conexion;

    public function __construct()
    {
        $this->conexion = (new Conexion())->getConexion();
        $this->mpdf = new Mpdf();  // Crear una instancia de Mpdf

    }
    
    public function obtenerClientesFinanciamiento()
    {
        try {
            $conductorModel = new Conductor();

            // Recibir la página actual, por defecto 1
            $pagina = isset($_GET['pagina']) ? (int)$_GET['pagina'] : 1;
            $cantidadPorPagina = 12;

            // Obtener los conductores con datos de financiamiento sin repetirlos
            $conductores = $conductorModel->obtenerTodosConductores($pagina, $cantidadPorPagina);
            
            // Obtener el total de conductores (sin contar financiamientos repetidos)
            $totalConductores = $conductorModel->obtenerTotalConductores();
            $totalPaginas = ceil($totalConductores / $cantidadPorPagina);

            // Devuelve los datos en formato JSON
            echo json_encode([
                'conductores' => $conductores,
                'totalPaginas' => $totalPaginas,
                'paginaActual' => $pagina
            ]);
            exit;
        } catch (Exception $e) {
            echo json_encode(['error' => 'Hubo un error al obtener los datos']);
            exit;
        }
    }

    public function obtenerClientesFiltrados()
    {
        try {
            $clienteModel = new Conductor();

            // Obtener el término de búsqueda desde la solicitud
            $searchTerm = isset($_GET['searchTerm']) ? $_GET['searchTerm'] : '';
            $pagina = isset($_GET['pagina']) ? (int)$_GET['pagina'] : 1;
            $cantidadPorPagina = 12;

            // Obtener los conductores filtrados y agrupados correctamente
            $clientes = $clienteModel->obtenerConductoresFiltrados($searchTerm, $pagina, $cantidadPorPagina);

            // Obtener el total de conductores únicos para la paginación
            $totalClientes = $clienteModel->obtenerTotalClientesBusqueda($searchTerm);
            $totalPaginas = ceil($totalClientes / $cantidadPorPagina);

            // Responder en formato JSON
            header('Content-Type: application/json');
            echo json_encode([
                'clientes' => $clientes,
                'totalPaginas' => $totalPaginas,
                'paginaActual' => $pagina
            ]);
            exit;
        } catch (Exception $e) {
            echo json_encode(['error' => 'Hubo un error al obtener los datos']);
            exit;
        }
    }

    public function obtenerFinanciamientoPorCliente()
        {
            try {
                // Obtener el id_cliente desde la solicitud GET
                $id_conductor = isset($_GET['id_conductor']) ? (int)$_GET['id_conductor'] : 0; // Cambié 'id_clie
                
                if ($id_conductor === 0) {
                    echo json_encode(['error' => 'ID de conductor no proporcionado']); // Cambié 'cliente' a 'conductor'
                    exit;
                }

                // Crear una instancia del modelo Financiamiento
                $financiamientoModel = new Financiamiento();

                // Obtener los detalles del financiamiento para el cliente
                $data = $financiamientoModel->obtenerPorConductor($id_conductor); // Cambié 'obtenerPorCliente' a 'obtenerPorConductor'

                if (!$data) { // Cambio: Verificar si está vacío o es null
                    echo json_encode(['error' => 'No se encontraron financiamientos para este conductor']); // Enviar error si no hay datos
                    exit;
                }

                // Devolver los datos de financiamiento
                echo json_encode($data); // Cambio: Enviar directamente el array asociativo
                exit;
            } catch (Exception $e) {
                echo json_encode(['error' => 'Hubo un error al obtener los datos del financiamiento']);
                exit;
            }
        }

        public function obtenerCuotasPorCliente()
        {
            try {
                // Obtener el ID del conductor desde el parámetro de la URL
                $id_conductor = isset($_GET['id_conductor']) ? (int)$_GET['id_conductor'] : 0; 

                if ($id_conductor === 0) {
                    echo json_encode(['error' => 'ID de conductor no proporcionado']);
                    return;
                }
       
                // Crear instancia del modelo Financiamiento
                $financiamientoModel = new Financiamiento(); 
                $financiamientos = $financiamientoModel->getFinanciamientoList($id_conductor); // Modificado

                $productoModel = new Productov2();
               
                if (empty($financiamientos)) {
                    echo json_encode(['financiamientos' => null]);
                    return;
                }
        
                
                $cuotaModel = new CuotaFinanciamiento(); 

                foreach ($financiamientos as &$financiamiento) {
                    $id_financiamiento = $financiamiento['idfinanciamiento'];
        
                    // Obtener cuotas asociadas
                    $financiamiento['cuotas'] = $cuotaModel->getCuotasforFinanciamientoList($id_financiamiento);
        
                    // Obtener producto asociado
                    $id_producto = $financiamiento['idproductosv2']; // ID del producto en el financiamiento
                    $financiamiento['producto'] = $productoModel->getProductsList($id_producto);
                }
                // Responder con los financiamientos y sus cuotas asociadas
                echo json_encode(['financiamientos' => $financiamientos]); // Modificado

            } catch (Exception $e) {
                echo json_encode(['error' => 'Error al obtener cuotas: ' . $e->getMessage()]);
            }
        }

        public function obtenerClienteDetalle()
        {
             try {
                // Obtener el ID del conductor desde el parámetro de la URL
                $id_conductor = isset($_GET['id_conductor']) ? (int)$_GET['id_conductor'] : 0; 

                if ($id_conductor === 0) {
                    echo json_encode(['error' => 'ID de conductor no proporcionado']);
                    return;
                }
       
                // Crear instancia del modelo Financiamiento
                $financiamientoModel = new Financiamiento(); 
                $financiamientos = $financiamientoModel->getFinanciamientoList($id_conductor); // Modificado

                $productoModel = new Productov2();
                $conductorModel = new Conductor(); 
                $direccionModel = new DireccionConductor(); 
               
                if (empty($financiamientos)) {
                    echo json_encode(['financiamientos' => null]);
                    return;
                }
        
                
                $cuotaModel = new CuotaFinanciamiento(); 

                foreach ($financiamientos as &$financiamiento) {
                    $id_financiamiento = $financiamiento['idfinanciamiento'];
        
                    // Obtener cuotas asociadas
                    $financiamiento['cuotas'] = $cuotaModel->getCuotasforFinanciamientoList($id_financiamiento);
        
                    // Obtener producto asociado
                    $id_producto = $financiamiento['idproductosv2']; // ID del producto en el financiamiento
                    $financiamiento['producto'] = $productoModel->getProductsList($id_producto);
                }

                //Obtener información del conductor
                $conductor = $conductorModel->getConductorFinanceList($id_conductor); // Nuevo método agregado
                // Obtener dirección del conductor
                
                $direccion = $direccionModel->obtenerDatosDireccion($id_conductor); // Modificado: llamado al método correcto
                // Responder con los financiamientos y sus cuotas asociadas
                echo json_encode(['financiamientos' => $financiamientos,
                                   'conductor' => $conductor,
                                   'direccion' => $direccion
                ]); // Modificado

            } catch (Exception $e) {
                echo json_encode(['error' => 'Error al obtener cuotas: ' . $e->getMessage()]);
            }
        }

        private function obtenerNombreDepartamento($idDepartamento)
        {
            $sql = "SELECT nombre FROM depast WHERE iddepast = ?";
            return $this->obtenerNombrePorId($sql, $idDepartamento);
        }
        
        private function obtenerNombreProvincia($idProvincia)
        {
            $sql = "SELECT nombre FROM provincet WHERE idprovincet = ?";
            return $this->obtenerNombrePorId($sql, $idProvincia);
        }
        
        private function obtenerNombreDistrito($idDistrito)
        {
            $sql = "SELECT nombre FROM distritot WHERE iddistritot = ?";
            return $this->obtenerNombrePorId($sql, $idDistrito);
        }
        
        private function obtenerNombrePorId($sql, $id)
        {
            try {
                $conexion = (new Conexion())->getConexion();
                $stmt = $conexion->prepare($sql);
                $stmt->bind_param("i", $id);
                $stmt->execute();
                $result = $stmt->get_result();
        
                $row = $result->fetch_assoc();
                return $row ? $row['nombre'] : 'Desconocido';
            } catch (Exception $e) {
                return 'Error';
            }
        }


    // Función para obtener clientes filtrados para autocompletado
    public function obtenerClientesAutocompletado()
        {
            try {
                $conductorModel = new Conductor();
        
                // Obtener el término de búsqueda desde la solicitud GET
                $searchTerm = isset($_GET['searchTerm']) ? $_GET['searchTerm'] : '';
        
                // Obtener los conductores filtrados
                $conductores = $conductorModel->obtenerConductoresConCodigo($searchTerm);
        
                // Devolver los resultados en formato JSON
                echo json_encode($conductores);
                exit;
            } catch (Exception $e) {
                echo json_encode(['error' => 'Hubo un error al obtener los datos']);
                exit;
            }
        }

        public function obtenerNumDocAutocompletado()
        {
            try {
                $conductorModel = new Conductor();

                // Obtener el término de búsqueda desde la solicitud GET
                $searchTerm = isset($_GET['searchTerm']) ? $_GET['searchTerm'] : '';

                // Obtener los números de documento filtrados
                $conductores = $conductorModel->obtenerNumDocFiltrado($searchTerm);

                // Devolver los resultados en formato JSON
                echo json_encode($conductores);
                exit;
            } catch (Exception $e) {
                echo json_encode(['error' => 'Hubo un error al obtener los datos']);
                exit;
            }
        }

        public function obtenerProductos()
        {
            try {
                // Obtener la página actual desde $_GET
                $pagina = isset($_GET['pagina']) ? (int)$_GET['pagina'] : 1;
                $productosPorPagina = 5; // Número de productos por página


                // Mostrar los valores de entrada
                //var_dump(['pagina' => $pagina, 'productosPorPagina' => $productosPorPagina]);


                // Crear una instancia del modelo ProductoV2
                $productoV2 = new ProductoV2();

                // Obtener los productos con paginación
                $productos = $productoV2->obtenerProductos($pagina, $productosPorPagina);


                // Mostrar los datos obtenidos del modelo
                //var_dump($productos);



                // Devolver los productos en formato JSON
                echo json_encode([
                    'productos' => $productos['productos'],
                    'totalPaginas' => $productos['totalPages'], // Cambiamos "totalPages" por "totalPaginas"
                ]);
                exit;
            } catch (Exception $e) {
                //var_dump(['error' => $e->getMessage()]);
                echo json_encode(['error' => 'Hubo un error al obtener los productos']);
                exit;
            }
            
        }

        public function searchProductos() {
            try {
                // Obtener el término de búsqueda desde la solicitud
                $searchTerm = isset($_GET['searchTerm']) ? $_GET['searchTerm'] : '';
        
                // Instanciar el modelo
                $productoModel = new ProductoV2();
        
                // Obtener los productos filtrados
                $productos = $productoModel->buscarProductosPorNombreOCodigo($searchTerm);
        
                // Responder con los datos en formato JSON
                echo json_encode(['productos' => $productos]);
            } catch (Exception $e) {
                echo json_encode(['error' => $e->getMessage()]);
            }
        }

        public function obtenerTipoProducto()
        {
            if (isset($_GET['id_producto'])) {
                $idProducto = intval($_GET['id_producto']);
                $modeloProducto = new Productov2();

                $tipoProducto = $modeloProducto->obtenerTipoProductoPorId($idProducto);

                if ($tipoProducto) {
                    echo json_encode(['tipo_producto' => $tipoProducto]);
                } else {
                    echo json_encode(['error' => 'Producto no encontrado']);
                }
            } else {
                echo json_encode(['error' => 'ID de producto no proporcionado']);
            }
        }

        public function guardarGrupoFinanciamiento() {
            if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                $nombreGrupo = isset($_POST['nombre']) ? trim($_POST['nombre']) : '';

                if (empty($nombreGrupo)) {
                    echo json_encode(['success' => false, 'message' => 'El campo nombre está vacío.']);
                    return;
                }

                $model = new GrupoFinanciamientoModel(); // Instanciar el modelo

                $resultado = $model->guardarGrupoFinanciamiento($nombreGrupo); // Guardar el grupo

                if ($resultado) {
                    // Obtener el ID del nuevo grupo
                    $nuevoId = $model->getUltimoIdInsertado();
                    echo json_encode([
                        'success' => true,
                        'nuevoGrupoFinanciamiento' => [
                            'idgrupoVehicular_financiamiento' => $nuevoId,
                            'nombre' => $nombreGrupo
                        ]
                    ]);
                } else {
                    echo json_encode(['success' => false, 'message' => 'No se pudo guardar el grupo de financiamiento.']);
                }
            }
        }

        public function cargarGruposFinanciamiento() {
            $grupoFinanciamientoModel = new GrupoFinanciamientoModel();
            $grupos = $grupoFinanciamientoModel->obtenerGruposFinanciamiento();
            echo json_encode($grupos);
        }

        public function generarCronogramaPDF() {
            $input = file_get_contents('php://input');
            $data = json_decode($input, true);      
            
            // Validar que los datos estén presentes
            if (!$data || !isset($data['nombreCliente'], $data['numeroDocumento'], $data['fechaInicio'], $data['monto'], $data['tasaInteres'], $data['cronograma'])) {
                return json_encode([
                    'success' => false,
                    'message' => 'Datos incompletos enviados al servidor.'
                ]);
            }

            // Asignar variables desde el payload
            $nombreCliente = $data['nombreCliente'];
            $numeroDocumento = $data['numeroDocumento'];
            $fechaInicio = $data['fechaInicio'];
            $monto = $data['monto'];
            $tasaInteres = $data['tasaInteres'];
            $frecuenciaPago = $data['frecuenciaPago'];
            $cronograma = $data['cronograma'];
            $tipoMoneda = $data['tipoMoneda'];

            $conductorModel = new Conductor();     
            $tipoDoc = $conductorModel->obtenerTipoDocumento($numeroDocumento); // Cambié $datos['numeroDocumento'] a $numeroDocumento porque $datos no estaba definido
    
            if ($frecuenciaPago == 'mensual') { // Si es mensual
                $htmlCronograma = $this->generarHTMLCronogramaMensual([
                    'nombreCliente' => $nombreCliente,
                    'numeroDocumento' => $numeroDocumento,
                    'fechaInicio' => $fechaInicio,
                    'monto' => $monto,
                    'tasaInteres' => $tasaInteres,
                    'frecuenciaPago' => $frecuenciaPago,
                    'cronograma' => $cronograma,
                    'tipoMoneda' => $tipoMoneda
                ], $tipoDoc);
            } else { // Si es semanal
                $htmlCronograma = $this->generarHTMLCronograma([
                    'nombreCliente' => $nombreCliente,
                    'numeroDocumento' => $numeroDocumento,
                    'fechaInicio' => $fechaInicio,
                    'monto' => $monto,
                    'tasaInteres' => $tasaInteres,
                    'frecuenciaPago' => $frecuenciaPago,
                    'cronograma' => $cronograma,
                    'tipoMoneda' => $tipoMoneda // Pasar el tipo de moneda al HTML
                ], $tipoDoc);
            }

            // Configurar mPDF
            $mpdf = new \Mpdf\Mpdf();
            $mpdf->WriteHTML($htmlCronograma);

            // Generar nombre del archivo
            $nombreArchivo = "cronograma_{$numeroDocumento}.pdf";

            // Generar PDF
            $pdfContent = $mpdf->Output('', 'S'); // 'S' para obtener el contenido como string

            // Retornar el PDF en formato base64 para enviarlo a la vista
            return json_encode([
                'success' => true,
                'pdf' => base64_encode($pdfContent), // Convertir a base64 para poder enviarlo a la vista
                'nombre' => $nombreArchivo
            ]);
        }
    
        private function generarHTMLCronograma($datos, $tipoDoc) {
            // Ruta del archivo cronograma.html
            $rutaBase = "app" . DIRECTORY_SEPARATOR . "contratos";
            $rutaArchivo = $rutaBase . DIRECTORY_SEPARATOR . "cronograma.html";
        
            // Leer el contenido del archivo
            $html = file_get_contents($rutaArchivo);
            /*if ($datos['frecuenciaPago'] == 'semanal') {
                $html = str_replace('style="display:none;"', '', $html); // Eliminar el display:none si es semanal
            }*/
            
            
            // Reemplazar los valores en el HTML
            $html = str_replace('[Nombre del cliente]', $datos['nombreCliente'], $html);
            $html = str_replace('[Tipo de documento de identidad]', $tipoDoc, $html); // Cambié para asegurar que $tipoDoc provenga del modelo correctamente
            $html = str_replace('[Número de identidad]', $datos['numeroDocumento'], $html);
            $html = str_replace('[Fecha de inicio del financiamiento]', date('d/m/Y', strtotime($datos['fechaInicio'])), $html);
            $html = str_replace('[Monto del financiamiento]', $datos['tipoMoneda'] . ' ' . number_format($datos['monto'], 2), $html); // Modificado para usar el tipo de moneda dinámico
            $html = str_replace('[Tasa de interés]', $datos['tasaInteres'], $html);
        
            $tablaSemanal = ''; // Inicializo la variable para la tabla
            foreach ($datos['cronograma'] as $cuota) { // Itero sobre el cronograma
                $fechaVencimiento = DateTime::createFromFormat('d/m/Y', $cuota['vencimiento']); // Convertimos la fecha
                if ($fechaVencimiento) {
                    $fechaFormateada = $fechaVencimiento->format('d/m/Y'); // Formateamos la fecha
                } else {
                    $fechaFormateada = $cuota['vencimiento']; // Si la fecha no se puede convertir, dejamos la original
                }

                $tablaSemanal .= "<tr>\n";
                $tablaSemanal .= "<td>{$cuota['cuota']}</td>\n"; // Número de cuota
                $tablaSemanal .= "<td>{$datos['tipoMoneda']} " . number_format($cuota['valor'], 2) . "</td>\n"; // Modificado para usar el tipo de moneda dinámico
                $tablaSemanal .= "<td>{$fechaFormateada}</td>\n"; // Fecha de vencimiento con formato
                $tablaSemanal .= "</tr>\n";
            }

           
            $html = str_replace('<tbody id="tabla_semanal">', '<tbody id="tabla-cronograma">' .$tablaSemanal, $html); 
                        
            // Ocultar tabla mensual si es semanal
            $html = str_replace('<div class="section" id="mensual">', '<div class="section" id="mensual" style="display:none;">', $html); // Ocultar tabla mensual


            $html = str_replace('[NOMBRE DE LA EMPRESA]', 'EMPRESA DE TRANSPORTE AREQUIPA GO S.A.C.', $html);
            $html = str_replace('[Dirección de la empresa]', 'Urb. Adepa Mz L Lt 15 Distrito de José Luis Bustamante y Rivero Provincia y Departamento de Arequipa', $html);


            // Retornar el HTML generado
            return $html;

        }

            
        private function generarHTMLCronogramaMensual($datos, $tipoDoc){    
                
              // Ruta del archivo cronograma.html
            $rutaBase = "app" . DIRECTORY_SEPARATOR . "contratos";
            $rutaArchivo = $rutaBase . DIRECTORY_SEPARATOR . "cronograma.html";
        
            // Leer el contenido del archivo
            $html = file_get_contents($rutaArchivo);
        
            

            // Reemplazar los valores en el HTML
            $html = str_replace('[Nombre del cliente]', $datos['nombreCliente'], $html);
            $html = str_replace('[Tipo de documento de identidad]', $tipoDoc, $html); // Cambié para asegurar que $tipoDoc provenga del modelo correctamente
            $html = str_replace('[Número de identidad]', $datos['numeroDocumento'], $html);
            $html = str_replace('[Fecha de inicio del financiamiento]', date('d/m/Y', strtotime($datos['fechaInicio'])), $html);
            $html = str_replace('[Monto del financiamiento]', $datos['tipoMoneda'] . ' ' . number_format($datos['monto'], 2), $html); // Modificado para usar el tipo de moneda dinámico
            $html = str_replace('[Tasa de interés]', $datos['tasaInteres'], $html);
            
            
            
            // Array de traducción para los meses
                $mesesEnEspanol = [
                    'January' => 'Enero',
                    'February' => 'Febrero',
                    'March' => 'Marzo',
                    'April' => 'Abril',
                    'May' => 'Mayo',
                    'June' => 'Junio',
                    'July' => 'Julio',
                    'August' => 'Agosto',
                    'September' => 'Septiembre',
                    'October' => 'Octubre',
                    'November' => 'Noviembre',
                    'December' => 'Diciembre'
                ];

                // Rellenar la tabla de pagos mensual
                $tablaMensual = '';
                $cuotasPorMes = [];

                // Agrupar las cuotas por mes y año
                foreach ($datos['cronograma'] as $cuota) {
                    $fechaVencimiento = DateTime::createFromFormat('d/m/Y', $cuota['vencimiento']);
                    
                    if (!$fechaVencimiento) {
                        continue; // Si la fecha no es válida, continuar con el siguiente ciclo
                    }
                    
                    $mesEnIngles = $fechaVencimiento->format('F');
                    $mes = $mesesEnEspanol[$mesEnIngles];
                    $anio = $fechaVencimiento->format('Y');

                    $mesAnio = $mes . ' ' . $anio;

                    // Agrupar cuotas por mes y año
                    if (!isset($cuotasPorMes[$mesAnio])) {
                        $cuotasPorMes[$mesAnio] = [];
                    }

                    $cuotasPorMes[$mesAnio][] = $cuota;
                }

                // Generar filas para la tabla mensual
                foreach ($cuotasPorMes as $mesAnio => $cuotas) {
                    foreach ($cuotas as $cuota) {
                        $fechaVencimiento = $cuota['vencimiento']; // Ya está en formato dd/mm/yyyy
                        $valorFormateado = number_format($cuota['valor'], 2, '.', ',');
                        $tablaMensual .= "<tr>\n" .
                            "<td>{$mesAnio}</td>\n" .
                            "<td>Cuota {$cuota['cuota']}: {$datos['tipoMoneda']} {$valorFormateado}</td>\n" . // Aquí se arregló la concatenación
                            "<td>{$fechaVencimiento}</td>\n" .
                            "</tr>\n";
                    }
                }

                $html = str_replace('<tbody id="tabla_mensual">', '<tbody id="superTabla">' . $tablaMensual, $html);

                $html = str_replace('<div class="section" id="semanal">', '<div class="section" id="semanal" style="display:none;">', $html); // Ocultar tabla semanal
                
                // Rellenar los datos de la empresa
                $html = str_replace('[NOMBRE DE LA EMPRESA]', 'EMPRESA DE TRANSPORTE AREQUIPA GO S.A.C.', $html);
                $html = str_replace('[Dirección de la empresa]', 'Urb. Adepa Mz L Lt 15 Distrito de José Luis Bustamante y Rivero Provincia y Departamento de Arequipa', $html);


                // Retornar el HTML generado
                return $html;
               
       }

       public function obtenerTipoCambio() {
            $token = 'apis-token-12676.06vC22lNLuV4uUGX4CsxHcdKf2tT92T8'; // Reemplaza con tu token
            $url = 'https://api.apis.net.pe/v2/sunat/tipo-cambio';

            // Iniciar llamada a API
            $curl = curl_init();
            curl_setopt_array($curl, array(
                CURLOPT_URL => $url,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_SSL_VERIFYPEER => 0,
                CURLOPT_HTTPHEADER => array(
                    'Referer: https://apis.net.pe/tipo-de-cambio-sunat-api',
                    'Authorization: Bearer ' . $token
                ),
            ));

            $response = curl_exec($curl);
            curl_close($curl);

            

            // Decodificar la respuesta
            $data = json_decode($response, true);

            

            // Manejar errores o respuesta vacía
            if (!$data || !isset($data['precioVenta'])) {
                echo json_encode(['error' => 'No se pudo obtener el tipo de cambio']);
                return;
            }

            // Enviar el tipo de cambio al cliente
            // Enviar el tipo de cambio al cliente
            echo json_encode(['tipo_cambio' => $data['precioVenta']]); // Usamos 'precioVenta' que es el campo correcto

        }

        
        public function buscarPlanesMensuales() {
            $model = new Productov2(); // Cambié el acceso estático por una instancia del modelo

            // Llamamos al método del modelo para obtener los datos
            $productos = $model->getPlanesMensuales(); // Usamos la instancia para invocar el método

            // Devolvemos los datos como JSON
            echo json_encode($productos);
        }
       
        public function obtenerPlanFinanciamiento() {
            if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['id_producto'])) {
                $idProducto = intval($_POST['id_producto']); // Aseguramos que sea un número entero
    
                $financiamientoModel = new Financiamiento(); // Instanciamos el modelo
                $plan = $financiamientoModel->getPlanChecker($idProducto); // Llamamos al método del modelo
    
                if ($plan) {
                    echo json_encode(['success' => true, 'plan' => $plan]); // Enviamos respuesta en JSON
                } else {
                    echo json_encode(['success' => false, 'message' => 'No se encontró un plan de financiamiento']);
                }
            } else {
                echo json_encode(['success' => false, 'message' => 'Solicitud inválida']);
            }
        }
    
    }