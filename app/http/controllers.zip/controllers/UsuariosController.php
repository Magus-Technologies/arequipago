<?php


class UsuariosController extends Controller
{

    private $cliente;

    public function __construct()
    {
        $this->conectar = (new Conexion())->getConexion();
    }



    public function render()
    {
        $sql = "SELECT
                    usuario_id,
                    r.nombre,
                    usuario,
                    email,
                    nombres,
                    CASE 
                        WHEN sucursal = 1 THEN 'Tienda 435'
                        ELSE 'Tienda 426'
                    END AS tienda,
                    CASE 
                        WHEN rotativo = 0 THEN 'No'
                        ELSE 'Si'
                    END AS rotativo 
                FROM
                    usuarios u
                INNER JOIN roles r ON r.rol_id = u.id_rol";
        $fila = mysqli_query($this->conectar, $sql);
        $respuesta = mysqli_fetch_all($fila, MYSQLI_ASSOC);
        return json_encode($respuesta);
    }

    public function getOne()
    {
        $sql = "SELECT
                    usuario_id,
                    num_doc,
                    id_rol,
                    usuario,
                    email,
                    nombres,
                    sucursal,
                    rotativo
                FROM
                    usuarios u
                where u.usuario_id = {$_POST["id"]}";
        $fila = mysqli_query($this->conectar, $sql);
        $respuesta = mysqli_fetch_all($fila, MYSQLI_ASSOC);
        return json_encode($respuesta);
    }

    public function editar()
    {
        $udp = "";
        if (!empty($_POST["clave"])) { 
            $clave = sha1($_POST["clave"]);
            $udp = "clave='$clave',";
        }
        $sql = "UPDATE usuarios SET 
            id_rol='{$_POST["rol"]}',
            nombres='{$_POST["datosEditar"]}',
            num_doc='{$_POST["doc"]}',
            usuario='{$_POST["usuariou"]}',"
            . $udp . " 
            email='{$_POST["emailEditar"]}',
            rotativo={$_POST["rotativou"]}
        WHERE usuario_id = {$_POST["idCliente"]}";

        mysqli_query($this->conectar, $sql);
        return true;
    }

    public function borrar()
    {
        $sql = "DELETE FROM usuarios WHERE usuario_id = {$_POST["value"]}";
        mysqli_query($this->conectar, $sql);
        return true;
    }
}
