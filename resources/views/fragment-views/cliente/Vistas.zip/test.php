<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>


    <table style="width:100%" class="table table-bordered dt-responsive nowrap text-center table-sm">
        <tr>
            <th rowspan="3" colspan="1" style="text-align: center;font-size: 12px;">NUMERO DEL REGISTRO O CODIGO UNICO DE OPERACIÓN</th>

            <th rowspan="2" colspan="5" style="text-align: center;font-size: 12px;">COMPROBANTE DE PAGO O DOCUMENTO</th>

            <th colspan="4" rowspan="1" style="text-align: center;font-size: 12px;">INFORMACION DEL CLIENTE</th>
            <th rowspan="3" style="text-align: center;font-size: 12px;">VALOR FACTURADO DE LA EXPORTACION</th>
            <th rowspan="3" style="text-align: center;font-size: 12px;">BASE IMPONIBLE DE LA OPERACIÓN GRAVADA</th>
            <th rowspan="2" colspan="2" style="text-align: center;font-size: 12px;">IMPORTE DE LA OPERACIÓN EXONERADA O INAFECTA</th>
            <th rowspan="3" colspan="2" style="text-align: center;font-size: 12px;">ISC</th>
            <th rowspan="3" colspan="2" style="text-align: center;font-size: 12px;">IGV Y/O IPM</th>
            <th rowspan="3" colspan="2" style="text-align: center;font-size: 12px;">OTROS TRIBUTOS Y CARGOS QUE NO FORMAN PARTE DE LA BASE IMPONIBLE</th>
            <th rowspan="3" colspan="2" style="text-align: center;font-size: 12px;">IMPORTE TOTAL DEL COMPROBANTE DE PAGO</th>
            <th rowspan="3" colspan="2" style="text-align: center;font-size: 12px;">TIPO DE CAMBIO</th>
            <th rowspan="2" colspan="4" style="text-align: center;font-size: 12px;">REF. COMPROBANTE DE PAGO QUE SE MODIFICA</th>


        </tr>
        <tr>
            <td colspan="2" style="font-size: 12px;">DOC. IDENTIDAD</td>
            <td rowspan="2" colspan="1" style="font-size: 12px;">APELLIDOS Y NOMBRES O RAZON SOCIAL</td>
            <td rowspan="2" colspan="1" style="font-size: 12px;">APELLIDOS Y NOMBRES O RAZON SOCIAL</td>
         
         

        </tr>
        <tr>
            <td style="font-size: 12px;">FECHA DE EMISION</td>
            <td style="font-size: 12px;">FECHA DE VCTO</td>
            <td style="font-size: 12px;">TIPO</td>
            <td style="font-size: 12px;">SERIE</td>
            <td style="font-size: 12px;">NUMERO</td>
            <td style="font-size: 12px;">TIPO</td>
            <td style="font-size: 12px;">NUMERO</td>
            <td style="font-size: 12px;">EXONERADA</td>
            <td style="font-size: 12px;">INAFECTA</td>
            <td style="font-size: 12px;">FECHA EMISION</td>
            <td style="font-size: 12px;">TIPO</td>
            <td style="font-size: 12px;">SERIE</td>
            <td style="font-size: 12px;">NUMERO</td>

        </tr>



    </table>
</body>

</html>