<?php
    $id_conductor = $_GET['id'] ?? null;
?>

<head>
<style>
        .container-custom {
            max-width: 1200px;
            /* Ajustado para un tamaño más realista en lugar de 900rem */
            margin-top: 20px;
            padding: 20px;
            background-color: #F2F2F2;
            /* Fondo claro para hacer que los elementos resalten */
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }


        .form-section {
            border: 2px solid #D7D7D7;
            padding: 20px;
            margin-bottom: 15px;
            border-radius: 8px;
            background-color: #FAFAFA;
            /* Fondo oscuro para contrastar con el contenedor principal */
            color: #000000;
            font-weight: normal;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease;
        }

        .form-section label {
            font-family: 'Roboto', sans-serif;
            font-weight: 300;
        }

        .form-section:hover {
            transform: translateY(-4px);
            /* Efecto de elevación en hover */
        }

        .form-section h5 {
            color: #000000;
            font-size: 1.2rem;
            font-weight: bold;
            margin-bottom: 10px;
        }

        .btn-custom {
            background-color: #F2E74B;
            color: #343F40;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            font-weight: bold;
            transition: background-color 0.3s ease, transform 0.2s ease;
            cursor: pointer;
        }

        .btn-custom:hover {
            background-color: #F2D64B;
            transform: scale(1.05);
            /* Efecto de agrandamiento en hover */
            color: #343F40;
        }

        .btn-warning {
            background-color: #000000;
            border: none;
        }

        .bton-warning: hover {
            background-color: #000000;
        }

        .btn.btn-danger {
            background-color: #000000;
            border: none;
        }

        .btn-secondary {
            color:
        }

        .btn-custom {
            padding: 0.375rem 0.75rem;
            font-family: inherit;
            color: #F2E74B;
            font-weight: 500;
            background-color: #000000;
        }

        .btn-secondary {
            background-color: #F2E74B;
            color: #000000;
        }

        label {
            margin-bottom: 7px;
            color: black;
        }

        input.form-control {
            background-color: #e9ecef;
        }

        .custom-select {
            background-color: #e9ecef;
        }

        .nav-tabs .nav-link {
            color: black;
            font-size: 18px;
        }

        .nav-tabs .nav-link.active {
            background-color: #8b8c64;
            color: white;
            border-color: black;
        }

        .tab-pane h5 {
            color: #000000;
            font-size: 1.2rem;
            font-weight: bold;
            margin-bottom: 10px;
        }

        .col-md-3.photo-wrapper {
            position: relative;
            height: auto;



        }


        .photo-container {
            position: relative;
            width: 70%;

            height: 320%;
            border: 1px solid black;
            border-radius: 8px;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            background-color: #f4f4f4;
            max-width: 250px;
            margin: 0 auto;
            overflow: hidden;



        }

        .photo-preview {
            width: 100%;
            height: 100px;
            border: 2px solid #ccc;
            background-color: #f4f4f4;
            text-align: center;
            line-height: 150px;
            color: #999;
            font-size: 14px;
            border-radius: 4px;
            overflow: hidden;
            pointer-events: none;
        }

        #photo-placeholder {
            display: block;
        }

        .photo.preview img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            border-radius: 4px;
        }

        #photo {
            position: absolute;
            width: 100%;
            height: 100%;
            opacity: 0;
            cursor: pointer;
        }
    </style>
</head>

<body>
<div class="container mt-5">
        <!-- Pestañas (Tabs) -->
        <ul class="nav nav-tabs" id="formTabs" role="tablist">
            <li class="nav-item" role="presentation">
                <a class="nav-link active" id="conductor-tab" data-bs-toggle="tab" href="#conductor" role="tab"
                    aria-controls="conductor" aria-selected="true">Conductor</a></li>

            <li class="nav-item" role="presentation">
                <a class="nav-link" id="descripDoc-tab" data-bs-toggle="tab" href="#descripDoc" role="tab"
                    aria-controls="descripDoc" aria-selected="false">Doc. inscripción</a>
            </li>
        </ul>

        <!-- Contenido de las Pestañas -->
        <div class="tab-content mt-4" id="formTabsContent">
            <!-- Formulario Conductor -->
            <div class="tab-pane fade show active" id="conductor" role="tabpanel" aria-labelledby="conductor-tab">

                <form>
                    <h5>Datos del Conductor</h5>

                    <div class="row mb-4">
                        <div class="col-md-3">
                            <label for="nombres">Nombres</label>
                            <input type="text" placeholder="Nombre"name="nombres" id="nombre" class="form-control" required>
                        </div>
                        <div class="col-md-3">
                            <label for="apellido_paterno">Apellido Paterno</label>
                            <input type="text" placeholder="Apellido Paterno" class="form-control" id="apellidoPaterno">
                        </div>
                        <div class="col-md-3">
                            <label for="apellido_materno">Apellido Materno</label>
                            <input type="text" placeholder="Apellido Materno" class="form-control" id="apellidoMaterno">
                        </div>

                        <div class="col-md-3">
                            <label for="correo">Correo</label>
                            <input type="text" name="correo" id="correo" class="form-control" required>
                        </div>
                    </div>

                </form>
            </div>

            <!----Formulario de Doc.inscripción--->
            <div class="tab-pane fade" id="descripDoc" role="tabpanel" aria-labelledby="descripDoc-tab">
                <form>
                    <h5>Detalle de Inscripción</h5>

                    <div class="form-section">
                        <h5 class="mb-3">COMENTARIOS ADICIONALES</h5>
                        <div class="row mb-4">
                            <div class="col-md-12">
                                <textarea id="comentarios" name="comentarios" class="form-control" rows="6"
                                    placeholder="Escribe tus comentarios aquí. .."></textarea>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>

        <!-- Botón para guardar al final -->
        <div class="text-center mt-4">
            <button id="registrar" class="btn btn-custom" onclick="saveChangesConductor(event)">Guardar Cambios</button>
           
            <button type="button" class="btn btn-danger" onclick="window.location.href='/arequipago/conductores';">Cerrar</button>
        </div>

        <div class="mt-4">
            <!-- Contenido vacío / espacio -->
        </div>
    </div>

<script>
    function chargedData() {
        var id_conductor = <?php echo json_encode($id_conductor); ?>;

        if (!id_conductor) {
            console.error('No conductor ID provided');
            return;
        }

        $.ajax({
            url: '/arequipago/chargedData-asesor', 
            type: 'GET',
            data: { id: id_conductor },
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    var data = response.data;
                    console.log("Datos del conductor:", data);

                    // Poblar solo los campos requeridos
                    document.getElementById('nombre').value = data.nombres;
                    document.getElementById('apellidoPaterno').value = data.apellido_paterno;
                    document.getElementById('apellidoMaterno').value = data.apellido_materno;
                    document.getElementById('correo').value = data.correo;
                    document.getElementById('comentarios').value = data.observacion.descripcion;
                } else {
                    console.error('Failed to fetch conductor data:', data.message);
                }
            },
            error: function(error) {
                console.error('Error fetching conductor data:', error);
            }
        });
    }

    function saveChangesConductor(event) {
        event.preventDefault();

        var formData = new FormData();
        var idConductor = "<?php echo $id_conductor; ?>";
        formData.append('id_conductor', idConductor);

        // Obtener los campos requeridos
        var elementos = {
            'nombres': document.getElementById('nombre'),
            'apellido_paterno': document.getElementById('apellidoPaterno'),
            'apellido_materno': document.getElementById('apellidoMaterno'),
            'correo': document.getElementById('correo'),
            'observacion': document.getElementById('comentarios') // No es obligatorio
        };

        var camposObligatorios = ['nombres', 'apellido_paterno', 'apellido_materno'];
        var camposFaltantes = [];

        for (var key of camposObligatorios) {
            if (!elementos[key] || !elementos[key].value.trim()) {
                camposFaltantes.push(key);
            }
        }

        if (camposFaltantes.length > 0) {
            Swal.fire({
                icon: 'error',
                title: 'Campos Incompletos',
                text: 'Por favor, complete todos los campos obligatorios.',
                confirmButtonText: 'Aceptar'
            }).then(() => {
                paintInput();
            });
            return;
        }

        // Agregar los valores al FormData
        for (var key in elementos) {
            formData.append(key, elementos[key] ? elementos[key].value.trim() : '');
        }

        // Mostrar mensaje de procesamiento
        Swal.fire({
            icon: 'info',
            title: 'Procesando',
            text: 'Los datos se están procesando',
            showConfirmButton: false,
            allowOutsideClick: false
        });

        // Enviar datos al servidor
        $.ajax({
            url: '/arequipago/ajs/actualizar/conductorofasesor',
            type: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            success: function (response) {
                Swal.close();
                try {
                    var res = JSON.parse(response); // Asegurar que la respuesta se maneje como JSON
                    if (res.status === "success") {
                        Swal.fire({
                            icon: 'success',
                            title: '¡Éxito!',
                            text: res.message,
                            confirmButtonText: 'Aceptar'
                        });
                    } else {
                        Swal.fire({
                            icon: 'error',
                            title: '¡Error!',
                            text: res.message || 'Hubo un problema con la actualización. Intenta nuevamente.',
                            confirmButtonText: 'Aceptar'
                        });
                    }
                } catch (e) {
                    console.error('Error al analizar la respuesta:', response);
                    Swal.fire({
                        icon: 'error',
                        title: '¡Error!',
                        text: 'Respuesta inesperada del servidor.',
                        confirmButtonText: 'Aceptar'
                    });
                }
            },
            error: function (xhr, status, error) {
                Swal.close();
                console.error('Detalles del error:', xhr.responseText);
                Swal.fire({
                    icon: 'error',
                    title: '¡Error!',
                    text: 'Error al actualizar los datos. Intenta nuevamente.',
                    confirmButtonText: 'Aceptar'
                });
            }
        });
    }

    function paintInput() {
        // Resetear el color de fondo de los inputs
        var allInputs = document.querySelectorAll("input, select");
        allInputs.forEach((input) => {
            input.style.backgroundColor = "";
        });

        // Elementos requeridos
        var elementos = {
            nombres: document.getElementById("nombre"),
            apellido_paterno: document.getElementById("apellidoPaterno"),
            apellido_materno: document.getElementById("apellidoMaterno"),
        };

        // Colorear los campos vacíos
        for (var key in elementos) {
            var elemento = elementos[key];
            if (elemento && !elemento.value) {
                elemento.style.backgroundColor = "#ff9999";
            }
        }
    }

    $(document).ready(function () {
        chargedData();
    });

</script>
</body>

