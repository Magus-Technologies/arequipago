<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Planes de Financiamiento</title>

    <style>
        .form-section {
            border: 2px solid #D7D7D7;
            padding: 20px;
            margin-bottom: 15px;
            border-radius: 8px;
            background-color: #FAFAFA;
            color: #000000;
            font-weight: normal;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease;
        }
        .form-section:hover {
            transform: translateY(-4px);
        }
        .btn-custom {
            background-color: #F2E74B;
            color: #343F40;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            font-weight: bold;
            transition: background-color 0.3s ease, transform 0.2s ease;
            cursor: pointer;
        }
        .btn-custom:hover {
            background-color: #F2D64B;
            transform: scale(1.05);
        }
        .nav-tabs .nav-link {
            color: black;
            font-size: 18px;
        }
        .nav-tabs .nav-link.active {
            background-color: #8b8c64;
            color: white;
            border-color: black;
        }
        .dropdown-list {
      position: absolute;
      background: white;
      border: 1px solid #ccc;
      border-radius: 5px;
      list-style: none;
      padding: 0;
      margin-top: 40px;
      width: 700px;
      box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);
      max-height: 200px;
      overflow-y: auto;
      z-index: 1000;
  }
  
  .dropdown-list li {
      padding: 10px;
      cursor: pointer;
      transition: background 0.3s;
  }
  
  .dropdown-list li:hover {
      background: #007bff;
      color: white;
  }

    </style>
</head>
<body>
    <div class="container mt-4">
        <ul class="nav nav-tabs" id="financiamientoTabs">
            <li class="nav-item">
                <a class="nav-link active" data-bs-toggle="tab" href="#planFinanciamiento">Plan Financiamiento</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" data-bs-toggle="tab" href="#asociarProducto">Asociar Producto</a>
            </li>
        </ul>
        <div class="tab-content mt-3">
            <div class="tab-pane fade show active" id="planFinanciamiento">
                <div class="form-section">
                    <h5>Registrar Plan de Financiamiento</h5>
                    <form id="formFinanciamiento"> <!-- Agregado id para referencia en JS -->
                        <div class="mb-3">
                            <label>Nombre del Plan</label>
                            <input type="text" class="form-control" name="nombre_plan" required> <!-- Agregado name -->
                        </div>
                        <div class="mb-3">
                            <label>Cuota Inicial</label> 
                            <input type="number" class="form-control" name="cuota_inicial" step="0.01" min="0"> <!-- 🔹 Agregado el campo de Cuota Inicial -->
                        </div>
                        <div class="mb-3">
                            <label>Monto de Cuota</label>
                            <input type="number" class="form-control" name="monto_cuota" required> <!-- Agregado name -->
                        </div>
                        <div class="mb-3">
                            <label>Cantidad de Cuotas</label>
                            <input type="number" class="form-control" name="cantidad_cuotas" required> <!-- Agregado name -->
                        </div>
                        <div class="mb-3">
                            <label>Tasa de Interés (%)</label> <!-- 🔹 Nuevo campo agregado -->
                            <input type="number" class="form-control" name="tasa_interes" step="0.01" min="0" required> <!-- 🔹 Campo nuevo para tasa_interes -->
                        </div>
                        <div class="row mb-3">
                            <div class="col-md-6 mb-3"> <!-- 🔹 Cambié 'col' por 'col-md-6' para que ocupe la mitad de la fila -->
                                <label>Frecuencia de Pago</label>
                                <select class="form-select" name="frecuencia_pago" required> <!-- Agregado name -->
                                    <option value="">Seleccione</option>
                                    <option value="mensual">Mensual</option>
                                    <option value="semanal">Semanal</option>
                                </select>
                            </div>
                            <div class="col-md-6 mb-3"> <!-- 🔹 Cambié 'col' por 'col-md-6' para que ocupe la mitad de la fila -->
                                <label for="moneda">Moneda:</label>
                                <select class="form-select" name="moneda" id="moneda"> <!-- 🔹 Agregado 'form-select' para que tenga el mismo estilo que el otro select -->
                                    <option value="S/.">Soles (S/.)</option>
                                    <option value="$">Dólares ($)</option>
                                </select>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-custom">Registrar</button>
                    </form>
                </div>

            </div>
            <div class="tab-pane fade" id="asociarProducto">
                <div class="form-section">
                    <h5>Asociar Producto</h5>
                    <form>
                        <div class="mb-3">
                            <label>Buscar Producto por Código o Nombre</label>
                            <input type="text" id="search_product" class="form-control" required>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-8">
                                <label>Producto</label>
                                <input type="text" id="product" class="form-control" required>
                            </div>
                            <div class="col-md-4">
                                <label>Opciones</label>
                                <select id="GrupoFinanciamiento" class="form-select" required>
                                    <option value="">Seleccione</option>    
                                    <option value="opcion1">Opción 1</option>
                                    <option value="opcion2">Opción 2</option>
                                </select>
                            </div>
                        </div>
                        <div class="mt-3">
                        <button type="button" id="asociar" onclick="saveAsociation()" class="btn btn-custom">Asociar Producto</button> 
                        </div>
                    </form>
                </div>
            </div>
            <div class="tab-pane fade" id="buscarProducto">
                <div class="form-section">
                    <h5>Buscar y Asignar Producto</h5>
                    <form>
                        
                    </form>
                </div>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<script>
function saveAsociation() {
    let productValue = $("#product").val().trim(); // Obtiene el valor del input y elimina espacios en blanco
    let planId = $("#GrupoFinanciamiento").val(); // Obtiene el ID del plan seleccionado

    if (!productValue || !planId) {
        alert("Por favor, ingrese un producto y seleccione un plan.");
        return;
    }

    let productCode = productValue.split('-')[0].trim(); // Obtiene solo el código antes del guion y elimina espacios

    $.ajax({
        url: "/arequipago/asociar",
        type: "POST",
        data: { codigo: productCode, id_plan: planId },
        dataType: "json",
        success: function (response) {
            if (response.success) {
                Swal.fire({ // 🔹 Reemplazado alert() por Swal.fire() en éxito
                    icon: "success",
                    title: "¡Éxito!",
                    text: "Producto asociado correctamente."
                });
                $("#product").val(""); // Limpia el input después de asociar
                $("#GrupoFinanciamiento").val(""); // Resetea el select
            } else {
                Swal.fire({ // 🔹 Reemplazado alert() por Swal.fire() en caso de error
                    icon: "error",
                    title: "Error",
                    text: "Error al asociar producto: " + response.message
                });
            }
        },
        error: function (xhr, status, error) {
            console.error("Error en la solicitud AJAX:", error);
            Swal.fire({ // 🔹 Reemplazado alert() por Swal.fire() en caso de error de AJAX
                icon: "error",
                title: "Error",
                text: "Hubo un problema al asociar el producto."
            });
        }
    });
}

        
        $(document).ready(function () {
        document.querySelector("#formFinanciamiento").addEventListener("submit", function (e) { // Cambié "form" por "#formFinanciamiento" para mayor precisión
        e.preventDefault();

        // Cambié los selectores para usar el atributo 'name' en vez de 'placeholder', porque no había placeholders en el HTML
        let nombrePlan = document.querySelector('input[name="nombre_plan"]').value.trim(); // Modificado
        let cuotaInicial = document.querySelector('input[name="cuota_inicial"]').value.trim() || "NULL"; // 🔹 Agregado para cuota inicial, si está vacío envía NULL
        let montoCuota = document.querySelector('input[name="monto_cuota"]').value.trim(); // Modificado
        let cantidadCuotas = document.querySelector('input[name="cantidad_cuotas"]').value.trim(); // Modificado
        let frecuenciaPago = document.querySelector('select[name="frecuencia_pago"]').value; // Modificado
        let moneda = document.querySelector('select[name="moneda"]').value; //
        let tasaInteres = document.querySelector('input[name="tasa_interes"]').value.trim();

        if (!nombrePlan || !montoCuota || !cantidadCuotas || !frecuenciaPago || !moneda || !tasaInteres) { 
            Swal.fire({
                icon: "error",
                title: "Oops...",
                text: "Todos los campos son obligatorios",
            });
            return;
        }

        let formData = new FormData();
        formData.append("nombre_plan", nombrePlan);
        formData.append("cuota_inicial", cuotaInicial); // 🔹 Agregado el envío de cuota inicial
        formData.append("monto_cuota", montoCuota);
        formData.append("cantidad_cuotas", cantidadCuotas);
        formData.append("frecuencia_pago", frecuenciaPago);
        formData.append("moneda", moneda);
        formData.append("tasa_interes", tasaInteres);

        fetch("/arequipago/save-newGroupFinance", { 
            method: "POST",
            body: formData,
        })
            .then((response) => response.json())
            .then((data) => {
                if (data.success) {
                    Swal.fire({
                        icon: "success",
                        title: "¡Éxito!",
                        text: "Plan de financiamiento registrado correctamente.",
                    });
                    document.querySelector("#formFinanciamiento").reset(); // Cambiado para que use el id del formulario
                } else {
                    Swal.fire({
                        icon: "error",
                        title: "Error",
                        text: data.message || "Hubo un problema al registrar.",
                    });
                }
            })
            .catch((error) => {
                console.error("Error:", error);
                Swal.fire({
                    icon: "error",
                    title: "Error",
                    text: "No se pudo conectar con el servidor.",
                });
            });
    });

    /*--------Código pra buscar productos ------*/
    const searchInput = document.getElementById("search_product");
    const productInput = document.getElementById("product");
    const scannerCheckbox = document.createElement("input");
    scannerCheckbox.type = "checkbox";
    scannerCheckbox.id = "use_scanner";
    const scannerLabel = document.createElement("label");
    scannerLabel.htmlFor = "use_scanner";
    scannerLabel.innerText = " Usar Scanner";
    searchInput.insertAdjacentElement("afterend", scannerCheckbox);
    scannerCheckbox.insertAdjacentElement("afterend", scannerLabel);
    
    const dropdown = document.createElement("ul");
    dropdown.classList.add("dropdown-list");
    searchInput.parentNode.insertBefore(dropdown, searchInput);
    
    let debounceTimer;
    
    searchInput.addEventListener("input", function () {
        clearTimeout(debounceTimer);
        dropdown.innerHTML = "";
        
        if (this.value.length > 0) {
            debounceTimer = setTimeout(() => {
                fetch(`/arequipago/consultar-productos-venta?searchTerm=${encodeURIComponent(this.value)}`)
                    .then(response => response.json())
                    .then(data => {
                        if (data.success && data.productos.length > 0) {
                            data.productos.forEach(producto => {
                                const listItem = document.createElement("li");
                                const codigo = producto.codigo || producto.codigo_barra;
                                listItem.innerText = `${codigo} - ${producto.nombre}`;
                                listItem.dataset.codigo = codigo;
                                listItem.dataset.nombre = producto.nombre;
                                listItem.addEventListener("click", function () {
                                    productInput.value = `${this.dataset.codigo} - ${this.dataset.nombre}`;
                                    dropdown.innerHTML = "";
                                });
                                dropdown.appendChild(listItem);
                            });
                            
                            if (scannerCheckbox.checked && data.productos.length === 1) {
                                setTimeout(() => {
                                    dropdown.firstChild.click();
                                    const enterEvent = new KeyboardEvent("keydown", { key: "Enter" });
                                    searchInput.dispatchEvent(enterEvent);
                                }, 2000);
                            }
                        }
                    })
                    .catch(error => console.error("Error en la búsqueda:", error));
            }, 300);
        }
    });
    
    document.addEventListener("click", function (e) {
        if (!searchInput.contains(e.target) && !dropdown.contains(e.target)) {
            dropdown.innerHTML = "";
        }
    });

    $.ajax({
        url: "/arequipago/getAllPlanes",
        type: "GET",
        dataType: "json",
        success: function (response) {
            if (response.success) {
                let select = $("#GrupoFinanciamiento");
                select.empty();
                select.append('<option value="">Seleccione</option>');

                response.planes.forEach(plan => {
                    let optionText = `${plan.nombre_plan} | S/.${plan.cuota_inicial} | ${plan.cantidad_cuotas} cuotas | ${plan.frecuencia_pago}`;
                    let option = `<option value="${plan.idplan_financiamiento}">${optionText}</option>`;
                    select.append(option);
                });
            }
        },
        error: function (xhr, status, error) {
            console.error("Error al obtener los planes:", error);
        }
    });
    
});



    </script>
</body>
</html>
