<table style="background-color: #bde9ba;">

    <thead>
        <tr>
            <th style="text-align:center">Nº Registro</th>
            <th>Tipo Doc.</th>
            <th>Documento</th>
            <th>Fecha Registro</th>
            <th>F. Vencimiento</th>
            <th>Codigo Cliente</th>
            <th>Nombre Cliente</th>
            <th>Sunat</th>
            <th>Moneda</th>
            <th>Total</th>
            <th>Saldo</th>
            <th>Glosa</th>
            <th>Total Convertido</th>
            <th>E</th>
            <th>Con Guía</th>
            <th>Vendedor</th>
            <th>Orden Compra</th>
            <th>Fecha Crea.</th>
            <th>Usuario Crea.</th>
            <th>Fecha Act.</th>
            <th>Usuario Act.</th>
            <th>Historial</th>

        </tr>
    </thead>
    <tbody>
    </tbody>
</table>