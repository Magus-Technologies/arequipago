<?php
$anio1 = date("Y");
$mes1 = date("m");
$anio2='';
$mes2='';
if ($mes1==1){
    $mes2='12';
    $anio2=$anio1-1;
}else{
    $anio2=$anio1;
    $mes2=$mes1-1;
}

$conexion = (new Conexion())->getConexion();

// Consulta SQL para contar los registros de conductores
$sql = "SELECT COUNT(*) AS total_conductores FROM conductores"; // Consulta para contar los conductores
$result = $conexion->query($sql); // Ejecutar la consulta
$row = $result->fetch_assoc(); // Obtener el resultado

// Obtener el número de conductores
$cantidad_conductores = $row['total_conductores'];

// Función para obtener los cumpleaños de la semana actual
function obtenerCumpleanosSemanales($conexion) {
    // Obtener fecha actual y calcular inicio y fin de semana
    $hoy = new DateTime();
    $inicioSemana = clone $hoy;
    $inicioSemana->modify('this week monday'); // Lunes de esta semana
    $finSemana = clone $inicioSemana;
    $finSemana->modify('+6 days'); // Domingo de esta semana
    
    // Formatear fechas para la consulta SQL
    $inicioSemanaStr = $inicioSemana->format('m-d');
    $finSemanaStr = $finSemana->format('m-d');
    
    // Consulta SQL para obtener conductores con cumpleaños en esta semana
    // Comparamos solo mes y día, ignorando el año
    $sql = "SELECT 
                id_conductor,
                nombres,
                apellido_paterno,
                apellido_materno,
                fech_nac,
                foto
            FROM 
                conductores 
            WHERE 
                DATE_FORMAT(fech_nac, '%m-%d') BETWEEN '$inicioSemanaStr' AND '$finSemanaStr'
            ORDER BY 
                DATE_FORMAT(fech_nac, '%m-%d') ASC
            LIMIT 5";
    
    $resultado = mysqli_query($conexion, $sql);
    
    if (!$resultado) {
        return []; // Retornar array vacío si hay error
    }
    
    return mysqli_fetch_all($resultado, MYSQLI_ASSOC);
}

// Obtener los cumpleaños de la semana para usarlos en el dashboard
$cumpleanosSemana = obtenerCumpleanosSemanales($conexion);

// 1. Conductores registrados por semana y por mes
$sql_conductores_semanal = "SELECT YEARWEEK(fecha_inscripcion, 1) AS semana, COUNT(*) AS total 
                             FROM inscripciones 
                             GROUP BY semana 
                             ORDER BY semana DESC";

$sql_conductores_mensual = "SELECT DATE_FORMAT(fecha_inscripcion, '%Y-%m') AS mes, COUNT(*) AS total 
                            FROM inscripciones 
                            GROUP BY mes 
                            ORDER BY mes DESC";

$result_conductores_semanal = $conexion->query($sql_conductores_semanal);
$result_conductores_mensual = $conexion->query($sql_conductores_mensual);

// 2. Pagos por inscripción (id_tipopago != 2) por semana y por mes
$sql_pagos_semanal = "SELECT YEARWEEK(fecha_pago, 1) AS semana, COUNT(*) AS total 
                      FROM conductor_pago 
                      WHERE id_tipopago != 2
                      GROUP BY semana 
                      ORDER BY semana DESC";

$sql_pagos_mensual = "SELECT DATE_FORMAT(fecha_pago, '%Y-%m') AS mes, COUNT(*) AS total 
                      FROM conductor_pago 
                      WHERE id_tipopago != 2
                      GROUP BY mes 
                      ORDER BY mes DESC";

$result_pagos_semanal = $conexion->query($sql_pagos_semanal);
$result_pagos_mensual = $conexion->query($sql_pagos_mensual);

// 3. Financiamientos de inscripciones (id_tipopago = 2) por semana y por mes
$sql_financiamiento_ins_semanal = "SELECT YEARWEEK(fecha_pago, 1) AS semana, COUNT(*) AS total 
                                   FROM conductor_pago 
                                   WHERE id_tipopago = 2
                                   GROUP BY semana 
                                   ORDER BY semana DESC";

$sql_financiamiento_ins_mensual = "SELECT DATE_FORMAT(fecha_pago, '%Y-%m') AS mes, COUNT(*) AS total 
                                   FROM conductor_pago 
                                   WHERE id_tipopago = 2
                                   GROUP BY mes 
                                   ORDER BY mes DESC";

$result_financiamiento_ins_semanal = $conexion->query($sql_financiamiento_ins_semanal);
$result_financiamiento_ins_mensual = $conexion->query($sql_financiamiento_ins_mensual);

// 4. Financiamientos de productos (fecha_creacion) por semana y por mes
$sql_financiamiento_prod_semanal = "SELECT YEARWEEK(fecha_creacion, 1) AS semana, COUNT(*) AS total 
                                    FROM financiamiento 
                                    GROUP BY semana 
                                    ORDER BY semana DESC";

$sql_financiamiento_prod_mensual = "SELECT DATE_FORMAT(fecha_creacion, '%Y-%m') AS mes, COUNT(*) AS total 
                                    FROM financiamiento 
                                    GROUP BY mes 
                                    ORDER BY mes DESC";

// Ejecutar las consultas de financiamiento de productos
$result_financiamiento_prod_semanal = $conexion->query($sql_financiamiento_prod_semanal); // Se agregó la ejecución de la consulta
$result_financiamiento_prod_mensual = $conexion->query($sql_financiamiento_prod_mensual); // Se agregó la ejecución de la consulta

// 4. Financiamientos de productos (fecha_creacion) por semana y por mes
$financiamientoProdSemanal = $result_financiamiento_prod_semanal->fetch_all(MYSQLI_ASSOC);
$financiamientoProdMensual = $result_financiamiento_prod_mensual->fetch_all(MYSQLI_ASSOC);


$conductoresSemanal = $result_conductores_semanal->fetch_all(MYSQLI_ASSOC);
$conductoresMensual = $result_conductores_mensual->fetch_all(MYSQLI_ASSOC);

$pagosSemanal = $result_pagos_semanal->fetch_all(MYSQLI_ASSOC);
$pagosMensual = $result_pagos_mensual->fetch_all(MYSQLI_ASSOC);

$financiamientoInsSemanal = $result_financiamiento_ins_semanal->fetch_all(MYSQLI_ASSOC);
$financiamientoInsMensual = $result_financiamiento_ins_mensual->fetch_all(MYSQLI_ASSOC);

$financiamientoProdSemanal = $result_financiamiento_prod_semanal->fetch_all(MYSQLI_ASSOC);
$financiamientoProdMensual = $result_financiamiento_prod_mensual->fetch_all(MYSQLI_ASSOC);

?>


<!-- start page title -->

<style>
    @media (min-width: 1200px) { /* Solo afecta a pantallas grandes */
        .custom-conductor-box {
            margin-top: 35px; /* Baja el cuadro 50px */
        }
    }

    .cantidad-conductores {
        margin-left: 29px; /* Ajusta el valor según necesites */
    }

    /* Fondo general del gráfico */
    .card {
        background-color: #bcbcbc ; /* Color de fondo más claro */
        border-radius: 10px;
        padding: 15px;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    }

    /* Título del gráfico */
    .card-title {
        color: #333; /* Color oscuro para mejor contraste */
        font-weight: bold;
        font-size: 1.2rem;
    }

    /* Estilización del botón de cambio de periodo */
    .form-check-label {
        color: #333;
    }

    .form-check-input:checked {
        background-color: #007bff;
        border-color: #007bff;
    }

    /* Estilos para el gráfico */
    canvas#chart-estadisticas {
        background-color: rgba(10, 10, 20, 0.95); /* Fondo blanco para mejor visibilidad */
        border-radius: 8px;
        padding: 10px;
        border: 1px solid #ddd;
    }

    /* Colores para las barras del gráfico */
    .chart-bar-1 {
        background-color: rgba(75, 192, 192, 0.5) !important;
        border-color: rgba(75, 192, 192, 1) !important;
    }

    .chart-bar-2 {
        background-color: rgba(255, 159, 64, 0.5) !important;
        border-color: rgba(255, 159, 64, 1) !important;
    }

    #chart-estadisticas {
    font-size: 14px !important;
    color: black !important;
    }

    #chart-estadisticas * {
        font-size: 14px !important;
        color: black !important;
    }

    .mini-stat-img {
        width: 65px !important;
        height: 40% !important; /* Reduce la altura */
    }

    .text-end{
        margin-right: -18px;
    }

    .form-switch .form-check-input {
        background-color: #eed8fc;
    }

    .form-switch .form-check-input {
        background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='-4 -4 8 8'%3e%3ccircle r='3' fill='%237852a2'/%3e%3c/svg%3e") !important;
    }

    /* Estilos para el componente de cumpleaños */
    .cumpleanos-lista {
        max-height: 250px;
        overflow-y: auto;
    }
    
    .cumpleanos-lista::-webkit-scrollbar {
        width: 5px;
    }
    
    .cumpleanos-lista::-webkit-scrollbar-thumb {
        background-color: #eed8fc;
        border-radius: 10px;
    }
    
    .cumpleanos-lista::-webkit-scrollbar-track {
        background-color: #f1f1f1;
        border-radius: 10px;
    }

    /* Actualizar los estilos del componente de cumpleaños */
    .cumpleanos-lista {
        scrollbar-width: thin;
        scrollbar-color: #eed8fc #f1f1f1;
    }

    .cumpleanos-lista::-webkit-scrollbar {
        width: 4px;
    }

    .cumpleanos-lista::-webkit-scrollbar-thumb {
        background-color: #eed8fc;
        border-radius: 4px;
    }

    .cumpleanos-lista::-webkit-scrollbar-track {
        background-color: #f1f1f1;
        border-radius: 4px;
    }
</style>
<div class="page-title-box">
    <div class="row align-items-center">
        <div class="col-md-8">
            <h6 class="page-title">Dashboard</h6>
            <ol class="breadcrumb m-10">
                <li class="breadcrumb-item active">Bienvenido al Sistema de <strong>AREQUIPAGO ERP</strong></li>
            </ol>
        </div>
        <div class="col-md-4">

        </div>
    </div>
</div>
<!-- end page title -->

<div class="row">
    <div class="col-xl-3 col-md-6">
        <div class="card mini-stat bg-white text-dark" style="border-radius:20px;box-shadow:0 4px 6px -1px rgba(0,0,0,.1),0 2px 4px -1px rgba(0,0,0,.06)" >
            <div class="card-body">
                <div class="mb-4">
                    <div class="position-absolute top-0 start-15 translate-middle border-radius-xl mini-stat-img mt-3 w-25 h-50" style="border-radius: 20px;background-color: #eed8fc;">
                        <img class="mt-3 mr-5" src="<?=URL::to('public/assets/images/services-icon/01.png')?>">
                    </div>
                    <h5 class="text-uppercase fw-light text-dark text-end">Monto Vendido</h5>
                    <h1 class="fw-bolder text-end">S/ 0.00</h1>
                    <!-- <div class="mini-stat-label bg-success">
                        <p class="mb-0">Mes</p>
                    </div> -->
                </div>
                <div class="pt-2">
                    <div class="float-end"  hidden>
                        <a href="javascript:void(0)" class="text-black-50"><i class="mdi mdi-arrow-right h5"></i></a>
                    </div>

                    <p class="text-dark-50 mb-0 mt-1 text-end">Facturas y Boletas</p>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-xl-3 col-md-6">
        <div class="card mini-stat bg-white text-dark" style="border-radius:20px;box-shadow:0 4px 6px -1px rgba(0,0,0,.1),0 2px 4px -1px rgba(0,0,0,.06)">
            <div class="card-body">
                <div class="mb-4">
                    <div class="position-absolute top-0 start-15 translate-middle border-radius-xl mini-stat-img mt-3 w-25 h-50" style="border-radius: 20px; background-color: #eed8fc;">
                        <img class="mt-3 mr-5" src="<?=URL::to('public/assets/images/services-icon/02.png')?>" alt="">
                    </div>
                    <h6 class="fw-light text-uppercase text-black text-end" style="margin-bottom: 20px; margin-right: -12px;" >Producto mas Vendido</h6>
                    <p  class="fw-bolder text-end" style="font-size: 17px;">Not data</p>
                    <div hidden class="mini-stat-label bg-danger">
                        <p class="mb-0">Total</p>
                    </div>
                </div>
                <div class="pt-2">
                    <div hidden class="float-end">
                        <a href="javascript:void(0)" class="text-white-50"><i class="mdi mdi-arrow-right h5"></i></a>
                    </div>

                    <p class="text-dark-50 mb-0 mt-1 text-end" >Cantidad Vendidas (0)</p>
                </div>
            </div>
        </div>
    </div>
    <div class="col-xl-3 col-md-6">
        <div class="card mini-stat bg-white text-dark" style="border-radius:20px;box-shadow:0 5px 6px -1px rgba(0,0,0,.1),0 2px 4px -1px rgba(0,0,0,.06)">
            <div class="card-body">
                <div class="mb-4">
                    <div  class="position-absolute top-0 start-15 translate-middle border-radius-xl mini-stat-img mt-3 w-25 h-50" style="border-radius: 20px; background-color: #eed8fc;">
                        <img class="mt-3 mr-5" src="<?=URL::to('public/assets/images/services-icon/03.png')?>" alt="">
                    </div>
                    <h5 class="fw-light text-uppercase text-black text-end">Total en Facturas</h5>
                    <h1 class="fw-bolder text-end">S/ 0.00</h1>
                    <!-- <div class="mini-stat-label bg-info">
                        <p class="mb-0"> Mes</p>
                    </div> -->
                </div>
                <div class="pt-2">
                    <div class="float-end">
                        <a href="javascript:void(0)" class="text-white-50"><i class="mdi mdi-arrow-right h5"></i></a>
                    </div>

                    <p class="text-white-50 mb-0 mt-1"> </p>
                </div>
            </div>
        </div>
    </div>
    <div class="col-xl-3 col-md-6">
        <div class="card mini-stat bg-white text-dark" style="border-radius:20px;box-shadow:0 4px 6px -1px rgba(0,0,0,.1),0 2px 4px -1px rgba(0,0,0,.06)">
            <div class="card-body">
                <div class="mb-4">
                    <div class="position-absolute top-0 start-15 translate-middle border-radius-xl mini-stat-img mt-3 w-25 h-50" style="border-radius: 20px; background-color: #eed8fc;">
                        <img class="mt-3 mr-5" src="<?=URL::to('public/assets/images/services-icon/04.png')?>" alt="">
                    </div>
                    <h5 class="fw-light text-uppercase text-black text-end">Total en Boletas</h5>
                    <h1 class="fw-bolder text-end">S/ 0.00 </h1>
                    <!-- <div class="mini-stat-label bg-warning">
                        <p class="mb-0">Mes</p>
                    </div> -->
                </div>
                <div class="pt-2">
                    <div class="float-end">
                        <a href="javascript:void(0)" class="text-white-50"><i class="mdi mdi-arrow-right h5"></i></a>
                    </div>

                    <p class="text-white-50 mb-0 mt-1"> </p>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-xl-3 col-md-6 custom-conductor-box"> 
        <div class="card mini-stat bg-white text-dark" style="border-radius:20px;box-shadow:0 4px 6px -1px rgba(0,0,0,.1),0 2px 4px -1px rgba(0,0,0,.06)"> <!-- Nuevo cuadro agregado -->
            <div class="card-body">
                <div class="mb-4">
                    <div class="position-absolute top-0 start-15 translate-middle border-radius-xl mini-stat-img mt-3 w-25 h-50" style="border-radius: 20px; background-color: #eed8fc;">
                        <img class="mt-3 mr-5" src="<?=URL::to('public/assets/images/services-icon/173-512.png')?>" alt="">
                    </div>
                    <h5 class="fw-light text-uppercase text-black text-end cantidad-conductores" style="font-size: 15px;">Cantidad de Conductores</h5> <!-- Reducido tamaño de letra con style -->
                    <h1 class="fw-bolder text-end" ><?= $cantidad_conductores ?></h1>
                </div>
                <div class="pt-2">
                    <div class="float-end">
                        <a href="javascript:void(0)" class="text-white-50"><i class="mdi mdi-arrow-right h5"></i></a>
                    </div>
                    <p class="text-white-50 mb-0 mt-1"></p>
                </div>
            </div>
        </div>
    </div>

    <!-- Reemplazar el componente de Cumpleaños de la Semana actual con este nuevo diseño -->
    <!-- Eliminar el código actual de Cumpleaños de la Semana que está en un solo div col-xl-3 col-md-6 -->

    <!-- Componente de Cumpleaños de la Semana (versión mejorada) -->
    <div class="col-xl-6 col-md-12">
    <div class="card border-0" style="border-radius:20px;box-shadow:0 10px 15px -3px rgba(120,82,162,0.2),0 4px 6px -2px rgba(120,82,162,0.1); background: linear-gradient(135deg, #f5f7fa 0%, #e4e8f0 100%);">
        <div class="card-body p-0">
            <div class="row g-0">
                <!-- Columna izquierda con título y decoración -->
                <div class="col-md-4 position-relative overflow-hidden">
                    <div class="h-100 d-flex flex-column justify-content-center p-4" style="border-radius: 20px 0 0 20px; background: linear-gradient(135deg, #7852a2 0%, #5e3d82 100%);">
                        <div class="position-absolute top-0 right-0 w-100 h-100 overflow-hidden opacity-20">
                            <div class="position-absolute" style="top: -20px; right: -20px; width: 140px; height: 140px; border-radius: 50%; background: rgba(255,255,255,0.2);"></div>
                            <div class="position-absolute" style="bottom: -30px; left: -30px; width: 180px; height: 180px; border-radius: 50%; background: rgba(255,255,255,0.15);"></div>
                        </div>
                        <div class="position-relative">
                            <div class="d-inline-flex align-items-center justify-content-center bg-white rounded-circle mb-3" style="width: 60px; height: 60px;">
                                <img src="<?=URL::to('public/assets/images/services-icon/gift-9.gif')?>" alt="Cumpleaños" class="w-75 h-75 object-fit-contain" style="background: transparent;">
                            </div>
                            <h4 class="text-white fw-bold mb-2">Cumpleaños de la Semana</h4>
                            <p class="text-white-50 mb-0">Celebremos juntos</p>
                            <div class="mt-4">
                                <div class="d-flex align-items-center">
                                    <div class=" bg-opacity-25 rounded-pill px-3 py-1" style="background-color: rgba(230, 59, 59, 0.2);">
                                        <span class="text-white small fw-bold">
                                            <?php 
                                                $inicioSemana = new DateTime();
                                                $inicioSemana->modify('this week monday');
                                                $finSemana = clone $inicioSemana;
                                                $finSemana->modify('+6 days');
                                                echo $inicioSemana->format('d M') . ' - ' . $finSemana->format('d M');
                                            ?>
                                        </span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Columna derecha con la lista de cumpleaños -->
                <div class="col-md-8">
                    <div class="p-4">
                        <div class="d-flex justify-content-between align-items-center mb-3">
                            <h6 class="fw-bold text-purple-800 mb-0" style="color: #5e3d82;">Próximos cumpleaños</h6>
                            <span class="badge rounded-pill px-3 py-2" style="background-color: #eed8fc; color: #5e3d82; font-weight: bold;">
                                <?= count($cumpleanosSemana) ?> personas
                            </span>
                        </div>
                        
                        <div class="cumpleanos-lista" style="max-height: 280px; overflow-y: auto;">
                            <?php if (empty($cumpleanosSemana)): ?>
                                <div class="text-center py-5">
                                    <div class="mb-3">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="text-muted opacity-50">
                                            <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path>
                                            <circle cx="12" cy="7" r="4"></circle>
                                        </svg>
                                    </div>
                                    <p class="text-muted mb-0">No hay cumpleaños esta semana</p>
                                </div>
                            <?php else: ?>
                                <?php 
                                    // Ordenar los cumpleaños: primero los de hoy, luego los próximos, luego los pasados
                                    $hoy = new DateTime();
                                    $cumpleanosPorCategoria = [
                                        'hoy' => [],
                                        'proximos' => [],
                                        'pasados' => []
                                    ];
                                    
                                    foreach ($cumpleanosSemana as $conductor) {
                                        $fechaNac = new DateTime($conductor['fech_nac']);
                                        $fechaCumpleEsteAnio = new DateTime($hoy->format('Y') . '-' . $fechaNac->format('m-d'));
                                        
                                        // Determinar si el cumpleaños es hoy
                                        if ($hoy->format('m-d') === $fechaNac->format('m-d')) {
                                            $cumpleanosPorCategoria['hoy'][] = $conductor;
                                        } 
                                        // Determinar si el cumpleaños es en el futuro (esta semana)
                                        elseif ($fechaCumpleEsteAnio > $hoy && $fechaCumpleEsteAnio->diff($hoy)->days < 7) {
                                            $cumpleanosPorCategoria['proximos'][] = $conductor;
                                        } 
                                        // Determinar si el cumpleaños ya pasó (esta semana)
                                        else {
                                            $cumpleanosPorCategoria['pasados'][] = $conductor;
                                        }
                                    }
                                    
                                    // Ordenar los próximos por fecha más cercana
                                    usort($cumpleanosPorCategoria['proximos'], function($a, $b) use ($hoy) {
                                        $fechaNacA = new DateTime($a['fech_nac']);
                                        $fechaNacB = new DateTime($b['fech_nac']);
                                        
                                        $fechaCumpleA = new DateTime($hoy->format('Y') . '-' . $fechaNacA->format('m-d'));
                                        $fechaCumpleB = new DateTime($hoy->format('Y') . '-' . $fechaNacB->format('m-d'));
                                        
                                        return $fechaCumpleA <=> $fechaCumpleB;
                                    });
                                    
                                    // Ordenar los pasados por fecha más reciente
                                    usort($cumpleanosPorCategoria['pasados'], function($a, $b) use ($hoy) {
                                        $fechaNacA = new DateTime($a['fech_nac']);
                                        $fechaNacB = new DateTime($b['fech_nac']);
                                        
                                        $fechaCumpleA = new DateTime($hoy->format('Y') . '-' . $fechaNacA->format('m-d'));
                                        $fechaCumpleB = new DateTime($hoy->format('Y') . '-' . $fechaNacB->format('m-d'));
                                        
                                        // Si la fecha ya pasó este año, ajustar para comparación
                                        if ($fechaCumpleA < $hoy) {
                                            $fechaCumpleA->modify('-1 day');
                                        }
                                        if ($fechaCumpleB < $hoy) {
                                            $fechaCumpleB->modify('-1 day');
                                        }
                                        
                                        // Orden inverso para que los más recientes aparezcan primero
                                        return $fechaCumpleB <=> $fechaCumpleA;
                                    });
                                    
                                    // Combinar las categorías en el orden deseado
                                    $cumpleanosOrdenados = array_merge(
                                        $cumpleanosPorCategoria['hoy'],
                                        $cumpleanosPorCategoria['proximos'],
                                        $cumpleanosPorCategoria['pasados']
                                    );
                                    
                                    // Colores para los avatares
                                    $colores = ['#7852a2', '#4a6bdf', '#df4a94', '#4adfb4', '#dfb44a'];
                                ?>
                                
                                <?php foreach ($cumpleanosOrdenados as $index => $conductor): ?>
                                    <?php 
                                        $fechaNac = new DateTime($conductor['fech_nac']);
                                        $hoy = new DateTime();
                                        $edad = $hoy->format('Y') - $fechaNac->format('Y');
                                        if ($hoy->format('m-d') < $fechaNac->format('m-d')) {
                                            $edad--;
                                        }
                                        
                                        $meses = ['enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio', 'julio', 'agosto', 'septiembre', 'octubre', 'noviembre', 'diciembre'];
                                        $mes = $meses[$fechaNac->format('n') - 1];
                                        $fechaFormateada = $fechaNac->format('d') . ' de ' . $mes;
                                        
                                        $nombreCompleto = $conductor['nombres'] . ' ' . $conductor['apellido_paterno'];
                                        $iniciales = mb_substr($conductor['nombres'], 0, 1) . mb_substr($conductor['apellido_paterno'], 0, 1);
                                        
                                        // Calcular días hasta/desde el cumpleaños
                                        $fechaCumpleEsteAnio = new DateTime($hoy->format('Y') . '-' . $fechaNac->format('m-d'));
                                        $esHoy = $hoy->format('m-d') === $fechaNac->format('m-d');
                                        
                                        // Determinar si el cumpleaños ya pasó este año
                                        $cumpleYaPaso = false;
                                        $diasDesde = 0;
                                        $diasHasta = 0;
                                        
                                        if ($fechaCumpleEsteAnio < $hoy) {
                                            $cumpleYaPaso = true;
                                            $diasDesde = $hoy->diff($fechaCumpleEsteAnio)->days;
                                            
                                            // Si pasaron más de 300 días, probablemente es del año pasado
                                            if ($diasDesde > 300) {
                                                $diasDesde = $diasDesde - 365;
                                            }
                                            
                                            // Para el próximo cumpleaños
                                            $fechaProximoCumple = clone $fechaCumpleEsteAnio;
                                            $fechaProximoCumple->modify('+1 year');
                                            $diasHasta = $hoy->diff($fechaProximoCumple)->days;
                                        } else {
                                            $diasHasta = $hoy->diff($fechaCumpleEsteAnio)->days;
                                        }
                                        
                                        // Colores para el avatar basados en el índice
                                        $colorIndex = $index % count($colores);
                                        $color = $colores[$colorIndex];
                                        
                                        // Determinar el estado y color del badge
                                        $badgeText = '';
                                        $badgeColor = '';
                                        $badgeBgColor = '';
                                        
                                        if ($esHoy) {
                                            $badgeText = 'Hoy';
                                            $badgeColor = 'white';
                                            $badgeBgColor = '#00c389'; // Verde
                                        } elseif ($cumpleYaPaso) {
                                            if ($diasDesde == 1) {
                                                $badgeText = 'Ayer';
                                                $badgeColor = 'white';
                                                $badgeBgColor = '#ff9500'; // Naranja
                                            } elseif ($diasDesde <= 7) {
                                                $badgeText = 'Hace ' . $diasDesde . ' días';
                                                $badgeColor = 'white';
                                                $badgeBgColor = '#ff9500'; // Naranja
                                            } else {
                                                $badgeText = 'En ' . $diasHasta . ' días';
                                                $badgeColor = '#6c757d';
                                                $badgeBgColor = '#e9ecef'; // Gris claro
                                            }
                                        } else {
                                            if ($diasHasta == 1) {
                                                $badgeText = 'Mañana';
                                                $badgeColor = 'white';
                                                $badgeBgColor = '#007bff'; // Azul
                                            } else {
                                                $badgeText = 'En ' . $diasHasta . ' días';
                                                $badgeColor = 'white';
                                                $badgeBgColor = '#007bff'; // Azul
                                            }
                                        }
                                    ?>
                                    <div class="d-flex align-items-center p-3 <?= $index < count($cumpleanosOrdenados) - 1 ? 'border-bottom' : '' ?> <?= $esHoy ? 'bg-light rounded-3' : '' ?>">
                                        <div class="flex-shrink-0 position-relative">
                                            <?php if (!empty($conductor['foto'])): ?>
                                                <div class="rounded-circle overflow-hidden" style="width: 50px; height: 50px; border: 3px solid <?= $color ?>;">
                                                    <img src="<?=URL::to('public/' . $conductor['foto'])?>" alt="<?=$nombreCompleto?>" class="w-100 h-100 object-fit-cover">
                                                </div>
                                            <?php else: ?>
                                                <div class="rounded-circle d-flex align-items-center justify-content-center text-white" 
                                                     style="width: 50px; height: 50px; background-color: <?= $color ?>; border: 3px solid rgba(255,255,255,0.3); font-weight: bold;">
                                                    <?=$iniciales?>
                                                </div>
                                            <?php endif; ?>
                                            <?php if ($esHoy): ?>
                                                <div class="position-absolute bottom-0 end-0 bg-success rounded-circle d-flex align-items-center justify-content-center" 
                                                     style="width: 20px; height: 20px; border: 2px solid white;">
                                                    <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" class="text-white">
                                                        <path d="M20 6L9 17l-5-5"></path>
                                                    </svg>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                        <div class="ms-3 flex-grow-1">
                                            <div class="d-flex justify-content-between align-items-center">
                                                <h6 class="mb-0 fw-semibold"><?=mb_strimwidth($nombreCompleto, 0, 20, "...")?></h6>
                                                <span class="badge rounded-pill px-2 py-1" style="background-color: <?= $badgeBgColor ?>; color: <?= $badgeColor ?>;">
                                                    <?= $badgeText ?>
                                                </span>
                                            </div>
                                            <div class="d-flex align-items-center mt-1">
                                                <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="color: #7852a2;" class="me-1">
                                                    <rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect>
                                                    <line x1="16" y1="2" x2="16" y2="6"></line>
                                                    <line x1="8" y1="2" x2="8" y2="6"></line>
                                                    <line x1="3" y1="10" x2="21" y2="10"></line>
                                                </svg>
                                                <span class="text-muted small"><?=$fechaFormateada?></span>
                                                <div class="ms-2 d-flex align-items-center">
                                                    <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="color: #7852a2;" class="me-1">
                                                        <path d="M20.59 13.41l-7.17 7.17a2 2 0 0 1-2.83 0L2 12V2h10l8.59 8.59a2 2 0 0 1 0 2.82z"></path>
                                                        <line x1="7" y1="7" x2="7.01" y2="7"></line>
                                                    </svg>
                                                    <span class="text-muted small">
                                                        <?= $cumpleYaPaso ? $edad + 1 : $edad ?> años
                                                    </span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

</div>
<!-- end row -->

    <div class="row">
        <div class="col-xl-12">
            <div class="card">
                <div class="card-body h-50">
                    <h4 class="card-title mb-4">Estadísticas</h4>
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <span class="text-muted">Filtrar por:</span>
                        <div class="form-check form-switch">
                            <input class="form-check-input" type="checkbox" id="switchPeriodo">
                            <label class="form-check-label" for="switchPeriodo">Semana / Mes</label>
                        </div>
                    </div>
                    <canvas id="chart-estadisticas"></canvas>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-xl-12">
            <div class="card">
                <div class="card-body h-50">
                    <h4 class="card-title mb-4">Venta Anual</h4>
                    <div class="row">
                        <div class="col-lg-7">
                            <div>
                                <canvas id="chart-with-area" >
                                </canvas>
                            </div>
                        </div>
                        <div class="col-lg-5">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="text-center">
                                        <p class="text-muted mb-4">Este Mes</p>
                                        <h3>S/ 0.00 </h3>
                                        <p class="text-muted mb-5">Ganancias Totales.</p>
                                        <span class="peity-donut"
                                            data-peity='{ "fill": ["#02a499", "#f2f2f2"], "innerRadius": 28, "radius": 32 }'
                                            data-width="72" data-height="72"></span>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="text-center">
                                        <p class="text-muted mb-4">Mes Anterior</p>
                                        <h3>S/ 0.00 </h3>
                                        <p class="text-muted mb-5">Comparativa Ganancias Totales.</p>
                                        <span class="peity-donut"
                                            data-peity='{ "fill": ["#02a499", "#f2f2f2"], "innerRadius": 28, "radius": 32 }'
                                            data-width="72" data-height="72"></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- end row -->
                </div>
            </div>
            <!-- end card -->
        </div>

    </div>
    <!-- end row -->

<!---<textarea style="display: none" id="listatempdata"><?=json_encode($dataListVen)?></textarea>--->


<textarea style="display: none" id="data-conductores-semanal"><?=json_encode($conductoresSemanal)?></textarea>
<textarea style="display: none" id="data-conductores-mensual"><?=json_encode($conductoresMensual)?></textarea>

<textarea style="display: none" id="data-pagos-semanal"><?=json_encode($pagosSemanal)?></textarea>
<textarea style="display: none" id="data-pagos-mensual"><?=json_encode($pagosMensual)?></textarea>

<textarea style="display: none" id="data-financiamiento-ins-semanal"><?=json_encode($financiamientoInsSemanal)?></textarea>
<textarea style="display: none" id="data-financiamiento-ins-mensual"><?=json_encode($financiamientoInsMensual)?></textarea>

<textarea style="display: none" id="data-financiamiento-prod-semanal"><?=json_encode($financiamientoProdSemanal)?></textarea>
<textarea style="display: none" id="data-financiamiento-prod-mensual"><?=json_encode($financiamientoProdMensual)?></textarea>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chartjs-plugin-zoom"></script>


<script>
    $(document).ready(function (){
       
       function cambiarGrafico(modo) {
            if (modo === 'mensual') {
                cargarGraficoMensual();
            } else if (modo === 'semanal') {
                // Limpiar gráfico existente
                if (miGrafico) {
                    miGrafico.destroy();
                }
                
                // Reiniciar variables globales si las usas
                datosSemanales = [];
                
                // Volver a ejecutar la función original
                cargarGraficoSemanal();
            }
        }

        console.log("Depuración de datos desde PHP:");

        function printJson(id, data) {
            let jsonData = JSON.stringify(data);
            console.log(id, jsonData);
            document.getElementById(id).value = jsonData;
        }

        printJson("data-conductores-semanal", <?php echo json_encode($conductoresSemanal); ?>);
        printJson("data-conductores-mensual", <?php echo json_encode($conductoresMensual); ?>);

        printJson("data-pagos-semanal", <?php echo json_encode($pagosSemanal); ?>);
        printJson("data-pagos-mensual", <?php echo json_encode($pagosMensual); ?>);

        printJson("data-financiamiento-ins-semanal", <?php echo json_encode($financiamientoInsSemanal); ?>);
        printJson("data-financiamiento-ins-mensual", <?php echo json_encode($financiamientoInsMensual); ?>);

        printJson("data-financiamiento-prod-semanal", <?php echo json_encode($financiamientoProdSemanal); ?>);
        printJson("data-financiamiento-prod-mensual", <?php echo json_encode($financiamientoProdMensual); ?>);
        

        let ctx = document.getElementById("chart-estadisticas").getContext("2d");

        function parseData(id) {
            let el = document.getElementById(id);
            return el && el.value ? JSON.parse(el.value) : [];
        }

        let datosSemanal = {
            conductores: parseData("data-conductores-semanal"),
            pagos: parseData("data-pagos-semanal"),
            financiamientoIns: parseData("data-financiamiento-ins-semanal"),
            financiamientoProd: parseData("data-financiamiento-prod-semanal")
        };

        let datosMensual = {
            conductores: parseData("data-conductores-mensual"),
            pagos: parseData("data-pagos-mensual"),
            financiamientoIns: parseData("data-financiamiento-ins-mensual"),
            financiamientoProd: parseData("data-financiamiento-prod-mensual")
        };

        let estadoActual = "semanal";

        function formatearSemana(semana) {
            if (!semana || semana.length < 6) return ""; // 🔹 Validación agregada para evitar errores si semana es undefined
            return semana.slice(0, 4) + "-" + semana.slice(4);
        }

        function obtenerDatos(estado) {
            let datos = estado === "semanal" ? datosSemanal : datosMensual;
            
            if (!datos.conductores || datos.conductores.length === 0) {
                console.warn(`⚠️ No hay datos disponibles para ${estado}`);
                return {
                    labels: [],
                    datasets: []
                };
            }

            datos.conductores.sort((a, b) => {
                let anioA = parseInt(a.semana ? a.semana.slice(0, 4) : (a.mes ? a.mes.slice(0, 4) : "0")); // ✅ Validación adicional
                let semanaA = parseInt(a.semana ? a.semana.slice(4) : "0");
                let mesA = parseInt(a.mes ? a.mes.slice(4) : "0"); // Extrae el mes si es mensual
                let anioB = parseInt(b.semana ? b.semana.slice(0, 4) : b.mes.slice(0, 4));
                let mesB = parseInt(b.mes ? b.mes.slice(4) : "0");
                let semanaB = parseInt(b.semana ? b.semana.slice(4) : "0");
                
                if (anioA === anioB) {
                    if (mesA === mesB) {
                        return semanaA - semanaB;
                    }
                    return mesB - mesA; // 🔹 Ordena los meses en orden ascendente
                }
                return anioA - anioB;
            }); // 🔹 Se corrigió la lógica de ordenación de meses dentro del mismo año
                    
            let labels = datos.conductores.map(item => item.semana ? formatearSemana(item.semana) : (item.mes || "")); 
           
         
            return {
                labels: labels,
                datasets: [
                    {
                        label: "Conductores Registrados",
                        data: datos.conductores.map(item => item.total || 0), 
                        backgroundColor: "rgba(75, 192, 192, 0.5)",
                        borderColor: "rgba(75, 192, 192, 1)",
                        borderWidth: 1
                    },
                    {
                        label: "Pagos por Inscripción",
                        data: datos.pagos.map(item => item.total || 0),
                        backgroundColor: "rgba(238, 216, 252, 0.5)",
                        borderColor: "rgba(238, 216, 252, 1)",
                        borderWidth: 1,
                        color: "#ffffff" // Letras blancas para mayor contraste
                    },
                    {
                        label: "Financiamientos de Inscripciones",
                        data: datos.financiamientoIns.map(item => item.total || 0),
                        backgroundColor: "rgba(252, 243, 75, 0.5)",
                        borderColor: "rgba(252, 243, 75, 1)",
                        borderWidth: 1
                    },
                    {
                        label: "Financiamiento de Productos",
                        data: datos.financiamientoProd.map(item => item.total || 0),
                        backgroundColor: "rgba(255, 99, 132, 0.5)",
                        borderColor: "rgba(255, 99, 132, 1)",
                        borderWidth: 1
                    }
                ]
            };
        }

        console.log("Plugins registrados:", Chart.register);

        if (typeof ChartZoom !== "undefined") {
            Chart.register(ChartZoom); // ✅ Si ChartZoom está definido, se registra
        } else if (typeof window !== "undefined" && window.chartjsPluginZoom) {
            Chart.register(window.chartjsPluginZoom); // ✅ Alternativa si está en window
        } else {
            console.warn("⚠️ Plugin 'chartjs-plugin-zoom' no encontrado.");
        }



        let chart = new Chart(ctx, {
            type: "bar",
            data: obtenerDatos(estadoActual),
            options: {
                plugins: {
                    zoom: {
                        pan: {
                            enabled: true,
                            mode: 'x',
                        },
                        zoom: {
                            wheel: {
                                enabled: true,
                            },
                            pinch: {
                                enabled: true
                            },
                            mode: 'x'
                        }
                    },
                    legend: {
                        labels: {
                            font: { size: 14, weight: "bold" }, // 🔹 Letras más nítidas en la leyenda
                            color: "white", // 🔹 Color blanco para visibilidad
                            textShadow: "0px 0px 5px #ffffff" // 🔹 Efecto de brillo sutil
                        }
                    }
                },
                scales: {
                    x: { 
                        beginAtZero: true,
                        ticks: { 
                            font: { size: 14, weight: "bold" }, // 🔹 Letras más nítidas en negrita
                            color: "#00FFFF", // 🔹 Color azul neón para contraste futurista
                            textShadow: "0px 0px 8px #00FFFF" // 🔹 Efecto de brillo en el texto
                        },
                        grid: {
                            color: "rgba(0, 255, 255, 0.3)" // 🔹 Líneas azules neón semi-transparente en X
                        }
                    },
                    y: { 
                        beginAtZero: true,
                        ticks: { 
                            font: { size: 14, weight: "bold" }, // 🔹 Letras más nítidas en negrita
                            color: "#00FFFF", // 🔹 Color azul neón para contraste futurista
                            textShadow: "0px 0px 8px #00FFFF" // 🔹 Efecto de brillo en el texto
                        },
                        grid: {
                            color: "rgba(0, 255, 255, 0.3)" // 🔹 Líneas azules neón semi-transparente en Y
                        }
                    }
                },
                layout: {
                    padding: 20 // 🔹 Margen interno para evitar que las etiquetas queden pegadas
                },
                animation: {
                    duration: 1500, // 🔹 Animación de entrada más fluida
                    easing: "easeInOutQuart" // 🔹 Suaviza la animación para que se vea más profesional
                },
                backgroundColor: "rgba(10, 10, 20, 0.95)", // 🔹 Fondo negro con leve transparencia para efecto "holográfico"
                elements: {
                    bar: {
                        backgroundColor: [
                            "rgba(0, 255, 255, 0.6)", // 🔹 Barras con colores neón (cyan)
                            "rgba(255, 0, 255, 0.6)", // 🔹 Magenta
                            "rgba(255, 255, 0, 0.6)", // 🔹 Amarillo
                            "rgba(0, 255, 0, 0.6)"  // 🔹 Verde neón
                        ],
                        borderColor: [
                            "rgba(0, 255, 255, 1)", // 🔹 Borde más brillante para el efecto futurista
                            "rgba(255, 0, 255, 1)",
                            "rgba(255, 255, 0, 1)",
                            "rgba(0, 255, 0, 1)"
                        ],
                        borderWidth: 2, // 🔹 Bordes más marcados para un estilo elegante
                        borderRadius: 8 // 🔹 Esquinas redondeadas para que se vea más moderno
                    }
                }
            }
        });

    
$("#switchPeriodo").on("change", function() {
    let nuevoEstado = $(this).is(":checked") ? "mensual" : "semanal";

    console.log(`📊 Cambiando a ${nuevoEstado}`);

    let datos = obtenerDatos(nuevoEstado);

    if (!datos || !datos.labels || datos.labels.length === 0) {
        console.warn(`⚠️ No hay datos para ${nuevoEstado}, no se actualizará el gráfico.`);
        return;
    }

    // 🔥 Forzar actualización reemplazando completamente los datos
    chart.data = {
        labels: datos.labels,
        datasets: datos.datasets
    };

    chart.update();

    // Actualizar el estado después de haber cambiado los datos
    estadoActual = nuevoEstado;
});





    });
</script>

