<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start(); // Aseguramos que la sesión está iniciada
}

// Verificamos si el usuario tiene sesión activa
$id_rol = $_SESSION['id_rol'] ?? null;
?>

<!DOCTYPE html>
<html lang="es">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Financiamiento CrediGO</title>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.min.js"></script>

    
    <style>


        
        /* Navbar personalizada */
        .navbar-custom {
            border: 2px groove #4fa7ff;
            box-shadow: 0 4px, 6px, rgba(0, 0, 0, 0.1);
            background-color: transparent;
        }

        .navbar-custom .nav-link {
            color: blue;
        }

        .navbar-custom .nav-link.active {
            background-color: #eed8fc;
            color: black;
            font-weight: bold;
        }

        .navbar-custom .nav-link:hover {
            color: #007bff;
        }

        /* Botón primary personalizado */
        .btn-primary {
            padding: 0.375rem 0.75rem;
            font-family: inherit;
            color: #F2E74B;
            font-weight: 500;
            background-color: #000000;   
            border: none;     
        }

        .btn-primary:hover {
            background-color: #8b8c64;
        }

        /* Botón info personalizado */
        .btn-info {
            background-color: #000000;
            border: none;
            color: white;
        }

        .btn-info:hover {
            background-color: #8b8c64;
        }

        /* Formulario de nuevo financiamiento */
        #nuevoFinanciamientoForm {
            
            padding-top: 10px;  /* Ajusta el valor según lo necesites */
            padding-right: 5px; /* Mantén el padding a la derecha igual */
            padding-bottom: 20px; /* Mantén el padding abajo igual */
            padding-left: 5px; /* Mantén el padding a la izquierda igual */
            border-radius: 8px;
            width: 100%;
            margin: 0 auto;
        }

        /* Card personalizada para el formulario */
        #formularioNuevoFinanciamiento .card-custom {
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        #formularioNuevoFinanciamiento .card-header {
            background-color: #8b8c64;
            color: white;
        }

        /* Input y select con border-radius */
        #formularioNuevoFinanciamiento .form-control, 
        #formularioNuevoFinanciamiento .form-select {
            border-radius: 8px;
            padding: 12px;
        }

        /* Botones personalizados */
        .btn-custom {
            border-radius: 6px;
            padding: 10px 20px;
            font-size: 16px;
            margin-top: 10px;
            width: 160px;  /* Ancho reducido */
        }

        .btn-amarillo-negro {
            background-color: #f2e74b;
            color: black;
            padding: 0.375rem 0.5rem; /* Padding vertical y horizontal reducido */
            font-family: inherit;
            font-weight: bold; /* Fuente en negrita */
            font-size: 1rem; /* Fuente ligeramente más grande */ 
        }

        .btn-amarillo-negro:hover {
            background-color: #8b8c64;
        }

        .btn-amarillo-blanco {
            background-color: #f4c542;
            color: white;
        }

        .btn-negro-blanco {
            background-color: #000000;
            color: white;
            padding: 0.360rem 0.3rem; /* Padding vertical y horizontal reducido */
            font-size: 1rem; /* Fuente ligeramente más grande */
        }

        .btn-negro-blanco:hover {
            background-color: #8b8c64;
        }

        /* Clase para ocultar elementos */
        .d-none {
            display: none;
        }

        /* Estilo para la tabla de clientes */
        .client-table {
            box-shadow: 4px 4px 10px rgba(0, 0, 0, 0.2); /* sombra abajo y a la izquierda */
        }

        /* Información rápida */
        .info-rapida {
            background-color: #eed8fc;
            padding: 2rem;
            border-radius: 35px;
        }

        /* Estilos para el contenedor del título */
        .titulo-container {
            background-color: #d5d696; /* Color de fondo para el título */
            width: 100%; /* Ancho reducido para que no ocupe todo el espacio (puedes ajustar este valor) */
            
            padding: 10px; /* Padding alrededor del título */
            border-radius: 5px; /* Bordes redondeados si lo deseas */
        }

        /* Estilo opcional para el texto del título */
        .titulo-container h5 {
            font-weight: bold; /* Fuente en negrita */
           
        }

        #CardModify {
            background: #f9f9f9;
            padding-top: 20px;
            padding-right: 20px; /* Mantén el padding a la derecha igual */
            padding-bottom: 20px; /* Mantén el padding abajo igual */
            padding-left: 20px; /* Mantén el padding a la izquierda igual */
            Width: 100%;
        }

        

        #listaAutomatic {
            max-height: 200px;
            overflow-y: auto;
            position: absolute;
            z-index: 1000;
            width: 45%;
        }

        #listaAutomatic li {
            cursor: pointer;
        }
        
        #listaAutomatic li:hover {
            background-color: #d0f0fc;
            cursor: pointer;
            
        }

        #listaNumDoc li{
            cursor: pointer;
        }

        #listaNumDoc li:hover {
            background-color: #d0f0fc;
            cursor: pointer;
            
        }

        /* Estilo específico para la tabla dentro del contenedor con ID tablaProductosContainer */
        #tablaProductosContainer .table {
            border-radius: 8px; /* Redondear esquinas */
            overflow: hidden; /* Evitar desbordamiento */
        }

        #tablaProductosContainer thead {
            background-color: #e4eef7; /* Gris azulado claro */
            color: #000; /* Texto negro */
        }

        #tablaProductosContainer tbody tr {
            background-color: #fff; /* Fondo blanco */
            font-size: 14px; /* Reducir tamaño del texto */
        }

        #tablaProductosContainer tbody tr td {
            vertical-align: middle; /* Centrar contenido verticalmente */
        }

        #tablaProductosContainer th,
        #tablaProductosContainer td {
            text-align: center; /* Centrar contenido */
        }

        #tablaProductosContainer th:first-child,
        #tablaProductosContainer td:first-child {
            width: 50px; /* Reducir ancho de la columna Seleccionar */
        }

        #tablaProductosContainer .btn {
            border-radius: 4px; /* Botones ligeramente redondeados */
        }

        .producto-seleccionado {
            background-color: #d4edda !important; /* Verde claro */
        }

        /* Estilos específicos para el formulario de Generar Contratos */
        .generar-contratos-container {
            font-family: Arial, sans-serif;
            margin: 20px auto;
            max-width: 800px;
            border: 1px solid #ccc;
            border-radius: 8px;
            padding: 20px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .generar-contratos-container h1 {
            text-align: center;
            color: #333;
        }

        .generar-contratos-container .filtro {
            margin-bottom: 20px;
        }

        .generar-contratos-container .filtro label {
            font-weight: bold;
            display: block;
            margin-bottom: 8px;
        }

        .generar-contratos-container .filtro input[type="text"] {
            width: 100%;
            padding: 8px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        .generar-contratos-container .filtro button {
            padding: 10px 20px;
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        .generar-contratos-container .filtro button:hover {
            background-color: #0056b3;
        }

        .generar-contratos-container .tabla-financiamientos {
            margin-top: 20px;
            overflow-x: auto;
        }

        .generar-contratos-container table {
            width: 100%;
            border-collapse: collapse;
        }

        .generar-contratos-container table th, 
        .generar-contratos-container table td {
            padding: 10px;
            text-align: left;
            border: 1px solid #ccc;
        }

        .generar-contratos-container table th {
            background-color: #f4f4f4;
            font-weight: bold;
        }

        .generar-contratos-container .acciones button {
            padding: 5px 10px;
            margin-right: 5px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        .generar-contratos-container .acciones .ver {
            background-color: #28a745;
            color: white;
        }

        .generar-contratos-container .acciones .ver:hover {
            background-color: #218838;
        }

        .generar-contratos-container .acciones .eliminar {
            background-color: #dc3545;
            color: white;
        }

        .generar-contratos-container .acciones .eliminar:hover {
            background-color: #c82333;
        }

        .generar-contratos-container .rango-fechas {
            margin-top: 20px;
        }

        .generar-contratos-container .rango-fechas label {
            font-weight: bold;
            display: block;
            margin-bottom: 8px;
        }

        .generar-contratos-container .rango-fechas input {
            width: calc(50% - 10px);
            padding: 8px;
            margin-right: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        .generar-contratos-container .boton-generar {
            margin-top: 20px;
            text-align: center;
        }

        .generar-contratos-container .boton-generar button {
            padding: 10px 20px;
            background-color: #ffc107;
            color: #333;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        .generar-contratos-container .boton-generar button:hover {
            background-color: #e0a800;
        }

        #financiamientoModal {
            background-color: #1f1f1f; /* Fondo oscuro */
            color: white; /* Texto blanco */
            border-radius: 10px; /* Bordes redondeados */
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.6), 0 0 20px #0867d2, 0 0 30px #0867d2; /* Efecto de neón turquesa */
            border: 2px solid transparent; /* Borde transparente para el efecto de neón */
            position: relative;
            font-family: 'Arial', sans-serif; /* Arial sin negrita */
            font-weight: normal; /* Asegura que el texto no esté en negrita */
        }

        /* Efecto de neón turquesa en el borde */
        @keyframes neonGlow {
            0% {
                border-color: #0867d2;
                box-shadow: 0 0 10px #0867d2, 0 0 20px #0867d2, 0 0 30px #0867d2;
            }
            100% {
                border-color: white;
                box-shadow: 0 0 10px white, 0 0 20px white, 0 0 30px white;
            }
        }

    #financiamientoModalHeader {
        background-color: #fcf34b; /* Azul */
        color: black; /* Texto blanco */
        border-bottom: 2px solid #0a0a0c; /* Línea de separación */
    }

    #financiamientoModal .modal-title {
        font-size: 1.5rem;
    }

    #financiamientoModalBody {
        padding: 20px;
        font-family: 'Arial', sans-serif; /* Arial sin negrita */
        font-weight: normal;
    }

    #financiamientoModalSection {
        margin-bottom: 20px;
    }

    #financiamientoModalSection h6 {
        color: #fcf34b; /* Títulos de las secciones en color morado */
        font-size: 1.2rem;
        margin-bottom: 10px;
    }

    #financiamientoModalSection ul {
        list-style-type: none;
        padding-left: 0;
    }

    #financiamientoModalSection li {
        margin-bottom: 8px;
        font-size: 1rem;
    }

    #financiamientoModalFooter {
        background-color: #0867d2; /* Azul */
        border-top: 2px solid #0a0a0c;
    }

    #financiamientoModalCloseBtn {
        
        color: #8b8c64;
        width: 60px; 
        height: auto; /* Texto en color oscuro */
    }

    #financiamientoModalCloseBtn:hover {
        background-color: Black; /* Azul cuando se pasa el ratón */
        color: white;
    }

    #financiamientoModalClose {
        background-color: transparent;
        color: white;
    }

    /* Estilo para los inputs coloreados */
    .colorCharged {
        background-color: #9cccf2; /* Color que deseas cuando el input está vacío */
        
    }

    #cronogramaSelect { /* Aplicado CSS solo al select por ID */
        border-collapse: collapse;
        margin-top: 5px; /* Espaciado con la caja */
    }
    #cronogramaSelect th, #cronogramaSelect td { /* Estilo de celdas */
        border: 1px solid #ccc;
        padding: 8px;
        text-align: center;
    }
    #cronogramaSelect tr:hover { /* Resaltar al pasar el mouse */
        background-color: #e0e0e0;
    }
    .fila-seleccionada { /* Resaltar fila seleccionada */
        background-color: rgb(37, 150, 190) !important;
        color: white;
    }

    #detalleSelect { /* Aplicado CSS solo al select por ID */
        border-collapse: collapse;
        margin-top: 5px; /* Espaciado con la caja */
    }
    #detalleSelect th, #detalleSelect td { /* Estilo de celdas */
        border: 1px solid #ccc;
        padding: 8px;
        text-align: center;
    }
    #detalleSelect tr:hover { /* Resaltar al pasar el mouse */
        background-color: #e0e0e0;
    }
    .fila-seleccionada { /* Resaltar fila seleccionada */
        background-color: rgb(37, 150, 190) !important;
        color: white;
    }
            
    </style>
    </head>

    <body>

        <div class="container-custom">

            <div class="row mb-3">
                <div class="col-12">
                    <br><h2 class="text-center mb-4">Financiamiento CrediGO</h2>
                </div>

                <nav class="navbar-custom">
                    <ul class="nav justify-content-center">
                        <li class="nav-item" onclick="setearLinkActive(this)">
                            <a class="nav-link active" id="listaFinanciamientoNav" href="#">Lista de Clientes</a>
                        </li>
                        <li class="nav-item" onclick="setearLinkActive(this)">
                            <a class="nav-link" id="nuevoFinanciamiento" href="#">Nuevo Financiamiento</a>
                        </li>
                        <li class="nav-item" onclick="setearLinkActive(this)">
                            <a class="nav-link" id="GContratosNav"href="#">Generar Contratos</a>
                        </li>
                    </ul>
                </nav>
            </div>
        </div>

    <div class="container">
        <div id="listaClientes">
            <div class="row">
                <div class="col-lg-8">
                    <div class="card-custom" >
                        <div class="card-header">
                            <h5>Lista de Clientes</h5>
                        </div>
                        
                        <div class="card-body">
                        <div class="mb-3">
                            <input type="text" class="form-control" id="searchCliente" placeholder="Buscar cliente por nombre o código" oninput="buscarClientes()">
                        </div>


                            <table class="table table-striped client-table">
                                <thead>
                                    <tr>
                                        <th>Nombre</th>
                                        <th>Código de Asociado</th>
                                        <th>Grupo de Financiamiento</th>
                                        <th>Cantidad de Financiamientos</th>
                                        <th>Acciones</th>
                                    </tr>
                                </thead>
                                <tbody id="clientTable">
                                    <!-- Los datos de los clientes se llenarán aquí -->
                                </tbody>
                            </table>

                            <!-- Paginación -->
                            <div class="pagination">
                                <button id="prevPage" class="btn btn-secondary btn-sm" disabled>Anterior</button>
                                <span id="pageNumber">Página 1</span>
                                <button id="nextPage" class="btn btn-secondary btn-sm">Siguiente</button>
                            </div>

                        </div>
                    </div>
                </div>

                <div class="col-lg-4">
                    <aside class="card-custom m-3 info-rapida">
                        <div class="card-header">
                            <h5>Información Rápida</5>
                        </div>

                        <div class="card-body ">
                            <ul>
                                <li><strong>Tipo de Documento</strong> Seleccione un cliente en la tabla</li>
                                <li><strong>Número de Documento</strong></li>
                                <li><strong>Nombre:</strong></li>
                                <li><strong>Cantidad de Financiamientos: </strong> </li>
                            </ul>
                        </div>
                    </aside>
                </div>

            </div>

            <!-- Modal para ver cronograma -->
            <div class="modal fade" id="paymentScheduleModal" tabindex="-1" aria-labelledby="paymentScheduleModalLabel" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header" style="background-color: rgb(37, 150, 190); color:white;">
                            <h5 class="modal-title" id="paymentScheduleModalLabel">Cronograma de Pagos</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">

                            <!-- Caja que actúa como el "select" -->
                            <div id="selectBox" onclick="toggleDropdown()" style="border: 1px solid #ccc; padding: 10px; cursor: pointer; text-align: center;">
                                Seleccionar un financiamiento ⬇ <!-- Texto por defecto -->
                            </div>

                            <!-- Tabla que simula el select (se oculta inicialmente) -->
                            <table id="cronogramaSelect" style="width: 100%; border: 1px solid #ccc; cursor: pointer; display: none;"> <!-- Se oculta al inicio -->
                                <thead>
                                    <tr style="background-color: #f0f0f0;">
                                        <th>Producto</th>
                                        <th>Grupo</th>
                                        <th>Cantidad</th>
                                        <th>Monto</th>
                                        <th>Categoría</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr onclick="seleccionarFila(this)">
                                        <td>Opción 1</td><td>Dato 1</td><td>Dato 2</td><td>Dato 3</td><td>Dato 4</td>
                                    </tr>
                                    <tr onclick="seleccionarFila(this)">
                                        <td>Opción 2</td><td>Dato 5</td><td>Dato 6</td><td>Dato 7</td><td>Dato 8</td>
                                    </tr>
                                    <tr onclick="seleccionarFila(this)">
                                        <td>Opción 3</td><td>Dato 9</td><td>Dato 10</td><td>Dato 11</td><td>Dato 12</td>
                                    </tr>
                                </tbody>
                            </table>

                            <table id="tablaCuotas" class="table table-striped" style="display: none;">
                                <thead>
                                    <tr>
                                        <th>Fecha de vencimiento</th>
                                        <th>Monto</th>
                                        <th>Estado</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <!-- Las filas se llenan dinámicamente con JavaScript -->
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            

            <div class="modal fade" id="financiangDetailModal" tabindex="-1" aria-labelledby="financingDetailsModalLabel" aria-hidden="true"> 
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="financingDetailsModalLabel">Detalles de Financiamiento</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>

                        <div class="modal-body detailsF">
                            <ul>
                                <li><strong>Grupo:</strong>Vehicular 1</li>
                                <li><strong>Cuota Inicial</strong>S/.1000</li>
                                <li><strong>Fecha de Inicio:></strong>01/01/2023</li>
                                <li><strong>Cuotas Restantes:</strong></li>
                                <li><strong>Estado:</stron> En progreso</li>
                            </ul>

                        </div>
                    </div>
                </div>
            </div>

            <!-- Modal para Ver Detalles -->
            <div class="modal fade" id="financingDetailsModal" tabindex="-1" aria-labelledby="financingDetailsModalLabel" aria-hidden="true">
                <div class="modal-dialog modal-lg">
                    <div class="modal-content" style="background-color: #f5fcff;">
                        <div class="modal-header" style="background-color: #8b8c64; color: white;">
                            <h5 class="modal-title" id="financingDetailsModalLabel">Detalles del Cliente y Financiamiento</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">

                            <!-- Caja que actúa como el "select" -->
                            <div id="selectBoxDetalle" onclick="toggleDropdownDetalle()" style="border: 1px solid #ccc; padding: 10px; cursor: pointer; text-align: center;">
                                Seleccionar un financiamiento ⬇ <!-- Texto por defecto -->
                            </div>

                            <!-- Tabla que simula el select (se oculta inicialmente) -->
                            <table id="detalleSelect" style="width: 100%; border: 1px solid #ccc; cursor: pointer; display: none;"> <!-- Se oculta al inicio -->
                                <thead>
                                    <tr style="background-color: #f0f0f0;">
                                        <th>Producto</th>
                                        <th>Grupo</th>
                                        <th>Cantidad</th>
                                        <th>Monto</th>
                                        <th>Categoría</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr onclick="seleccionarFilaDetalle(this)">
                                        <td>Opción 1</td><td>Dato 1</td><td>Dato 2</td><td>Dato 3</td><td>Dato 4</td>
                                    </tr>
                                    <tr onclick="seleccionarFilaDetalle(this)">
                                        <td>Opción 2</td><td>Dato 5</td><td>Dato 6</td><td>Dato 7</td><td>Dato 8</td>
                                    </tr>
                                    <tr onclick="seleccionarFilaDetalle(this)">
                                        <td>Opción 3</td><td>Dato 9</td><td>Dato 10</td><td>Dato 11</td><td>Dato 12</td>
                                    </tr>
                                </tbody>
                            </table>

                            <div id="detalleFinanciamientoContainer" style="display: none;">

                                <div class="row">
                                    <div class="col-6">
                                        <h5>Datos del Cliente</h5>
                                        <p><strong>Documento: </strong><span id="modalClienteDocumento"></span></p>
                                        <p><strong>Nombres: </strong><span id="modalClienteNombres"></span></p>
                                        <p><strong>Dirección: </strong><span id="modalClienteDireccion"></span></p>
                                        <p><strong>Teléfono: </strong><span id="modalClienteTelefono"></span></p>
                                    </div>
                                    <div class="col-6">
                                        <h5>Financiamiento</h5>
                                        <p><strong>Código Asociado: </strong><span id="modalFinanciamientoCodigo"></span></p>
                                        <p><strong>Grupo de Financiamiento: </strong><span id="modalFinanciamientoGrupo"></span></p>
                                        <p><strong>Estado: </strong><span id="modalFinanciamientoEstado"></span></p>
                                        <p><strong>Fecha Inicio: </strong><span id="modalFechaInicio"></span></p>
                                        <p><strong>Fecha Fin: </strong><span id="modalFechaFin"></span></p>
                                    </div>
                                </div>

                                <h5>Cuotas</h5>
                                <table class="table table-striped" id="modalCuotasTable">
                                    <!-- Las cuotas se agregarán dinámicamente aquí -->
                                </table>

                                <?php if ($id_rol == 3): ?>
                                    <!-- Botón agregado para eliminar financiamiento -->
                                    <button type="button" class="btn btn-danger btn-sm eliminar-finance" onclick="deleteFinance()"> 
                                        <i class="fa fa-times"></i> Eliminar este financiamiento <!-- Se agregó el texto identificador -->
                                    </button>
                                <?php endif; ?>   
                            </div>


                        </div>

                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Formulario de Nuevo Financiamiento -->
        <div id="nuevoFinanciamientoForm" class="d-none">
            <div class="row justify-content-center">
                <div class="col-lg-10">
                    <div class="card-header">
                        <div class="titulo-container text-center">
                            <h5 class="text-start">Nuevo Financiamiento</h5>
                        </div>
                    </div>
                    <div class="card-custom" id="CardModify">
                        <div class="card-body">
                            <form id="formNuevoFinanciamiento">
                                <div class="row mb-4">
                                    <div class="col-md-4 mb-3">
                                        <label for="cliente" class="form-label">Cliente</label>
                                        <input type="text" class="form-control" id="cliente" placeholder="Nombre del cliente" oninput="searchClientes()" autocomplete="off" required>
                                        <ul id="listaAutomatic" class="list-group mt-2" style="display: none;"></ul>
                                    </div>

                                    <div class="col-md-4 mb-3">
                                        <label for="numeroDocumento" class="form-label">Número de Documento</label>
                                        <input type="text" class="form-control" id="numeroDocumento" placeholder="Número de documento" oninput="searchNumDoc()" required>
                                        <ul id="listaNumDoc" class="list-group mt-2" style="display: none; position: absolute; z-index: 1000;"></ul>
                                    </div>

                                    <div class="col-md-4 mb-3">
                                        <label for="codigoAsociado" class="form-label">Código de Asociado</label>
                                        <input type="number" class="form-control" id="codigoAsociado" placeholder="Código de asociado" required>
                                    </div>
                                </div>

                                <div class="row mb-4">
                                    <div class="col-md-8 mb-3" id="tablaProductosContainer">
                                        <label for="producto" class="form-label">Producto</label>
                                        <input type="text" class="form-control mb-2" placeholder="Buscar producto o por IMEI" id="buscarProducto" style="border: 3px solid #bed6fb;" oninput="buscarProductos()">
                                        <div class="table-responsive">
                                            <table class="table table-bordered">
                                                <thead>
                                                    <tr>
                                                        <th style="width: 5%;">Elegir</th>
                                                        <th>Nombre</th>
                                                        <th>Código</th>
                                                        <th>Cantidad</th>
                                                        <th>Unidad Medida</th>
                                                        <th>Perfil</th>
                                                        <th>Aro</th>
                                                        <th>Precio</th>
                                                    </tr>
                                                </thead>
                                                <tbody id="tablaProductos">
                                                    <!-- Registros dinámicos cargados desde la base de datos -->
                                                </tbody>
                                            </table>
                                        </div>
                                        <div class="d-flex justify-content-between">
                                            <button id="btnAtras" type="button" onclick="cambiarPagina(-1)">Anterior</button>
                                            <button id="btnAdelante" type="button" onclick="cambiarPagina(1)">Siguiente</button>
                                        </div>
                                    </div>

                                    <div class="col-md-4 mb-3">
                                        <label for="cantidad" class="form-label">Cantidad</label>
                                        <input type="number" class="form-control mb-5" id="cantidad" placeholder="Cantidad de productos" required oninput="calcularMonto()">
                                        
                                        <div class="d-none" id="FotoDinamica">
                                            <img src="https://pics.clipartpng.com/Tires_PNG_ClipArt-1164.png" alt="Foto dinámica" class="img-fluid" style="width: 90%; height: auto; display: block; margin: 0 auto;">
                                        </div>

                                        <div class="d-none" id="planContainer">
                                            <label for="plan" class="form-label">Plan de Telefonía</label>
                                            
                                            <select id="plan" class="form-select">
                                                <option value ="notPlan">Seleccionar</option>
                                            </select>
                                        </div>

                                    </div>

                                    
                                </div>

                                </div>   

                                <div class="row mb-4">                                
                                    <div class="col-md-4 mb-3 d-none" id="camposDinamicos">
                                        <label for="perfil" class="form-label">Perfil</label>
                                        <input type="text" class="form-control mb-3" id="perfil" placeholder="Perfil">
                                        <label for="nroAro" class="form-label">Nro de Aro</label>
                                        <input type="text" class="form-control" id="nroAro" placeholder="Número de Aro">
                                    </div>

                                    
                                </div>

                                <!-- NUEVO: Sección para tipo de moneda y tipo de cambio -->
                                <div class="row mb-4"> 
                                    <div class="col-md-4 mb-3">
                                        <label class="form-label">Tipo de Moneda</label>
                                        <div>
                                            <div class="form-check">
                                                <input class="form-check-input" type="radio" name="tipoMoneda" id="monedaSoles" value="Soles" required>
                                                <label class="form-check-label" for="monedaSoles">Soles</label>
                                            </div>
                                            <div class="form-check">
                                                <input class="form-check-input" type="radio" name="tipoMoneda" id="monedaDolares" value="Dolares" required>
                                                <label class="form-check-label" for="monedaDolares">Dólares</label>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-4 mb-3">
                                        <label for="tipoCambio" class="form-label">Tipo de Cambio</label>
                                        <p id="tipoCambio" class="form-control-plaintext"><--DATA NOT RECEIVED--></p> <!-- Valor de ejemplo -->
                                    </div>
                                </div>
                                <!-- Fin de la nueva sección -->

                                <div class="row mb-4">

                                <div class="col-md-4 mb-3 d-flex align-items-end">
                                    <div style="flex: 1;">
                                        <label for="grupo" class="form-label">Grupo de Financiamiento</label>
                                        <select class="form-select" id="grupo" style="width: 100%;" required> <!-- Reducido el ancho -->
                                            <option value="" disabled selected>Seleccione un grupo</option>
                                            <option value="Vehicular">Vehicular</option>
                                            <option value="Hipotecario">Hipotecario</option>
                                        </select>
                                    </div>
                                    <button type="button" class="btn btn-primary ms-2" id="btnAgregarGrupo" data-bs-toggle="modal" data-bs-target="#exampleModalGrupoFinanciamiento">+</button>
                                </div>
                                    
                                    <div class="col-md-4 mb-3">
                                        <label for="monto" class="form-label">Monto</label>
                                        <input type="text" class="form-control" id="monto" placeholder="Monto del financiamiento">
                                    </div>

                                    <div class="col-md-4 mb-3">
                                            <label for="cuotaInicial" class="form-label">Cuota Inicial</label>
                                            <input type="text" class="form-control" id="cuotaInicial" placeholder="Cuota inicial" required>
                                    </div>

                                </div>

                                <div class="row mb-4">
                                    <div class="col-md-4 mb-3">
                                        <label for="montoInscripcion" class="form-label">Monto de Inscripción</label> <!-- Nuevo campo -->
                                        <input type="text" class="form-control" id="montoInscripcion" placeholder="Monto de inscripción"> <!-- Nuevo campo -->
                                    </div>

                                    <div class="col-md-4 mb-3">
                                        <label for="tasaInteres" class="form-label">Tasa de Interés</label> <!-- Nuevo campo -->
                                        <input type="text" class="form-control" id="tasaInteres" placeholder="Tasa de interés"> <!-- Nuevo campo -->
                                    </div>

                                    <div class="col-md-4 mb-3"> <!-- Nueva columna -->
                                        <label for="frecuenciaPago" class="form-label">Frecuencia de Pago</label> <!-- Nuevo campo -->
                                        <select class="form-select" id="frecuenciaPago"> <!-- Nuevo campo -->
                                            <option value="mensual">Mensual</option> <!-- Opción nueva -->
                                            <option value="semanal">Semanal</option> <!-- Opción nueva -->
                                        </select>
                                    </div>
                                </div>

                                <div class="row mb-4">                                                                  

                                    <div class="col-md-4 mb-3">
                                        <label for="fechaInicio" class="form-label">Fecha de Inicio</label>
                                        <input type="date" class="form-control" id="fechaInicio" required>
                                    </div>

                                    <div class="col-md-4 mb-3">
                                        <label for="fechaFin" class="form-label">Fecha de Fin</label>
                                        <input type="date" class="form-control" id="fechaFin" placeholder="Fecha de fin" required readonly>
                                    </div>

                                    <div class="col-md-4 mb-3">
                                        <label for="cuotas" class="form-label">Cantidad de Cuotas</label>
                                        <input type="number" class="form-control" id="cuotas" placeholder="Número de cuotas" required>
                                    </div>

                                </div>

                                <div class="row mb-4">
                                    <div class="col-md-4 mb-3">
                                        <label for="valorCuota" class="form-label">Valor de la Cuota</label>
                                        <input type="text" class="form-control" id="valorCuota" placeholder="Valor de la cuota" readonly>
                                    </div>

                                    

                                    <div class="col-md-4 mb-3">
                                        <label for="estado" class="form-label" >Estado</label>
                                        <select class="form-select" id="estado" required disabled>
                                            <option value="En progreso">En progreso</option>
                                            <option value="Finalizado">Finalizado</option>
                                        </select>
                                    </div>

                                    <div class="col-md-4 mb-3">
                                        <label for="fechaHoraActual" class="form-label">Fecha y Hora Actual</label>
                                        <input type="datetime-local" class="form-control" id="fechaHoraActual" value="" required>
                                    </div>
                                    
                                </div>

                                    

                                    

                                <div id="contenedorFechas">
                                    <!-- Las fechas de vencimiento se mostrarán aquí -->
                                </div>

                                <div class="d-flex justify-content-center mt-4">
                                    <button class="btn btn-amarillo-negro btn-custom" onclick="saveFinanciamiento(event)">Registrar</button>
                                    <button type="button" id="cancelarFinanciamiento" class="btn btn-negro-blanco btn-custom ms-2">Cancelar</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="modal fade" id="exampleModalGrupoFinanciamiento" tabindex="-1" aria-labelledby="exampleModalLabelGrupoFinanciamiento" aria-hidden="true"> 
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header" style="background-color: #d5d696;">
                        <h5 class="modal-title" id="exampleModalLabelGrupoFinanciamiento">Nuevo Grupo de Financiamiento</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>

                    <div class="modal-body" style="background-color: #f7f3e4;">
                        <label class="mb-2">Agregar nuevo Grupo de Financiamiento:</label>
                        <input id="grupoFinanciamiento" type="text" class="form-control mb-4" placeholder="Ingrese nombre del grupo de financiamiento">
                    </div>

                    <div class="modal-footer" style="background-color: #d5d696;">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                        <button onclick="saveGroupFinance()" type="button" class="btn btn-primary">Guardar</button>
                    </div>
                </div>
            </div>
        </div>

        <div class="generar-contratos-container d-none" id="generarContratosFrm">
            <h1>Generar Contratos</h1>

            <!-- Filtro -->
            <div class="filtro">
                <label for="buscar-financiamientos">Buscar financiamientos:</label>
                <input type="text" id="buscar-financiamientos" placeholder="Ingrese criterios de búsqueda">
                <button id="btn-buscar" onclick="buscarFinanciamientos()">Buscar</button>
            </div>

            <!-- Tabla de financiamientos -->
            <div class="tabla-financiamientos">
                <h2>Financiamientos</h2>
                    <table>
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Cliente</th>
                                <th>Fecha</th>
                                <th>Monto</th>
                                <th>Estado</th>
                                <th>Acciones</th>
                            </tr>
                        </thead>
                        <tbody>
                        <!-- Las filas se cargarán dinámicamente -->
                        </tbody>
                    </table>
            </div>

            <!-- Rango de fechas -->
            <div class="rango-fechas">
                <h2>Rango de fechas</h2>
                <label for="fecha-inicio">Fecha de inicio:</label>
                <input type="date" id="fecha-inicio">
                <label for="fecha-fin">Fecha de fin:</label>
                <input type="date" id="fecha-fin">

                <button type="button" onclick="limpiarFechas()" style="display: inline-block; margin-left: 10px;">Limpiar Fechas</button>
            </div>

            <!-- Botón de acción -->
            <div class="boton-generar">
                <button id="btn-generar" onclick="GenerarContratos()">Generar Contratos</button>
            </div>
        </div>

        <!-- Modal -->
        <div class="modal fade" id="modalFinanciamiento" tabindex="-1" aria-labelledby="modalFinanciamientoLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content" id="financiamientoModal">
            <!-- Header -->
            <div class="modal-header" id="financiamientoModalHeader">
                <h5 class="modal-title" id="modalFinanciamientoLabel">Detalles del Financiamiento</h5>
                <button type="button" class="btn-close" id="financiamientoModalClose" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            
            <!-- Body -->
            <div class="modal-body" id="financiamientoModalBody">
                <!-- Información General -->
                <div class="modal-section" id="financiamientoModalSection">
                <h6>Información General</h6>
                <div class="row">
                    <div class="col-md-6">
                    <p><strong>ID del Financiamiento:</strong> [ID]</p>
                    <p><strong>Fecha de Creación:</strong> [Fecha]</p>
                    </div>
                    <div class="col-md-6">
                    <p><strong>Estado:</strong> [Estado]</p>
                    </div>
                </div>
                </div>

                <!-- Información del Conductor -->
                <div class="modal-section" id="financiamientoModalSection">
                <h6>Información del Conductor</h6>
                <div class="row">
                    <div class="col-md-6">
                    <p><strong>Nombre:</strong> [Nombre]</p>
                    <p><strong>Dirección:</strong> [Dirección]</p>
                    </div>
                    <div class="col-md-6">
                    <p><strong>Número de Celular:</strong> [Número]</p>
                    <p><strong>Correo:</strong> [Correo]</p>
                    </div>
                </div>
                </div>

                <!-- Información del Producto -->
                <div class="modal-section" id="financiamientoModalSection">
                <h6>Información del Producto</h6>
                <div class="row">
                    <div class="col-md-6">
                    <p><strong>Código de Producto:</strong> [Código]</p>
                    </div>
                    <div class="col-md-6">
                    <p><strong>Nombre del Producto:</strong> [Descripción]</p>
                    </div>
                    <div class="col-md-6">
                    <p><strong>Cantidad:</strong> [Cantidad]</p>
                    </div>
                </div>
                </div>

                <!-- Información del Financiamiento -->
                <div class="modal-section" id="financiamientoModalSection">
                <h6>Información del Financiamiento</h6>
                <div class="row">
                    <div class="col-md-6">
                    <p><strong>Monto:</strong> [Monto]</p>
                    <p><strong>Cuota Inicial:</strong> [Cuota Inicial]</p>
                    </div>
                    <div class="col-md-6">
                    <p><strong>Cuotas:</strong> [Cuotas]</p>
                    <p><strong>Fecha de Inicio:</strong> [Fecha de Inicio]</p>
                    <p><strong>Fecha de Fin:</strong> [Fecha de Fin]</p>
                    </div>
                </div>
                </div>
            </div>
            
            <!-- Footer -->
            <div class="modal-footer" id="financiamientoModalFooter">
                <button type="button" class="btn btn-close" id="financiamientoModalCloseBtn" data-bs-dismiss="modal">Cerrar</button>
            </div>
            </div>
        </div>
        </div>





    </div>    

<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>

<script src="http://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.min.js"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<script>

    

    var paginaActual = 1;
    var totalPaginas = 1;

    // Función para cargar los clientes desde el servidor
    function cargarClientes() {
        $.ajax({
            url: '/arequipago/obtenerClientesFinanciamiento?pagina=' + paginaActual, // Pasamos la página actual
            type: 'GET',
            dataType: 'json',
            success: function(data) {
                var tbody = $('#clientTable');
                tbody.empty(); // Vaciar la tabla antes de agregar nuevos datos

                // Cargar los conductores
                $.each(data.conductores, function(i, conductor) {
                    // Concatenar los nombres y apellidos en un solo campo
                    var nombreCompleto = conductor.nombres + ' ' + conductor.apellido_paterno + ' ' + conductor.apellido_materno;
                
                        tbody.append(`
                            <tr class="client-row" data-id-conductor="${conductor.id_conductor}"> <!-- Eliminado data-id-financiamiento -->
                                <td>${nombreCompleto}</td> <!-- Mostrar el nombre completo -->
                                <td>${conductor.codigo_asociado || 'N/A'}</td> <!-- Mostrar el código asociado, N/A si no existe -->
                                <td>${conductor.grupo_financiamiento || 'N/A'}</td> <!-- Mostrar el grupo de financiamiento, N/A si no existe -->
                                <td>${conductor.cantidad_financiamientos || 0}</td> <!-- Nueva columna: Mostrar la cantidad de financiamientos -->
                                <td>
                                    <button class="btn btn-primary btn-sm mb-2" data-bs-toggle="modal" data-bs-target="#paymentScheduleModal">Ver Cronograma</button>
                                    <button class="btn btn-info btn-sm" data-bs-toggle="modal" data-bs-target="#financingDetailsModal">Ver Detalles</button>
                                </td>
                            </tr>
                        `);
                });


                // Actualizar la información de la paginación
                totalPaginas = data.totalPaginas;
                $('#pageNumber').text('Página ' + paginaActual);

                // Deshabilitar o habilitar los botones de paginación según la página actual
                $('#prevPage').prop('disabled', paginaActual <= 1);
                $('#nextPage').prop('disabled', paginaActual >= totalPaginas);

                vincularEventosFilas();
                vincularEventosCronograma();
                vincularEventosDetalles()
            },
            error: function() {
                alert("Error al cargar los clientes");
            }
        });
    }

    // Función para ir a la página anterior
    $('#prevPage').click(function() {
        if (paginaActual > 1) {
            paginaActual--;
            cargarClientes();
        }
    });

    // Función para ir a la página siguiente
    $('#nextPage').click(function() {
        if (paginaActual < totalPaginas) {
            paginaActual++;
            cargarClientes();
        }
    });

    function buscarClientes() {
        // Obtener el término de búsqueda ingresado en el campo de búsqueda
        let searchTerm = document.getElementById('searchCliente').value;

        // Obtener la página actual (puedes agregar la lógica para paginación si es necesario)
        let paginaActual = 1; // Para este ejemplo, siempre es la página 1

        // Hacer la solicitud AJAX para obtener los conductores filtrados
        $.ajax({
            url: '/arequipago/obtenerClientesBuscados?searchTerm=' + encodeURIComponent(searchTerm) + '&pagina=' + paginaActual,
            type: 'GET',
            dataType: 'json',
            success: function(data) {
                if (data.error) {
                    alert('Error: ' + data.error);
                } else {
                    // Llamar a la función para mostrar los datos en la tabla
                    mostrarClientes(data.clientes);
                }
            },
            error: function() {
                alert('Error al realizar la búsqueda');
            }
        });
    }

        function mostrarClientes(clientes) {
            let clientTable = document.getElementById('clientTable');
            clientTable.innerHTML = ''; // Limpiar el contenido de la tabla

            clientes.forEach(cliente => {
                // Construir la fila de la tabla con los datos recibidos
                let row = document.createElement('tr');
                row.classList.add('client-row'); // Agregar la clase client-row
                row.setAttribute('data-id-conductor', cliente.id_conductor); // Ajustar el atributo data-id-conductor
                
                let nombreCompleto = cliente.datos || (cliente.nombres + ' ' + cliente.apellido_paterno + ' ' + cliente.apellido_materno);

                row.innerHTML = `
                    <td>${nombreCompleto}</td> <!-- Nombre completo -->
                    <td>${cliente.codigo_asociado || 'N/A'}</td> <!-- Código asociado -->
                    <td>${cliente.grupo_financiamiento || 'N/A'}</td> <!-- Grupo de financiamiento -->
                    <td>${cliente.cantidad_financiamientos || 0}</td> <!-- Cantidad de financiamientos -->
                    <td>
                        <button class="btn btn-primary btn-sm mb-2" data-bs-toggle="modal" data-bs-target="#paymentScheduleModal">Ver Cronograma</button>
                        <button class="btn btn-info btn-sm" data-bs-toggle="modal" data-bs-target="#financingDetailsModal">Ver Detalles</button>
                    </td>
                `;
                // Insertar los datos en las celdas de la fila
                
                clientTable.appendChild(row); // Agregar la fila a la tabla
            });

            // Volver a vincular los eventos de clic después de mostrar los conductores
            vincularEventosFilas();
            vincularEventosCronograma();
            vincularEventosDetalles();
        }

    function vincularEventosFilas() {
        $('.client-row').off('click').on('click', function() {
        var id_conductor = $(this).data('id-conductor'); // Cambié 'id-cliente' a 'id-conductor'
        var cantidadFinanciamientos = $(this).find('td:eq(3)').text().trim(); // Obtener la cantidad de financiamientos (columna 4)
        
        var cardBody = $('.info-rapida .card-body ul'); // Cambio: Asegurar que seleccionamos la UL dentro de la card correcta

        if (cardBody.length === 0) { // Cambio: Validar si la UL existe antes de manipularla
            console.error("No se encontró la lista dentro de la tarjeta");
            return;
        }

        cardBody.html('');;

            $.ajax({
                url: '/arequipago/obtenerFinanciamientoPorCliente?id_conductor=' + id_conductor, 
                type: 'GET',
                dataType: 'json',
                success: function(data) {
                if (data.error) {
                    alert(data.error);
                } else {
                    console.log('Datos recibidos:', data);

                    var datos = data; 
                    if (data.datos) { // Cambio: Si los datos vienen dentro de un objeto llamado "datos"
                        datos = data.datos;
                    } else if (Array.isArray(data) && data.length > 0) { // Cambio: Si la respuesta es un array, tomar el primer elemento
                        datos = data[0];
                    }

                    // Crear la estructura HTML con los datos recibidos
                    var contenido = `
                        <li><strong>Tipo de Documento:</strong> ${datos.tipo_doc || 'N/A'}</li> <!-- Cambio: Usar "datos" en lugar de "data" -->
                        <li><strong>Número de Documento:</strong> ${datos.nro_documento || 'N/A'}</li> <!-- Cambio: Usar "datos" en lugar de "data" -->
                        <li><strong>Nombre:</strong> ${datos.nombre_completo || 'N/A'}</li> <!-- Cambio: Usar "datos" en lugar de "data" -->
                        <li><strong>Cantidad de Financiamientos:</strong> ${cantidadFinanciamientos || 'N/A'}</li>
                    `;

                    cardBody.html(contenido); // Insertar datos en la tarjeta
                }
                },
                error: function() {
                    alert("Error al obtener los datos del conductor");
                }
            });
        });
    }

    function vincularEventosCronograma() {
        $('.client-row').each(function() {
            // Cuando se hace clic en el botón "Ver Cronograma" (btn-primary)
                $(this).find('.btn-primary').off('click').on('click', function() {
                    var idConductor = $(this).closest('tr').data('id-conductor');

                // Llamar a la función para cargar el cronograma en el modal
                cargarCronograma(idConductor); 
            });
        });
    }

    function vincularEventosDetalles() {
        $('.client-row').each(function() {
            $(this).find('.btn-info').off('click').on('click', function() {
                const idConductor = $(this).closest('tr').data('id-conductor'); // ✅ Obtener el ID del conductor correctamente de la tabla de financiamientos
                
                $('#modalCuotasTable').empty(); // ✅ Vaciar solo la tabla sin ocultarla

                mostrarDetallesCliente(idConductor); // ✅ Cargar los detalles en el modal
            });
        });
    }

    function cargarCronograma(idConductor) {

            document.getElementById("selectBox").innerText = "Seleccionar un financiamiento ⬇";
            var tablaFinanciamientos = document.querySelector("#cronogramaSelect tbody"); 
            tablaFinanciamientos.innerHTML = "";
            var tablaCuotas = document.querySelector("#tablaCuotas tbody");
            tablaCuotas.innerHTML = "";
            document.getElementById("tablaCuotas").style.display = "none"; // ✅ Ocultar la tabla de cuotas
            

            $.ajax({
                url: '/arequipago/obtenerCuotasPorCliente?id_conductor=' + idConductor,  // Modificado: ahora la solicitud AJAX envía id_conductor en vez de id_financiamiento
                dataType: 'json',
                success: function(data) {
                    //console.log("Datos recibidos del servidor:", data); 

                    if (data.financiamientos === null) {  // ✅ Verificar si "financiamientos" es null
                        return; // ✅ Detener la ejecución si no hay financiamientos
                    }
 
                    var tablaFinanciamientos = document.querySelector("#cronogramaSelect tbody");
                    tablaFinanciamientos.innerHTML = ""; // Limpiar la tabla antes de llenarla

                    data.financiamientos.forEach(financiamiento => {
                        var fila = document.createElement("tr");
                        fila.onclick = function() { seleccionarFila(this, financiamiento); }; // Pasar el objeto financiamiento

                        fila.innerHTML = `
                            <td>${financiamiento.producto.nombre}</td>
                            <td>${financiamiento.grupo_financiamiento}</td>
                            <td>${financiamiento.cantidad_producto}</td>
                            <td>${financiamiento.monto_total}</td>
                            <td>${financiamiento.producto.categoria}</td>
                        `;
                        tablaFinanciamientos.appendChild(fila);
                    });

                },
                error: function() {
                    alert("Error al cargar el cronograma de pagos");
                }
            });
        }

    function mostrarDetallesCliente(idConductor) {
        // Mostrar el contenedor de detalles
        let detalleContainer = document.getElementById("detalleFinanciamientoContainer");
        detalleContainer.style.display = "none"; 

        // Restablecer el texto del "select box" a su valor por defecto (Nueva línea agregada)
        document.getElementById("selectBoxDetalle").innerText = "Seleccionar un financiamiento ⬇";  
        let tbody = $("#detalleSelect tbody"); // Asegurar que este ID existe en el HTML
        tbody.empty(); // Limpiar filas anteriores
        let table = document.getElementById("detalleSelect"); // Obtener la tabla (Nueva línea agregada)

        // Verificar si la tabla está desplegada y ocultarla si es necesario (Nueva condición agregada)
        if (table.style.display === "table") {  
            table.style.display = "none";  
        }

        $.ajax({
            url: '/arequipago/obtenerClienteDetalle?id_conductor=' + idConductor, // Corregido para enviar solo idConductor  
            type: 'GET',
            dataType: 'json',
            success: function(data) {

                console.log(data);
                // Verificamos si hay financiamientos
                if (data.financiamientos && data.financiamientos.length > 0) {
                    let tbody = $("#detalleSelect tbody");
                    tbody.empty();

                    data.financiamientos.forEach(function(financiamiento) {
                        let producto = financiamiento.producto || {};
                        let conductor = data.conductor || {}; // Tomarlo desde data
                        let direccion = data.direccion || {};

                        let financiamientoData = {
                            producto,
                            financiamiento,
                            conductor, // Agregar el conductor
                            direccion// Agregar la dirección del conductor
                        };

                        let row = `<tr onclick="seleccionarFinanciamiento(this)" 
                                    data-financiamiento='${JSON.stringify(financiamientoData)}'>
                            <td>${producto.nombre || 'Sin nombre'}</td>
                            <td>${financiamiento.grupo_financiamiento || 'N/A'}</td>
                            <td>${financiamiento.cantidad_producto || '0'}</td>
                            <td>${financiamiento.monto_total || '0.00'}</td>
                            <td>${producto.categoria || 'Sin categoría'}</td>
                        </tr>`;
                        tbody.append(row); // Agregar la fila a la tabla correcta
                    });

                } else {
                    alert("No se encontraron financiamientos.");
                }
            },
            error: function() {
                alert("Error al cargar los detalles del cliente");
            }
        });
    }


    function setearLinkActive(liElement) {
        // Selecciona todos los li de la navbar
        
        const listItems = document.querySelectorAll('.navbar-custom .nav-item');

        // Recorremos todos los li y eliminamos la clase 'active' de los <a> dentro de los <li>
        listItems.forEach(item => {
            const link = item.querySelector('a');
            if (link && link.classList.contains('active')) {
                console.log("Eliminando clase 'active' de:", link);
                link.classList.remove('active');
            }
        });

        // Añadimos la clase 'active' al <a> del <li> que fue clickeado
        const linkClicked = liElement.querySelector('a');
        console.log("Añadiendo clase 'active' al <a> clickeado:", linkClicked);
        linkClicked.classList.add('active');
    }

    function searchClientes() {
        // Obtener el término de búsqueda ingresado en el campo de búsqueda
        let searchTerm = document.getElementById('cliente').value;

        // Evitar la ejecución si el término está vacío
        if (searchTerm.length < 2) {
            document.getElementById('listaAutomatic').style.display = 'none';
            return;
        }

        // Hacer la solicitud AJAX para obtener los clientes filtrados
        $.ajax({
            url: '/arequipago/obtenerClientesAutocompletado?searchTerm=' + encodeURIComponent(searchTerm),
            type: 'GET',
            dataType: 'json',
            success: function(data) {
                // Mostrar los resultados de autocompletado
                let listaAutomatic = document.getElementById('listaAutomatic');
                listaAutomatic.innerHTML = ''; // Limpiar la lista antes de mostrar nuevos resultados

                
                if (data.length > 0) {
                    data.forEach(conductor => {
                        let listItem = document.createElement('li');
                        listItem.classList.add('list-group-item');
                        listItem.textContent = conductor.datos; // Mostrar el nombre completo del conductor
                        listItem.setAttribute('data-id', conductor.id_conductor); // Agregar el id del conductor
                        listItem.setAttribute('data-nro-documento', conductor.nro_documento); // Agregar el número de documento
                        listItem.setAttribute('data-codfi', conductor.codigo_asociado); // Agregar `numeroCodFi` // <--- NUEVO CAMBIO

                        // Evento al hacer clic en un conductor
                        listItem.addEventListener('click', function() {
                            seleccionarConductor(conductor);
                            console.log(conductor);
                        });

                        listaAutomatic.appendChild(listItem);
                    });

                    listaAutomatic.style.display = 'block'; // Mostrar la lista de resultados
                } else {
                    listaAutomatic.style.display = 'none'; // Ocultar la lista si no hay resultados
                }
            },
            error: function() {
                console.error('Error al buscar los clientes');
            }
        });
    }

    function seleccionarConductor(conductor) {
        // Al seleccionar un cliente, poner el nombre del cliente en el input
        document.getElementById('cliente').value = conductor.datos;

        // Poner el número de documento en el input correspondiente
        document.getElementById('numeroDocumento').value = conductor.nro_documento;
        document.getElementById('codigoAsociado').value = conductor.codigo_asociado; // Setea `numeroCodFi` en el input correspondiente // <--- NUEVO CAMBIO

        // Opcional: puedes almacenar el id del cliente en otro campo oculto si es necesario
        document.getElementById('cliente').dataset.id = conductor.id_conductor;

        // Ocultar la lista de resultados
        document.getElementById('listaAutomatic').style.display = 'none';
    }

    function searchNumDoc() {
        let searchTerm = document.getElementById('numeroDocumento').value;

        if (searchTerm.length < 2) {
            document.getElementById('listaNumDoc').style.display = 'none';
            return;
        }

        $.ajax({
            url: '/arequipago/obtenerNumDocAutocompletado?searchTerm=' + encodeURIComponent(searchTerm),
            type: 'GET',
            dataType: 'json',
            success: function(data) {
                let listaNumDoc = document.getElementById('listaNumDoc');
                listaNumDoc.innerHTML = '';

                if (data.length > 0) {
                    data.forEach(conductor => {
                        let listItem = document.createElement('li');
                        listItem.classList.add('list-group-item');
                        listItem.textContent = conductor.nro_documento;
                        listItem.setAttribute('data-id', conductor.id_conductor);
                        listItem.setAttribute('data-nombre', conductor.nombres);
                        listItem.setAttribute('data-apellido-paterno', conductor.apellido_paterno); // Nuevo atributo
                        listItem.setAttribute('data-apellido-materno', conductor.apellido_materno); // Nuevo atributo
                        listItem.setAttribute('data-codigo-asociado', conductor.numeroCodFi); // Agregado el atributo data-codigo-asociado+

                        listItem.addEventListener('click', function() {
                            seleccionarNumDoc(conductor);
                        });

                        listaNumDoc.appendChild(listItem);
                    });

                    listaNumDoc.style.display = 'block';
                } else {
                    listaNumDoc.style.display = 'none';
                }
            },
            error: function() {
                console.error('Error al buscar los números de documento');
            }
        });
    }

    function seleccionarNumDoc(conductor) {
        document.getElementById('numeroDocumento').value = conductor.nro_documento;
        document.getElementById('cliente').value = `${conductor.nombres} ${conductor.apellido_paterno} ${conductor.apellido_materno}`;
        document.getElementById('codigoAsociado').value = conductor.numeroCodFi;  // Asignado el valor de numeroCodFi al input codigoAsociado
        document.getElementById('listaNumDoc').style.display = 'none';
    }

 
    

// Función para calcular el financiamiento
function calcularFinanciamiento() {
    // Obtener el monto total, cuota inicial, fecha de inicio y fecha de fin

    if (perteneceGrupoFinanciamiento) {
        console.warn("El producto no pertenece a un plan de financiamiento.");
        return;
    }

    const montoRaw = document.getElementById('monto').value;
    const cuotaInicialRaw = document.getElementById('cuotaInicial').value;
    const tasaInteresRaw = document.getElementById('tasaInteres').value; // Nuevo campo para tasa de interés
    const frecuenciaPago = document.getElementById('frecuenciaPago').value; // Obtener la frecuencia de pago seleccionada // NUEVO CAMPO
    const tipoMoneda = obtenerTipoMoneda(); // NUEVO: Obtener el tipo de moneda seleccionado
    
    
    
    const montoTotal = parseFloat(montoRaw.replace(/S\/\.|US\$/, '').replace(',', '').trim()); // Modificado para soportar "US$"
    const cuotaInicial = parseFloat(cuotaInicialRaw.replace(/S\/\.|US\$/, '').replace(',', '').trim()); // Modificado para soportar "US$"
    const tasaInteres = parseFloat(tasaInteresRaw) / 100;
    const fechaInicio = document.getElementById('fechaInicio').value;
    
    // CORRECCIÓN: Se usa isNaN en lugar de !cuotaInicial para permitir cuotaInicial = 0
    if (isNaN(montoTotal) || isNaN(cuotaInicial) || isNaN(tasaInteres) || !fechaInicio || !frecuenciaPago) {  
        return; // No hacer nada hasta que todos los campos estén completos
    }

    // Validar que la cuota inicial no sea mayor que el monto total
    if (cuotaInicial > montoTotal) {
        // No se muestra un alert, solo se retorna para evitar el cálculo
        return;
    }
       
    

    // Obtener la cantidad de cuotas del input (ahora el usuario puede elegir)
    const cantidadCuotas = parseInt(document.getElementById('cuotas').value); // Modificación: obtener la cantidad de cuotas elegida por el usuario

    // Verificar que la cantidad de cuotas sea válida
    if (!cantidadCuotas || cantidadCuotas <= 0) {
        return; // No hacer nada si la cantidad de cuotas no es válida
    }

    // Calcular la tasa de interés por período según la frecuencia seleccionada
    const tasaPeriodo = frecuenciaPago === 'semanal' 
        ? tasaInteres / 52 // Dividir por 52 para semanal // NUEVO
        : tasaInteres / 12; // Dividir por 12 para mensual // NUEVO

    // Calcular el valor de la cuota según la nueva fórmula:
    const valorCuota = ((montoTotal * (1 + tasaInteres)) - cuotaInicial) / cantidadCuotas; // CORREGIDO

    const cuotaFormateada = formatMoneda(valorCuota, tipoMoneda);

    // Mostrar los resultados en los campos
    document.getElementById('valorCuota').value = cuotaFormateada;  // Valor de la cuota formateado

    // Calcular las fechas de vencimiento de cada cuota
    let fechasVencimiento = [];
    const fechaInicioObj = new Date(fechaInicio);
    const diasIntervalo = frecuenciaPago === 'semanal' ? 7 : 30; // Intervalo en días según la frecuencia seleccionada // NUEVO

    // Corregir la fecha de inicio: sumamos 1 día a la fecha de inicio para evitar el problema de que el sistema la tome como un día antes // NUEVO
    fechaInicioObj.setDate(fechaInicioObj.getDate() + 1); // Sumar 1 día a la fecha de inicio
    
    for (let i = 1; i <= cantidadCuotas; i++) {
        let fechaVencimiento = new Date(fechaInicioObj);
        fechaVencimiento.setDate(fechaVencimiento.getDate() + (i * diasIntervalo)); // Sumar días según el intervalo // NUEVO
        fechasVencimiento.push(fechaVencimiento);
    }

    // Mostrar las fechas de vencimiento en la vista
    mostrarFechasVencimiento(fechasVencimiento, valorCuota, tipoMoneda);

    // ACTUALIZAR LA FECHA DE FIN AUTOMÁTICAMENTE EN EL INPUT DE TIPO DATE
    const fechaFin = fechasVencimiento[fechasVencimiento.length - 1]; // Última fecha de vencimiento
    
    // Modificar el formato de  la fecha para el input de tipo date (yyyy-mm-dd)
    const fechaFormateada = formatFechaInput(fechaFin); // Usamos una nueva función para este formato

    document.getElementById('fechaFin').value = fechaFormateada;
    }

    if (typeof cronogramaDatos === 'undefined') {
        var cronogramaDatos = [];  // O usar let o const si está en un ámbito adecuado
    }


    // Función para mostrar las fechas de vencimiento de las cuotas
    function mostrarFechasVencimiento(fechasVencimiento, valorcuota) {
        const contenedorFechas = document.getElementById('contenedorFechas'); // Asegúrate de tener un contenedor para las fechas
        contenedorFechas.innerHTML = ''; // Limpiar el contenedor antes de agregar las nuevas fechas

        cronogramaDatos = [];
        // Recorrer las fechas de vencimiento y mostrarlas
        fechasVencimiento.forEach((fecha, index) => {
            const fechaFormateada = formatFecha(fecha); // Asegúrate de tener una función para formatear la fecha
            contenedorFechas.innerHTML += `
                <div>
                    <label>Cuota ${index + 1}:</label>
                    <span>Valor: ${formatMoneda(valorcuota)} | Vencimiento: ${fechaFormateada}</span>
                </div>
            `;
             // Almacenar los datos de cada cuota en el array cronogramaDatos
            cronogramaDatos.push({
                cuota: index + 1,
                valor: valorcuota,
                vencimiento: fechaFormateada
            });

        });
        // Agregar botón para descargar cronograma (nuevo)
        const botonDescargar = document.createElement('button'); // Crear el botón
        botonDescargar.type = 'button'; // Evitar que el botón actúe como un submit
        botonDescargar.innerHTML = 'Cronograma <i class="fas fa-file-pdf"></i>'; // Icono y texto (Font Awesome)
        botonDescargar.style.backgroundColor = '#d32f2f'; // Fondo rojo (Adobe Acrobat)
        botonDescargar.style.color = '#FFFFFF'; // Texto blanco
        botonDescargar.style.border = 'none'; // Sin borde
        botonDescargar.style.padding = '10px 15px'; // Espaciado interno
        botonDescargar.style.borderRadius = '5px'; // Bordes redondeados
        botonDescargar.style.cursor = 'pointer'; // Cambiar cursor al pasar sobre el botón
        botonDescargar.style.marginTop = '10px'; // Espacio superior
        botonDescargar.style.display = 'inline-flex'; // Alinear icono y texto
        botonDescargar.style.alignItems = 'center'; // Centrar verticalmente el contenido
        botonDescargar.style.gap = '8px'; // Espacio entre el icono y el texto


        botonDescargar.addEventListener('click', () => {
            generateCronograma(); // Mensaje temporal, reemplázalo con tu lógica de descarga
        });
        contenedorFechas.appendChild(botonDescargar); // Agregar el botón al contenedor de fechas
    }

    function formatFechaInput(fecha) {
        const anio = fecha.getFullYear();
        const mes = (fecha.getMonth() + 1).toString().padStart(2, '0'); // Mes debe tener 2 dígitos
        const dia = fecha.getDate().toString().padStart(2, '0'); // Día debe tener 2 dígitos
        return `${anio}-${mes}-${dia}`; // Formato adecuado para el input de tipo date
    }

    function obtenerTipoMoneda() {
        const monedaSoles = document.getElementById('monedaSoles').checked; // Verificar si está seleccionado "Soles"
        const monedaDolares = document.getElementById('monedaDolares').checked; // Verificar si está seleccionado "Dólares"

        if (monedaSoles) return 'Soles'; // Retornar "Soles" si está seleccionado
        if (monedaDolares) return 'Dólares'; // Retornar "Dólares" si está seleccionado
        return ''; // Retornar cadena vacía si no hay selección
    }
        
    function formatFecha(fecha) {
        const dia = fecha.getDate().toString().padStart(2, '0');
        const mes = (fecha.getMonth() + 1).toString().padStart(2, '0');
        const anio = fecha.getFullYear();
        return `${dia}/${mes}/${anio}`;
    }

    function verificarFormatoMoneda(valor) { // Nueva función para verificar el formato de moneda
        const regex = /^(S\/\.|US\$)\s?\d{1,3}(?:,\d{3})*(?:\.\d{2})?$/; // Expresión regular para S/. 20.50 o US$ 20.50
        return regex.test(valor); // Devuelve true si el formato es correcto
    }

    function formatMoneda(valor, tipoMoneda) {
        if (tipoMoneda === 'Soles') {
            return 'S/. ' + valor.toLocaleString('es-PE', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
        } else if (tipoMoneda === 'Dólares') {
            return 'US$ ' + valor.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
        }
        return valor.toLocaleString('es-PE', { minimumFractionDigits: 2, maximumFractionDigits: 2 }); // Si no hay selección, mostrar sin prefijo
    }
    
    // Modificado: Función para agregar el prefijo automáticamente al monto según la selección del radiobutton
    document.getElementById('monto').addEventListener('input', function() {
        const tipoMoneda = obtenerTipoMoneda(); // Obtener el tipo de moneda seleccionado
        let monto = document.getElementById('monto').value;

        if (tipoMoneda === 'Soles' && !monto.startsWith('S/.')) {
            document.getElementById('monto').value = 'S/. ' + monto.replace(/[^\d,]/g, '');
        } else if (tipoMoneda === 'Dólares' && !monto.startsWith('US$')) {
            document.getElementById('monto').value = 'US$ ' + monto.replace(/[^\d,]/g, '');
        }
        calcularFinanciamiento(); // Recalcular el financiamiento al cambiar el monto
    });

    document.querySelectorAll('input[name="tipoMoneda"]').forEach(radio => {
        radio.addEventListener('change', function() {
            const montoInput = document.getElementById('monto');
            const tipoMoneda = obtenerTipoMoneda();
            let monto = montoInput.value.replace(/[^\d,\.]/g, ''); // Eliminar todo lo que no sea número, coma o punto decimal (modificado para aceptar el punto) // Modificado

            // Verificar si el valor tiene un símbolo de moneda y formato correcto
            if (montoInput.value.includes('S/.') || montoInput.value.includes('US$')) { // Si ya tiene el símbolo S/. o US$, no cambiar el valor // Modificado
                // Solo cambiar el símbolo, sin modificar el valor
                if (tipoMoneda === 'Soles' && !montoInput.value.includes('S/.')) { // Si es Soles y no tiene el símbolo S/. // Modificado
                    montoInput.value = montoInput.value.replace(/US\$/, 'S/.'); // Reemplazar US$ por S/. // Modificado
                } else if (tipoMoneda === 'Dólares' && !montoInput.value.includes('US$')) { // Si es Dólares y no tiene el símbolo US$ // Modificado
                    montoInput.value = montoInput.value.replace(/S\/\./, 'US$'); // Reemplazar S/. por US$ // Modificado
                }
            } else {
                // Si no tiene símbolo, asignar el nuevo formato con el tipo de moneda seleccionado
                if (tipoMoneda === 'Soles') {
                    montoInput.value = 'S/. ' + monto; // Asignar el símbolo S/. // Modificado
                } else if (tipoMoneda === 'Dólares') {
                    montoInput.value = 'US$ ' + monto; // Asignar el símbolo US$ // Modificado
                }
            }
            calcularFinanciamiento(); // Recalcular el financiamiento al cambiar la moneda
        });
    });


    function saveFinanciamiento(event) {
        event.preventDefault(); // Prevenir el comportamiento por defecto del formulario

        // Obtener los valores de los campos
        const codigoAsociado = $('#codigoAsociado').val();
        const grupoFinanciamiento = $('#grupo').val();
        const cantidadProducto = $('#cantidad').val();
        let montoTotal = $('#monto').val(); // Obtenemos el valor del monto total
        const Frecuencia = $('#frecuenciaPago').val();
        let plan_telefono = $('#plan').val();
        const montoInscrip = $('#montoInscripcion').val();
        
        if (plan_telefono === 'notPlan') {  // Si el valor es 'notPlan'
        plan_telefono = null;  // Asignamos null a plan_telefono
        } else {
            // Si es otro valor, lo dejamos tal cual
            // Aquí puedes agregar el código para guardar el valor correctamente
            console.log("Valor del plan:", plan_telefono);  // Ejemplo de cómo guardar el valor
        }

        let tipoMoneda = obtenerTipoMoneda();

        if (!tipoMoneda) {
                    Swal.fire('Error', 'Por favor, seleccione un tipo de moneda.', 'error'); // Mensaje si no se selecciona moneda
                    return;
                }

        // Convertir "Soles" a "S/." y "Dólares" a "$"
        if (tipoMoneda === "Soles") {
            tipoMoneda = "S/.";
        } else if (tipoMoneda === "Dólares") {
            tipoMoneda = "$";
        }

        const cuotaInicial = $('#cuotaInicial').val();
        const cuotas = $('#cuotas').val();
        
        let valorCuota = $('#valorCuota').val(); // Obtenemos el valor del monto total

        valorCuota = valorCuota.replace('S/. ', '').replace('US$ ', '').replace(',', ''); // ✅ Ahora también elimina "US$ "
        valorCuota = parseFloat(valorCuota);

        const estado = $('#estado').val();
        const fechaInicio = $('#fechaInicio').val();
        const fechaFin = $('#fechaFin').val();
        const fechaHoraActual = $('#fechaHoraActual').val();
        const numeroDocumento = $('#numeroDocumento').val();

        const fechasVencimiento = []; // Crear un arreglo vacío para almacenar las fechas
        $('#contenedorFechas span').each(function() {
            const textoFecha = $(this).text().split('Vencimiento: ')[1]; // Extraer la fecha de vencimiento
            if (textoFecha) {
                // Convertir la fecha a formato 'YYYY-MM-DD' para evitar problemas en el servidor
                const partesFecha = textoFecha.split('/');
                const fechaVencimiento = `${partesFecha[2]}-${partesFecha[1]}-${partesFecha[0]}`;
                fechasVencimiento.push(fechaVencimiento); // Agregar la fecha formateada al arreglo
            }
        });  

        
        const idProducto = productoSeleccionado?.id;

            if (!idProducto) {
            Swal.fire('Error', 'Debe seleccionar un producto.', 'error');
            return;
        }

        // Validaciones
        if (!codigoAsociado || !grupoFinanciamiento || !cantidadProducto || !montoTotal || !cuotaInicial || !cuotas || !estado || !fechaInicio || !fechaFin || !fechaHoraActual || !numeroDocumento) {
            Swal.fire('Error', 'Todos los campos son obligatorios.', 'error');
            return;
        }

        // Validar que la cuota inicial no supere el monto total
        if (parseFloat(cuotaInicial) > parseFloat(montoTotal)) {
            Swal.fire('Error', 'La cuota inicial no puede ser mayor al monto total.', 'error');
            return;
        }

        const fechaHoy = new Date();
        fechaHoy.setHours(0, 0, 0, 0); // Establecer la hora a las 00:00:00
        // Validar que la fecha de inicio no sea antes de hoy

        // Restar un día a la fecha actual para permitir ayer
        const fechaLimite = new Date(fechaHoy);
        fechaLimite.setDate(fechaHoy.getDate() - 1); // Restar un día

        if (new Date(fechaInicio) < fechaLimite) {
            Swal.fire('Error', 'La fecha de inicio no puede ser antes de ayer.', 'error');
            return;
        }

        // Validar que la fecha de fin no sea antes de la fecha de inicio
        if (new Date(fechaFin) < new Date(fechaInicio)) {
            Swal.fire('Error', 'La fecha de fin no puede ser antes de la fecha de inicio.', 'error');
            return;
        }

        // Buscar el id_conductor usando el número de documento
        $.ajax({
            url: '/arequipago/buscarConductor',
            type: 'GET',
            data: { nro_documento: numeroDocumento },
            dataType: 'json',
            success: function(response) {
                if (response && response.success) {
                    const idConductor = response.id_conductor;

                    // Enviar los datos al controlador para guardar el financiamiento
                    $.ajax({
                        url: '/arequipago/guardarFinanciamiento',
                        type: 'POST',
                        data: {
                            
                            id_conductor: idConductor, 
                            id_producto: idProducto,
                            valorCuota: valorCuota,
                            codigo_asociado: codigoAsociado,
                            grupo_financiamiento: grupoFinanciamiento,
                            cantidad_producto: cantidadProducto,
                            monto_total: montoTotal,
                            monto_inscrip: montoInscrip,
                            cuota_inicial: cuotaInicial,
                            cuotas: cuotas,
                            estado: estado,
                            fecha_inicio: fechaInicio,
                            fecha_fin: fechaFin,
                            fecha_creacion: fechaHoraActual,
                            fechas_vencimiento: fechasVencimiento,
                            frecuencia: Frecuencia,
                            planT: plan_telefono,
                            tipo_moneda: tipoMoneda
                        },
                        success: function(response) {
                            if (response.success) {
                                limpiarFormulario();
                                Swal.fire('Éxito', response.message, 'success');
                                generarContratoInstant(response.id_financiamiento);
                            } else {
                                Swal.fire('Error', response.message, 'error');
                            }
                        },
                        error: function() {
                            Swal.fire('Error', 'Hubo un error al guardar el financiamiento.', 'error');
                        }
                    });
                } else {
                    Swal.fire('Error', response.message || 'No se encontró un conductor con ese número de documento.', 'error');
                }
            },
            error: function() {
                Swal.fire('Error', 'Hubo un error al buscar el conductor.', 'error');
            }
        });
    }

    function limpiarFormulario() {
        document.getElementById('cliente').value = '';
        document.getElementById('cliente').dataset.id = '';
        document.getElementById('codigoAsociado').value = '';
        document.getElementById('monto').value = '';
        document.getElementById('grupo').value = '';
        document.getElementById('fechaInicio').value = '';
        document.getElementById('fechaFin').value = '';
       
        document.getElementById('valorCuota').value = '';
        document.getElementById('cuotas').value = '';
        document.getElementById('numeroDocumento').value = ''; // Limpiar numeroDocumento
        document.getElementById('cantidad').value = ''; // Limpiar cantidad

        // Limpiar buscarProducto solo si tiene contenido
        let buscarProducto = document.getElementById('buscarProducto');
        if (buscarProducto.value.trim() !== '') {
            buscarProducto.value = '';
        }

        // Deseleccionar radio buttons de tipoMoneda
        document.getElementById('monedaSoles').checked = false;
        document.getElementById('monedaDolares').checked = false;

        // Limpiar inputs adicionales
        document.getElementById('cuotaInicial').value = '';
        document.getElementById('montoInscripcion').value = '';
        document.getElementById('tasaInteres').value = '';
        document.getElementById('valorCuota').value = '';

        // Llamar a funciones adicionales
        clearTable();
        cleanList();
        colorInput();
    }

    function limpiarFormularioChangueProduct() {
        $("#contenedorFechas").empty();
        document.getElementById('monto').value = '';
        document.getElementById('grupo').value = '';
        document.getElementById('fechaInicio').value = '';
        document.getElementById('fechaFin').value = '';
        document.getElementById('valorCuota').value = '';
        document.getElementById('cuotas').value = '';


        // Limpiar buscarProducto solo si tiene contenido
        let buscarProducto = document.getElementById('buscarProducto');
        if (buscarProducto.value.trim() !== '') {
            buscarProducto.value = '';
        }

        // Deseleccionar radio buttons de tipoMoneda
        document.getElementById('monedaSoles').checked = false;
        document.getElementById('monedaDolares').checked = false;

        // Limpiar inputs adicionales
        document.getElementById('cuotaInicial').value = '';
        document.getElementById('montoInscripcion').value = '';
        document.getElementById('tasaInteres').value = '';
        document.getElementById('valorCuota').value = '';
    }

    function fechaHoraActual() {
        let now = new Date();
        let dateTimeLocal = document.getElementById("fechaHoraActual");
        now.setMinutes(now.getMinutes() - now.getTimezoneOffset()); // Resta el offset de la zona horaria para obtener la hora local correctamente

        let formattedDate = now.toISOString().slice(0, 16); // Mantener el formato para datetime-local
        dateTimeLocal.value = formattedDate; // Asignar el valor formateado al input
    }

    if (typeof currentPage === 'undefined') {
    var currentPage = 1; // Cambiar let por var para evitar conflictos de ámbito
    }
    if (typeof totalPages === 'undefined') {
        var totalPages = 1;
    }
    if (typeof productoSeleccionado === 'undefined') {
        var productoSeleccionado = null;
    }
    
    var currentPage = 1;
    var totalPages = 1;
    var productoSeleccionado = null;

    function cargarProductos() {
        $.ajax({
            url: `/arequipago/obtenerProductos?pagina=${currentPage}`,
            type: 'GET',
            dataType: 'json',
            success: function(data) {
                mostrarProductos(data.productos);
                totalPages = data.totalPaginas;
                $('#pageNumber').text(`Página ${currentPage}`);
                $('#btnAtras').prop('disabled', currentPage <= 1);
                $('#btnAdelante').prop('disabled', currentPage >= totalPages);
            },
            error: function() {
                alert("Error al cargar los productos");
            }
        });
    }

    function buscarProductos() {
        const searchTerm = $('#buscarProducto').val();
        $.ajax({
            url: `/arequipago/busquedaProductos?searchTerm=${encodeURIComponent(searchTerm)}&pagina=${currentPage}`,
            type: 'GET',
            dataType: 'json',
            success: function(data) {
                mostrarProductos(data.productos, searchTerm);
            },
            error: function() {
                alert("Error al realizar la búsqueda");
            }
        });
    }

    

    function mostrarProductos(productos, searchTerm = '') {
        const tbody = $('#tablaProductos');
        tbody.empty();

        // Si hay un producto seleccionado, agregarlo como primer registro
        if (productoSeleccionado) {
            tbody.append(`
                <tr class="producto-row ${productoSeleccionado.id ? 'producto-seleccionado' : ''}" data-id-producto="${productoSeleccionado.id}">
                    <td><input type="radio" name="producto" class="producto-checkbox" value="${productoSeleccionado.id}" checked></td>
                    <td>${productoSeleccionado.nombre}</td>
                    <td>${productoSeleccionado.codigo}</td>
                    <td>${productoSeleccionado.cantidad}</td>
                    <td>${productoSeleccionado.unidad_medida}</td>
                    <td>${productoSeleccionado.perfil}</td>
                    <td>${productoSeleccionado.aro}</td>
                    <td>${productoSeleccionado.precio_venta}</td>
                </tr>
            `);
        }

        // Cargar los productos de la búsqueda o todos si no hay término de búsqueda
        productos.forEach(producto => {
            if (!productoSeleccionado || producto.idproductosv2 !== productoSeleccionado.id) {
                tbody.append(`
                    <tr class="producto-row" data-id-producto="${producto.idproductosv2}">
                        <td><input type="radio" name="producto" class="producto-checkbox" value="${producto.idproductosv2}"></td>
                        <td>${producto.nombre || 'N/A'}</td>
                        <td>${producto.codigo || 'N/A'}</td>
                        <td>${producto.cantidad || 0}</td>
                        <td>${producto.unidad_medida || 'N/A'}</td>
                        <td>${producto.perfil || 'N/A'}</td>
                        <td>${producto.aro || 'N/A'}</td>
                        <td>${producto.precio_venta || '0.00'}</td>
                    </tr>
                `);
            }
        });

        // Manejar selección de productos
        $('.producto-checkbox').change(function() {
            const row = $(this).closest('tr');
            productoSeleccionado = {
                id: row.data('id-producto'),
                nombre: row.find('td:nth-child(2)').text(),
                codigo: row.find('td:nth-child(3)').text(),
                cantidad: row.find('td:nth-child(4)').text(),
                unidad_medida: row.find('td:nth-child(5)').text(),
                perfil: row.find('td:nth-child(6)').text(),
                aro: row.find('td:nth-child(7)').text(),
                precio_venta: row.find('td:nth-child(8)').text()
            };
            tipoXCamposDinamicos(productoSeleccionado.id);
            cargarProductos(); // Recargar para mover el producto seleccionado al inicio
            planChecker(productoSeleccionado.id);
            resaltarProductoSeleccionado();
        });
    }

    function cambiarPagina(direccion) {
        currentPage += direccion;
        const searchTerm = $('#buscarProducto').val();
        if (searchTerm) {
            buscarProductos();
        } else {
            cargarProductos();
        }
    }

    // Llamar a la función de búsqueda cuando el campo de búsqueda cambie
    $('#buscarProducto').on('input', function() {
        const searchTerm = $(this).val();
        if (searchTerm) {
            buscarProductos();
        } else {
            cargarProductos(); // Recargar todos los productos si no hay término de búsqueda
        }
    });

    // Asegurarse de que el producto marcado se mantenga seleccionado al cargar la página
    $(document).ready(function() {
        if (productoSeleccionado) {
            cargarProductos(); // Recargar productos si ya hay uno seleccionado
        } else {
            cargarProductos(); // Cargar productos normalmente
        }
    });

    // Llamar a la función para resaltar el producto seleccionado
    function resaltarProductoSeleccionado() {
        console.log("resaltaProducto");

        console.log("resaltaProducto"); // Verifica si la función se ejecuta correctamente

        // Elimina la clase de todas las filas antes de asignarla a la seleccionada
        $('#tablaProductos tr').removeClass('producto-seleccionado'); // <-- Cambio: Limpia la selección previa

        // Encuentra el radio seleccionado y resalta su fila
        $('#tablaProductos input[type="radio"]:checked').each(function() { // <-- Cambio: Selecciona solo los radios marcados
            $(this).closest('tr').addClass('producto-seleccionado'); // <-- Cambio: Resalta solo la fila seleccionada
        });
    }

    

    function tipoXCamposDinamicos() {
        // Obtener el ID del producto seleccionado
        const productoId = $('.producto-checkbox:checked').val(); // ID del producto marcado

        if (!productoId) {
            // Ocultar los campos dinámicos si no hay un producto seleccionado
            $('#camposDinamicos').addClass('d-none');
            return;
        }

        // Realizar una solicitud AJAX al controlador para verificar la categoría
        $.ajax({
            url: '/arequipago/tipoProducto?id_producto=' + productoId, // Concatenación explícita
            type: 'GET',
            dataType: 'json',
            success: function(response) {
                if (response.error) {
                    alert(response.error);
                } else if (response.tipo_producto === "Llantas") {
                    ///$('#camposDinamicos').removeClass('d-none');
                    $('#FotoDinamica').removeClass('d-none');
                    $('#planContainer').addClass('d-none');
                } else if (response.tipo_producto === "Celular") {
                    $('#FotoDinamica').addClass('d-none'); // Oculta la imagen de llantas
                    $('#planContainer').removeClass('d-none'); // Muestra el contenedor de planes
                    planMensual();
                }  else {
                    $('#FotoDinamica').addClass('d-none'); // Oculta la imagen de llantas
                    $('#planContainer').addClass('d-none'); // Oculta el contenedor de planes
                }

            },
            error: function() {
                alert("Error al verificar el tipo de producto.");
            }
        });
    }

    let timeout; // Declarar la variable globalmente

    // Vincular la función a los checkboxes
    $(document).on('change', '.producto-checkbox', function() {
        tipoXCamposDinamicos(); // Llamar a la función cada vez que se seleccione un producto
        clearTimeout(timeout); // Limpia cualquier timeout previo
        timeout = setTimeout(calcularMonto, 4000);
    });

    function calcularMonto() {
        // Obtener el precio del producto seleccionado
        console.log("funciona calcularMonto");
        console.log("el valor obtenido es:", productoSeleccionado.precio_venta);
        const precio = parseFloat(productoSeleccionado.precio_venta);
        
        
        console.log("el valor del precio de la variable precio es:");
        console.log(precio);
        // Obtener la cantidad ingresada
        console.log("Valor crudo del input cantidad:", $('#cantidad').val());

        let cantidad = parseFloat($('#cantidad').val()) || 0; // Si no es número, usa 0
        console.log("Cantidad ingresada:", cantidad);
        

        // Calcular el monto
        const monto = precio * cantidad;

        // Establecer el monto en el campo de texto
        $('#monto').val('S/. ' + monto.toFixed(2));// Mostrar con 2 decimales
        $('#monto')[0].dispatchEvent(new Event('input'));
        $('#monto').val('S/. ' + monto.toFixed(2));
    }

    function planMensual() {
        // Realizamos la solicitud AJAX
        $.ajax({
            url: '/arequipago/buscarPlanesMensuales',  // Ruta de la solicitud AJAX
            type: 'POST',
            dataType: 'json',  // Esperamos una respuesta en formato JSON
            success: function(data) {
                // Limpiar el select antes de agregar nuevas opciones
                const selectPlan = document.getElementById('plan');
                console.log("el id del select es", selectPlan);
                selectPlan.innerHTML = '<option value="notPlan">Seleccionar</option>';  // Opción inicial

                // Recorremos los datos de los planes y los agregamos al select
                data.forEach(function(plan) {
                    const option = document.createElement('option');
                    option.value = plan.idproductosv2;  // Seteamos el ID del producto como valor
                    option.textContent = `${plan.operadora} | ${plan.plan_mensual} | S/. ${parseFloat(plan.precio).toFixed(2)}`;  // Cambié 'plan.precio' para convertirlo a número
                    selectPlan.appendChild(option);
                });
            },
            error: function(xhr, status, error) {
                console.error("Error al cargar los planes:", error);
            }
        });
    }

    
    function buscarFinanciamientos() {
        const query = document.getElementById("buscar-financiamientos").value;

        fetch('/arequipago/busquedaFinanciamientos', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ query }),
        })
            .then((response) => response.json())
            .then((data) => {
                const tbody = document.querySelector('.tabla-financiamientos tbody');
                
                const rows = tbody.querySelectorAll('tr'); // Obtener todas las filas
                rows.forEach(row => {
                    if (row.cells[0] && row.cells[0].textContent === "No se encontraron resultados.") {
                        row.remove(); // Si es la fila del mensaje, la eliminamos
                    }
                });


                if (data.length > 0) {
                    data.forEach((item) => {

                        // Verificar si la fila con el mismo id ya existe en la tabla para evitar duplicados
                        const existingRow = Array.from(tbody.rows).find(row => row.cells[0].innerText == item.id.toString()); // Comprobamos si ya existe una fila con el mismo ID
                        if (existingRow) return; // Si ya existe, no agregamos la fila

                        const row = document.createElement('tr');
                        row.innerHTML = `
                            <td>${item.id}</td>
                            <td>${item.cliente}</td>
                            <td>${item.fecha}</td>
                            <td>${item.monto}</td>
                            <td>${item.estado}</td>
                            <td>
                                <button onclick="cargarDetallesFinanciamiento(${item.id})" data-bs-toggle="modal" data-bs-target="#modalFinanciamiento">👁️</button> 
                                <button onclick="eliminarDeTabla(this)">X</button> <!-- Botón de eliminar con "X" -->
                            </td>
                        `;
                        tbody.appendChild(row);
                    });
                } else {
                    tbody.innerHTML += '<tr><td colspan="6">No se encontraron resultados.</td></tr>'; 
                }
            })
            .catch((error) => console.error('Error:', error));
    }

    function visualizarFinanciamiento(id) {
    // Aquí puedes escribir el código para visualizar el financiamiento
    }

    // Función para eliminar un registro de la tabla
    function eliminarDeTabla(button) {
        const row = button.closest('tr'); // Encontrar la fila del botón
        row.remove(); // Eliminar la fila de la tabla
    }
    
    function cargarDetallesFinanciamiento(idFinanciamiento) {
        fetch(`/arequipago/obtenerFinanciamientoDetalle?id_financiamiento=${idFinanciamiento}`) // Usar el ID proporcionado
            .then(response => response.json())
            .then(data => {
                if (data.error) {
                    alert(`Error: ${data.error}`);
                    return;
                }

                // Información general
                document.querySelector('#modalFinanciamiento .modal-body').innerHTML = `
                <!-- Información General -->
                <div class="modal-section" id="financiamientoModalSection">
                    <h6>Información General</h6>
                    <div class="row">
                        <div class="col-md-6">
                            <p><strong>ID del Financiamiento:</strong> ${data.financiamiento.idfinanciamiento || 'N/A'}</p>
                            <p><strong>Fecha de Creación:</strong> ${data.financiamiento.fecha_creacion || 'N/A'}</p>
                        </div>
                        <div class="col-md-6">
                            <p><strong>Estado:</strong> ${data.financiamiento.estado || 'N/A'}</p>
                        </div>
                    </div>
                </div>

                <!-- Información del Conductor -->
                <div class="modal-section" id="financiamientoModalSection">
                    <h6>Información del Conductor</h6>
                    <div class="row">
                        <div class="col-md-6">
                            <p><strong>Nombre:</strong> ${data.conductor.nombres || 'N/A'} ${data.conductor.apellido_paterno || 'N/A'} ${data.conductor.apellido_materno || 'N/A'}</p>
                            <p><strong>Dirección:</strong> ${data.conductor.direccion || 'N/A'}</p>
                        </div>
                        <div class="col-md-6">
                            <p><strong>Número de Celular:</strong> ${data.conductor.telefono || 'N/A'}</p>
                            <p><strong>Correo:</strong> ${data.conductor.correo || 'N/A'}</p>
                        </div>
                    </div>
                </div>

                <!-- Información del Producto -->
                <div class="modal-section" id="financiamientoModalSection">
                    <h6>Información del Producto</h6>
                    <div class="row">
                        <div class="col-md-6">
                            <p><strong>Código de Producto:</strong> ${data.producto ? data.producto.codigo : 'N/A'}</p>
                        </div>
                        <div class="col-md-6">
                            <p><strong>Nombre del Producto:</strong> ${data.producto ? data.producto.nombre : 'Producto no disponible'}</p>
                        </div>
                        <div class="col-md-6">
                            <p><strong>Cantidad:</strong> ${data.financiamiento.cantidad_producto || 'N/A'}</p>
                        </div>
                    </div>
                </div>

                <!-- Información del Financiamiento -->
                <div class="modal-section" id="financiamientoModalSection">
                    <h6>Información del Financiamiento</h6>
                    <div class="row">
                        <div class="col-md-6">
                            <p><strong>Monto:</strong> ${data.financiamiento.monto_total || 'N/A'}</p>
                            <p><strong>Cuota Inicial:</strong> ${data.financiamiento.cuota_inicial || 'N/A'}</p>
                        </div>
                        <div class="col-md-6">
                            <p><strong>Cuotas:</strong> ${data.financiamiento.cuotas || 'N/A'}</p>
                            <p><strong>Fecha de Inicio:</strong> ${data.financiamiento.fecha_inicio || 'N/A'}</p>
                            <p><strong>Fecha de Fin:</strong> ${data.financiamiento.fecha_fin || 'N/A'}</p>
                        </div>
                    </div>
                </div>
            `;
            })
            .catch(error => console.error('Error:', error));
    }

    function cargarFinanciamientos() {
        const fechaInicio = document.querySelector('#fecha-inicio').value;
        const fechaFin = document.querySelector('#fecha-fin').value;

        // Validar que la fecha de fin no sea anterior a la de inicio
        if (fechaInicio && fechaFin && fechaFin < fechaInicio) {
            alert('La fecha de fin no puede ser anterior a la fecha de inicio.');
            return;
        }

        if (fechaInicio && fechaFin) {
            // Crear el objeto con las fechas
            const data = {
                fecha_inicio: fechaInicio,
                fecha_fin: fechaFin
            };

            // Enviar la solicitud AJAX
            fetch('/arequipago/obtenerFinanciamientosPorFecha', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(data)
            })
            .then(response => response.json())
        .then(data => {
            const tbody = document.querySelector('.tabla-financiamientos tbody');
            console.log('tbody:', tbody); // Verificar que el tbody está siendo seleccionado correctamente

            if (data.length > 0) {
                data.forEach(item => {
                    console.log('Item:', item); // Verificar que los datos se están recorriendo correctamente

                    // Verificar si el financiamiento ya está en la tabla para evitar duplicados
                    const existingRow = Array.from(tbody.rows).find(row => row.cells[0].innerText == item.id.toString()); // Cambié la comparación a string para evitar problemas de tipo
                    if (existingRow) return; // Si ya existe, no agregarlo

                    const row = document.createElement('tr');
                    row.innerHTML = `
                        <td>${item.id}</td>
                        <td>${item.cliente}</td>
                        <td>${item.fecha}</td>
                        <td>${item.monto}</td>
                        <td>${item.estado}</td>
                        <td>
                            <button onclick="cargarDetallesFinanciamiento(${item.id})" data-bs-toggle="modal" data-bs-target="#modalFinanciamiento">👁️</button>
                            <button onclick="eliminarDeTabla(this)">X</button>
                        </td>
                    `;
                    tbody.appendChild(row); // Agregar la fila al tbody
                });
            } else {
                alert('No se encontraron financiamientos para el rango de fechas seleccionado.');
            }
        })
        .catch(error => console.error('Error:', error));
    }
}

    function limpiarFechas() {
        document.getElementById('fecha-inicio').value = ''; // Limpiar el campo de fecha de inicio
        document.getElementById('fecha-fin').value = ''; // Limpiar el campo de fecha de fin
    }

    function GenerarContratos() {
    const rows = document.querySelectorAll('.tabla-financiamientos tbody tr');
    const ids = [];

    rows.forEach(row => {
        const idCell = row.querySelector('td');
        if (idCell) {
            const idFinanciamiento = idCell.textContent.trim();
            if (idFinanciamiento) {
                ids.push(idFinanciamiento);
            }
        }
    });

    if (ids.length === 0) {
        Swal.fire('Error', 'No hay financiamientos seleccionados.', 'error');
        return;
    }

    fetch('/arequipago/generarContratos', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ ids }),
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            Object.entries(data.pdfs).forEach(([id, pdf]) => { // Modificado: Cambiado pdfBase64 a pdf para acceder correctamente
                const linkSource = `data:application/pdf;base64,${pdf.content}`; // Modificado: Acceso a pdf.content
                const downloadLink = document.createElement("a");
                const fileName = pdf.nombre; // Modificado: Usar el nombre del archivo enviado desde el servidor

                downloadLink.href = linkSource;
                downloadLink.download = fileName;
                downloadLink.click();
            });
            Swal.fire('Éxito', 'Los contratos se generaron y descargaron correctamente.', 'success');
        } else {
            Swal.fire(
                'Atención',
                `Estos contratos no se generaron: ${data.errores.join(', ')}`,
                'warning'
            );
        }
    })
    .catch(error => {
        Swal.fire('Error', 'Ocurrió un error al generar los contratos.', 'error');
        console.error(error);
    });
}

    function saveGroupFinance() {
        const grupoFinanciamiento = document.getElementById('grupoFinanciamiento').value.trim(); // Obtener valor del input

        if (!grupoFinanciamiento) {
            Swal.fire({
                icon: 'warning',
                title: 'Campo vacío',
                text: 'Por favor, ingrese un nombre para el grupo de financiamiento antes de guardar.',
                confirmButtonText: 'Aceptar'
            });
            return;
        }

        $.ajax({
            url: '/arequipago/guardarGrupoFinanciamiento', // Ruta del Ajax
            type: 'POST',
            data: { nombre: grupoFinanciamiento }, // Enviar solo el dato del grupo
            dataType: 'json',
            success: function (response) {
                if (response.success) {
                    Swal.fire({
                        icon: 'success',
                        title: '¡Éxito!',
                        text: 'Grupo de financiamiento guardado correctamente.',
                        confirmButtonText: 'Aceptar'
                    });
                    cargarGruposFinanciamiento();

                    document.getElementById('grupoFinanciamiento').value = ''; // Limpiar el campo
                } else {
                    Swal.fire({
                        icon: 'error',
                        title: '¡Error!',
                        text: response.message || 'Hubo un problema al guardar el grupo de financiamiento.',
                        confirmButtonText: 'Aceptar'
                    });
                }
            },
            error: function (xhr) {
                Swal.fire({
                    icon: 'error',
                    title: '¡Error!',
                    text: 'Error al guardar el grupo de financiamiento. Intenta nuevamente.',
                    confirmButtonText: 'Aceptar'
                });
                console.error('Detalles del error:', xhr.responseText);
            }
        });
    }

    function clearTable() {
        productoSeleccionado = null; // Eliminar el producto seleccionado
        cargarProductos(); // Volver a cargar los productos normalmente sin selección
    }

    function cargarGruposFinanciamiento() {
    $.ajax({
        url: "/cargarGruposFinanciamiento", // Ruta del Ajax
        method: "GET",
        dataType: "json",
        success: function (response) {
            if (Array.isArray(response)) {
                var select = $('#grupo');
                var opcionesExistentes = Array.from(select.find('option')).map(option => option.value);

                response.forEach(function (grupo) {
                    if (!opcionesExistentes.includes(grupo.idgrupoVehicular_financiamiento.toString())) {
                        select.append($('<option>', {
                            value: grupo.idgrupoVehicular_financiamiento,
                            text: grupo.nombre
                        }));
                    }
                });
            } else {
                console.error("La respuesta no es un arreglo válido.");
            }
        },
        error: function () {
            alert('Ocurrió un error al obtener los grupos de financiamiento.');
        }
    });
}

    function cargarGruposFinanciamiento() {
        $.ajax({
            url: "/arequipago/cargarGruposFinanciamiento", // Ruta del Ajax
            method: "GET",
            dataType: "json",
            success: function (response) {
                if (Array.isArray(response)) {
                    var select = $('#grupo');
                    var opcionesExistentes = Array.from(select.find('option')).map(option => option.value);

                    response.forEach(function (grupo) {
                        if (!opcionesExistentes.includes(grupo.idgrupoVehicular_financiamiento.toString())) {
                            select.append($('<option>', {
                                value: grupo.idgrupoVehicular_financiamiento,
                                text: grupo.nombre
                            }));
                        }
                    });
                } else {
                    console.error("La respuesta no es un arreglo válido.");
                }
            },
            error: function () {
                alert('Ocurrió un error al obtener los grupos de financiamiento.');
            }
        });
    }

    function generateCronograma() {
        // Obtener los valores de los inputs
        const nombreCliente = document.getElementById('cliente').value;
        const numeroDocumento = document.getElementById('numeroDocumento').value;
        const fechaInicio = document.getElementById('fechaInicio').value;
                 
        const tasaInteres = document.getElementById('tasaInteres').value;
        const frecuenciaPago = document.getElementById('frecuenciaPago').value; // Obtener la opción seleccionada del select

        let tipoMoneda = obtenerTipoMoneda(); // Obtener el tipo de moneda seleccionado
        let monto = document.getElementById('monto').value;

        if (!tipoMoneda) {
            Swal.fire('Error', 'Por favor, seleccione un tipo de moneda.', 'error'); // Mensaje si no se selecciona moneda
            return;
        }

        

        if (tipoMoneda === 'Soles') {
            monto = monto.replace('S/. ', ''); // Eliminar el "S/. " para Soles
        } else if (tipoMoneda === 'Dólares') {
            monto = monto.replace('US$ ', ''); // Eliminar el "US$ " para Dólares
        }

        // Modificar tipoMoneda para enviar el símbolo y no el nombre
        if (tipoMoneda === 'Soles') { // Si la moneda es Soles
            tipoMoneda = 'S/. '; // Cambiar a símbolo S/. 
        } else if (tipoMoneda === 'Dólares') { // Si la moneda es Dólares
            tipoMoneda = 'US$ '; // Cambiar a símbolo US$
        } else {
            tipoMoneda = ''; // Si no se selecciona ninguna moneda, se deja vacío
        }
    
        // Validaciones
        if (parseFloat(monto) <= 0) {
            Swal.fire('Error', 'El monto del financiamiento debe ser mayor a 0.', 'error');
            return;
        }

        // Validar que la cuota inicial no supere el monto total
        const cuotaInicial = document.getElementById('cuotaInicial').value.replace('S/. ', ''); // Si existe el input
        if (parseFloat(cuotaInicial) > parseFloat(monto)) {
            Swal.fire('Error', 'La cuota inicial no puede ser mayor al monto total.', 'error');
            return;
        }

        // Validar fecha de inicio
        const fechaHoy = new Date();
        fechaHoy.setHours(0, 0, 0, 0);
        const fechaLimite = new Date(fechaHoy);
        fechaLimite.setDate(fechaHoy.getDate() - 1); // Restar un día

        if (new Date(fechaInicio) < fechaLimite) {
            Swal.fire('Error', 'La fecha de inicio no puede ser antes de ayer.', 'error');
            return;
        }

        console.log("Enviando cronogramaDatos al backend:", cronogramaDatos);
        // Aquí agregamos los datos del cronograma al objeto de datos
        const datosFormulario = {
            nombreCliente: nombreCliente,
            numeroDocumento: numeroDocumento,
            fechaInicio: fechaInicio,
            monto: monto,
            tasaInteres: tasaInteres,
            frecuenciaPago: frecuenciaPago, // Pasar la frecuencia de pago
            tipoMoneda: tipoMoneda,
            cronograma: cronogramaDatos // Los datos del cronograma
        };

            $.ajax({
                url: "/arequipago/generarCronogramaPDF",
                method: "POST",
                dataType: "json",
                data: JSON.stringify(datosFormulario),
                contentType: "application/json",
                success: function (response) {
                    if (response.success) {
                        Swal.fire({
                            title: 'Éxito',
                            text: 'El cronograma se generó correctamente. Descargando el archivo...',
                            icon: 'success',
                            showConfirmButton: false,
                            timer: 2000
                        });

                        // Crear un enlace temporal para descargar el archivo
                        const link = document.createElement('a');
                        link.href = 'data:application/pdf;base64,' + response.pdf; // Base64 del PDF
                        link.download = response.nombre; // Nombre del archivo
                        link.click(); // Simular clic para iniciar la descarga
                    } else {
                        Swal.fire('Error', 'No se pudo generar el cronograma. Intenta nuevamente.', 'error');
                    }
                },
                error: function (error) {
                    Swal.fire('Error', 'Ocurrió un problema al generar el cronograma. Intenta nuevamente.', 'error');
                    console.error('Error al enviar los datos:', error);
                }
            });

    }    

    // Función para aplicar el color a los inputs
    function colorInput() {
        // Aplica el color de fondo a los inputs específicos al cargar la página
        $('#cuotaInicial, #tasaInteres, #fechaInicio, #cuotas').each(function() {  // Seleccionamos los inputs por su id
            if ($(this).val() === '') {
                $(this).addClass('colorCharged');  // Si el input está vacío, añadimos la clase
            } else {
                $(this).removeClass('colorCharged');  // Si tiene valor, eliminamos la clase
            }
        });

        // Detecta cuando el usuario escribe en el input para eliminar la clase 'colorCharged'
        $('#cuotaInicial, #tasaInteres, #fechaInicio, #cuotas').on('input', function() {  // Solo los inputs específicos
            if ($(this).val() !== '') {
                $(this).removeClass('colorCharged');  // Si el input tiene valor, quitamos el color
            } else {
                $(this).addClass('colorCharged');  // Si el input está vacío, añadimos el color
            }
        });
    }

    function cargarTypeCambio() {
        // URL de tu controlador PHP
        
        $.ajax({
            url: "/arequipago/TipoCambio",
            method: "GET",
            dataType: "json",
            success: function (response) {
                if (response.error) {
                    console.error("Error del servidor:", response.error);
                    $("#tipoCambio").text("<--DATA NOT RECEIVED-->");
                    return;
                }

                // Actualizar el label con el tipo de cambio
                $("#tipoCambio").text(`Tipo de cambio: S/ ${response.tipo_cambio}`); // Usamos 'response.tipo_cambio'
            },
            error: function (xhr, status, error) {
                console.error("Error al cargar el tipo de cambio:", error);
                $("#tipoCambio").text("<--DATA NOT RECEIVED-->");
            },
        });
    }

    function cleanList() {
        const contenedorFechas = document.getElementById('contenedorFechas');
        if (contenedorFechas) {
            contenedorFechas.innerHTML = ''; // Limpiar todo el contenido del contenedor
        }
        cronogramaDatos = []; // Vaciar el array de datos del cronograma
    }

    function toggleDropdown() { 
        // Función para mostrar u ocultar la tabla
        var table = document.getElementById("cronogramaSelect"); 
        if (table.style.display === "none") { 
            table.style.display = "table"; // Mostrar tabla si está oculta
        } else {
            table.style.display = "none"; // Ocultar tabla si está visible
        }
    }

    function seleccionarFila(fila, financiamiento) {
        var textoSeleccionado = fila.cells[0].innerText; // Obtener texto de la primera columna
        document.getElementById("selectBox").innerText = textoSeleccionado + " ⬇"; // Mostrar opción seleccionada en el selectBox
        document.getElementById("cronogramaSelect").style.display = "none"; // Ocultar tabla después de seleccionar
        llenarTablaCuotas(financiamiento); 
    }

    function llenarTablaCuotas(financiamiento) {
        var tablaCuotas = document.querySelector("#tablaCuotas tbody"); //
        tablaCuotas.innerHTML = ""; // Limpiar la tabla antes de llenarla

        financiamiento.cuotas.forEach(cuota => {
            var fila = document.createElement("tr");

            var moneda = financiamiento.moneda ? financiamiento.moneda : "S/.";

            fila.innerHTML = `
                <td>${cuota.fecha_vencimiento}</td>
                <td>${moneda} ${cuota.monto}</td>
                <td>${cuota.estado}</td>
            `;
            tablaCuotas.appendChild(fila);
        });

        document.getElementById("tablaCuotas").style.display = "table"; 
    }

    function toggleDropdownDetalle() { 
        var table = document.getElementById("detalleSelect"); // Cambio de "cronogramaSelect" a "detalleSelect"
        table.style.display = (table.style.display === "none" || table.style.display === "") ? "table" : "none"; 
    }

    let idFinanciamientoSeleccionado = null;

    function seleccionarFinanciamiento(row) {

        let financiamiento = JSON.parse(row.getAttribute('data-financiamiento'));
        //console.log('Este es el financiamientooo: ', financiamiento);
        idFinanciamientoSeleccionado = financiamiento.financiamiento.idfinanciamiento;
        // Obtener el símbolo de la moneda
        let simboloMoneda = financiamiento.financiamiento.moneda;

        // Actualizar el "select box" con el nombre del producto seleccionado
        document.getElementById("selectBoxDetalle").innerText = financiamiento.producto.nombre || "Seleccionar un financiamiento";

        // Mostrar el contenedor de detalles
        let detalleContainer = document.getElementById("detalleFinanciamientoContainer");
        detalleContainer.style.display = "block";  

        // Llenar los datos del cliente
        document.getElementById("modalClienteDocumento").innerText = financiamiento.conductor.nro_documento || "N/A";
        let nombreCompleto = `${financiamiento.conductor.nombres || ''} ${financiamiento.conductor.apellido_paterno || ''} ${financiamiento.conductor.apellido_materno || ''}`.trim();
        document.getElementById("modalClienteNombres").innerText = nombreCompleto || "N/A";
        let direccionCompleta = `${financiamiento.direccion.departamento || ''}, ${financiamiento.direccion.provincia || ''}, ${financiamiento.direccion.distrito || ''}, ${financiamiento.direccion.direccion_detalle || ''}`.trim();
        document.getElementById("modalClienteDireccion").innerText = direccionCompleta || "Dirección no disponible";
        document.getElementById("modalClienteTelefono").innerText = financiamiento.conductor.telefono || "N/A";

        // Llenar los datos del financiamiento
        document.getElementById("modalFinanciamientoCodigo").innerText = financiamiento.financiamiento.codigo_asociado || "N/A";
        document.getElementById("modalFinanciamientoGrupo").innerText = financiamiento.financiamiento.grupo_financiamiento || "N/A";
        document.getElementById("modalFinanciamientoEstado").innerText = financiamiento.financiamiento.estado || "N/A";
        document.getElementById("modalFechaInicio").innerText = financiamiento.financiamiento.fecha_inicio || "N/A";
        document.getElementById("modalFechaFin").innerText = financiamiento.financiamiento.fecha_fin || "N/A";

        // Llenar la tabla de cuotas
        let cuotasTable = document.getElementById("modalCuotasTable");
        cuotasTable.innerHTML = "";  // Limpiar contenido anterior
        if (financiamiento.financiamiento.cuotas && financiamiento.financiamiento.cuotas.length > 0) {
            let tableHeader = `
                <thead>
                    <tr>
                        <th>N° Cuota</th>
                        <th>Monto</th>
                        <th>Fecha Vencimiento</th>
                        <th>Estado</th>
                    </tr>
                </thead>
                <tbody>`;
            let tableBody = financiamiento.financiamiento.cuotas.map(cuota => `
                <tr>
                    <td>${cuota.numero_cuota}</td>
                    <td>${simboloMoneda} ${cuota.monto}</td>
                    <td>${cuota.fecha_vencimiento}</td>
                    <td>${cuota.estado}</td>
                </tr>
            `).join('');
            cuotasTable.innerHTML = tableHeader + tableBody + `</tbody>`;
        } else {
            cuotasTable.innerHTML = "<tr><td colspan='4'>No hay cuotas disponibles</td></tr>";
        }

        // Ocultar la tabla de selección después de elegir un financiamiento
        $("#detalleSelect").hide();
    }

    let perteneceGrupoFinanciamiento = false;

    function planChecker(idProducto) {
        limpiarFormularioChangueProduct();
        $.ajax({
            url: "/arequipago/obtener-plan-financiamiento", // Ajusta la ruta según tu backend
            type: "POST",
            data: { id_producto: idProducto },
            dataType: "json",
            success: function (respuesta) {
                if (respuesta.success && respuesta.plan) {
                    
                    perteneceGrupoFinanciamiento = true; // ✅ Se encontró un plan
  
                    var plan = respuesta.plan;

                    $("#cantidad").val(1); // Cantidad de productos = 1
                    $("#cantidad").prop("disabled", true);

                    if (plan.moneda === "S/.") { // Si la moneda es Soles
                        $("#monedaSoles").prop("checked", true); // Marca Soles ✅
                    } else if (plan.moneda === "$") { // Si la moneda es Dólares
                        $("#monedaDolares").prop("checked", true); // Marca Dólares ✅
                    }
                    
                    // Crear y asignar la opción correcta en el select ✅
                    let nuevaOpcion = new Option(plan.nombre_plan, plan.idplan_financiamiento, true, true);
                    $("#grupo").append(nuevaOpcion);

                    // Cuota inicial
                    $("#cuotaInicial").val(plan.cuota_inicial);
                    
                    // Frecuencia de pago (con primera letra en mayúscula)
                    let frecuencia = plan.frecuencia_pago.charAt(0).toUpperCase() + plan.frecuencia_pago.slice(1);
                    $("#frecuenciaPago").val(plan.frecuencia_pago); // Asignamos el valor

                    // Fecha de inicio = fecha de hoy
                    let hoy = new Date().toISOString().split("T")[0]; // Formato YYYY-MM-DD
                    $("#fechaInicio").val(hoy);

                    // Valor de la cuota
                    $("#valorCuota").val(plan.monto_cuota);

                    // Cantidad de cuotas
                    $("#cuotas").val(plan.cantidad_cuotas);

                    console.log("Tasa de interés recibida:", plan.tasa_interes); 
                    $("#tasaInteres").val(plan.tasa_interes);

                    $("#tasaInteres").trigger("change"); // 🔥 Se agrega esta línea para forzar el evento de cambio en el input (por si hay algún listener)

                    // Calcular fecha de fin si la frecuencia es mensual
                    if (plan.frecuencia_pago.toLowerCase() === "mensual") {
                        let fechaInicio = new Date(hoy);
                        fechaInicio.setMonth(fechaInicio.getMonth() + parseInt(plan.cantidad_cuotas)); // Sumar meses
                        let fechaFin = fechaInicio.toISOString().split("T")[0]; // Convertir a formato YYYY-MM-DD
                        $("#fechaFin").val(fechaFin);
                    }

                    

                    // 🔥 **Retraso de 4 segundos antes de calcular el cronograma**
                    setTimeout(() => {
                                        calcularCronogramaDinamico();
                                    }, 4000);

                } else {
                    perteneceGrupoFinanciamiento = false;
                    console.warn("No se encontró un plan de financiamiento.");
                    $("#cantidad").prop("disabled", false);
                }
            },
            error: function () {
                console.error("Error en la solicitud AJAX.");
            }
        });
    }

    function calcularCronogramaDinamico() {
        // Obtener valores de entrada
        let tasaInteres = parseFloat(document.getElementById("tasaInteres").value) || 0;
        let cuotas = parseInt(document.getElementById("cuotas").value) || 6;
        let fechaInicio = document.getElementById("fechaInicio").value;
        let fechaFinInput = document.getElementById("fechaFin");
        let cuotaInicial = parseFloat(document.getElementById("cuotaInicial").value) || 0;
        let valorCuota = parseFloat(document.getElementById("valorCuota").value) || 0;
        let montoTotalInput = document.getElementById("monto");
        let frecuencia = document.getElementById("frecuenciaPago").value;

        if (!fechaInicio) {
            alert("Debe ingresar una fecha de inicio.");
            return;
        }

        let fechaPago = new Date(fechaInicio);
        let fechasVencimiento = [];

        cronogramaDatos = []; // ✅ Usa el global sin redeclararlo


        for (let i = 0; i < cuotas; i++) {
            if (frecuencia === "mensual") {
                fechaPago.setMonth(fechaPago.getMonth() + 1);
            } else if (frecuencia === "semanal") {
                fechaPago.setDate(fechaPago.getDate() + 7);
            }
            fechasVencimiento.push(new Date(fechaPago));
        }

        let fechaFinCalculada = fechasVencimiento[fechasVencimiento.length - 1].toISOString().split('T')[0];
        fechaFinInput.value = fechaFinCalculada;

        // Calcular monto total del financiamiento
        let montoTotal = cuotaInicial + (valorCuota * cuotas);
        montoTotalInput.value = montoTotal.toFixed(2);

        mostrarFechasVencimientoPlan(fechasVencimiento, valorCuota);
    }

    function mostrarFechasVencimientoPlan(fechasVencimiento, valorcuota) {
        const contenedorFechas = document.getElementById('contenedorFechas');
        contenedorFechas.innerHTML = '';
        
        cronogramaDatos = [];
        fechasVencimiento.forEach((fecha, index) => {
            let dia = fecha.getDate().toString().padStart(2, '0'); // 🔹 Agregado para formato correcto
            let mes = (fecha.getMonth() + 1).toString().padStart(2, '0'); // 🔹 Agregado para formato correcto
            let anio = fecha.getFullYear(); // 🔹 Agregado para formato correcto
            let fechaFormateada = `${dia}/${mes}/${anio}`; // 🔹 Modificado a 'd/m/Y'
            contenedorFechas.innerHTML += `
                <div>
                    <label>Cuota ${index + 1}:</label>
                    <span>Valor: ${valorcuota.toFixed(2)} | Vencimiento: ${fechaFormateada}</span>
                </div>
            `;
            cronogramaDatos.push({
                cuota: index + 1,
                valor: valorcuota,
                vencimiento: fechaFormateada
            });
        });

        const botonDescargar = document.createElement('button');
        botonDescargar.type = 'button';
        botonDescargar.innerHTML = 'Cronograma <i class="fas fa-file-pdf"></i>';
        botonDescargar.style.backgroundColor = '#d32f2f';
        botonDescargar.style.color = '#FFFFFF';
        botonDescargar.style.border = 'none';
        botonDescargar.style.padding = '10px 15px';
        botonDescargar.style.borderRadius = '5px';
        botonDescargar.style.cursor = 'pointer';
        botonDescargar.style.marginTop = '10px';
        botonDescargar.style.display = 'inline-flex';
        botonDescargar.style.alignItems = 'center';
        botonDescargar.style.gap = '8px';

        botonDescargar.addEventListener('click', () => {
            generateCronograma();
        });
        contenedorFechas.appendChild(botonDescargar);
        console.log("Datos del cronograma antes de generar PDF:", cronogramaDatos);

    }

    // ✅ Nueva función para generar contrato instantáneamente
    function generarContratoInstant(idFinanciamiento) {
        fetch('/arequipago/generarContratos', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ ids: [idFinanciamiento] }), // ✅ Enviar el ID del financiamiento
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                Object.entries(data.pdfs).forEach(([id, pdf]) => {
                    const linkSource = `data:application/pdf;base64,${pdf.content}`;
                    const downloadLink = document.createElement("a");
                    const fileName = pdf.nombre;

                    downloadLink.href = linkSource;
                    downloadLink.download = fileName;
                    downloadLink.click();
                });
                Swal.fire('Éxito', 'El contrato se generó y descargó correctamente.', 'success');
            } else {
                Swal.fire('Atención', `Error al generar contrato: ${data.errores.join(', ')}`, 'warning');
            }
        })
        .catch(error => {
            Swal.fire('Error', 'Ocurrió un error al generar el contrato.', 'error');
            console.error(error);
        });
    }

    function deleteFinance() {
        console.log(idFinanciamientoSeleccionado);
    if (!idFinanciamientoSeleccionado) { // Validar si hay un ID seleccionado
        Swal.fire({
            icon: 'warning',
            title: 'Atención',
            text: 'No se ha seleccionado ningún financiamiento para eliminar.'
        });
        return;
    }

    console.log(idFinanciamientoSeleccionado);

        // Confirmación antes de eliminar
        Swal.fire({
            title: '¿Estás seguro?',
            text: 'Esta acción eliminará el financiamiento permanentemente.',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#d33',
            cancelButtonColor: '#3085d6',
            confirmButtonText: 'Sí, eliminar',
            cancelButtonText: 'Cancelar'
        }).then((result) => {
            if (result.isConfirmed) {
                
                $.ajax({
                    url: '/arequipago/deleteFinance', // URL de la API
                    type: 'POST', // Método de la solicitud
                    data: { id_financiamiento: idFinanciamientoSeleccionado }, // Enviar el ID como datos
                    dataType: 'json', // Tipo de respuesta esperada
                    success: function(response) {
                        if (response.success) { // Si la eliminación fue exitosa
                            Swal.fire({
                                icon: 'success',
                                title: 'Eliminado',
                                text: 'Financiamiento eliminado correctamente.'
                            }).then(() => {
                                let closeButton = document.querySelector("#financingDetailsModal .btn-close");
                                if (closeButton) {
                                    closeButton.click(); // Simula el clic en el botón de cierre
                                }
                                cargarClientes();
                            });
                        } else {
                            Swal.fire({
                                icon: 'error',
                                title: 'Error',
                                text: 'Error al eliminar el financiamiento: ' + response.message
                            });
                        }
                    },
                    error: function() {
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: 'Ocurrió un error al eliminar el financiamiento.'
                        });
                    }
                });
                
            }
        });
    }

    // Cargar los clientes cuando la página se carga por primera vez
    $(document).ready(function() {
            cargarGruposFinanciamiento();
            cargarClientes();
            vincularEventosFilas();
            vincularEventosCronograma();
            vincularEventosDetalles()
            fechaHoraActual();
            cargarProductos();
            colorInput(); 
            cargarTypeCambio();
            
            $('#tablaProductos').on('change', 'input[type="radio"]', function() { 
                resaltarProductoSeleccionado(); // Llamar a la función de resaltado
            });
                
   
            $("#listaFinanciamientoNav").on("click", function(e) {
                e.preventDefault();
                console.log(12);
                $("#listaClientes").removeClass("d-none"); // Ocultar lista de clientes
                $("#nuevoFinanciamientoForm").addClass("d-none"); // Mostrar formulario de financiamiento
                $("#generarContratosFrm").addClass("d-none"); // Ocultar el formulario de contratos
            });
   
            document.getElementById("nuevoFinanciamiento").addEventListener("click", function(e) {
                e.preventDefault();
                document.getElementById("listaClientes").classList.add("d-none"); // Ocultar lista de clientes
                document.getElementById("nuevoFinanciamientoForm").classList.remove("d-none"); // Mostrar formulario de financiamiento
                document.getElementById("generarContratosFrm").classList.add("d-none");
            });

            document.getElementById("GContratosNav").addEventListener("click", function(e) {
                e.preventDefault();
                document.getElementById("listaClientes").classList.add("d-none"); // Ocultar lista de clientes
                document.getElementById("nuevoFinanciamientoForm").classList.add("d-none");
                document.getElementById("generarContratosFrm").classList.remove("d-none");
            });

            document.getElementById("listaClientes").addEventListener("click", function(e) {
                document.getElementById("generarContratosFrm").classList.add("d-none");
            })


            // Cancelar formulario y regresar a la lista de clientes
                    document.getElementById("cancelarFinanciamiento").addEventListener("click", function() {
                    
                    document.getElementById("nuevoFinanciamientoForm").classList.add("d-none"); // Ocultar formulario
                    document.getElementById("listaClientes").classList.remove("d-none"); // Mostrar lista de clientes
                });

            // Agregar los event listeners para calcular el financiamiento solo cuando los campos sean modificados
            document.getElementById('cuotaInicial').addEventListener('input', calcularFinanciamiento);
            document.getElementById('tasaInteres').addEventListener('input', calcularFinanciamiento);
            document.getElementById('fechaInicio').addEventListener('change', calcularFinanciamiento);
            document.getElementById('cuotas').addEventListener('input', calcularFinanciamiento);
            document.getElementById('frecuenciaPago').addEventListener('change',calcularFinanciamiento);
            
            document.querySelector('#fecha-inicio').addEventListener('change', cargarFinanciamientos);
            document.querySelector('#fecha-fin').addEventListener('change', cargarFinanciamientos);

            $(document).on('change', '#cantidad', function () {
                clearTimeout(timeout); // Limpia cualquier timeout previo
                timeout = setTimeout(calcularMonto, 300); // Ejecuta después de 300ms
            });
    });

</script>

    </body>
</html>